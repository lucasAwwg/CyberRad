# CyberRad V4.5

Motor local de curación de noticias de ciberseguridad con:
- aliases y sinónimos
- scoring híbrido léxico + semántico
- aprendizaje por feedback manual
- deduplicación avanzada
- clustering temático de campañas
- exportación DOCX

## Arranque rápido (Windows CMD)

```bat
cd /d D:\Descargas\cyberrad_v4_5_semantic
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 3000 --app-dir .
```


## Paquete unificado
Este paquete incluye en un único proyecto:
- CyberRad V4.5.1 con prompt estable y autoguardado
- filtro sectorial **Marcas** (`marcas_retail`)
- Docker root (`Dockerfile`, `docker-compose.yml`, `.env.example`)
- workflow de GitHub Actions para self-hosted runner
- scripts de despliegue para Ubuntu/Linux Mint

### Arranque rápido local
```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 3000 --app-dir .
```

### Arranque con Docker
```bash
cp .env.example .env
docker-compose up -d --build
```

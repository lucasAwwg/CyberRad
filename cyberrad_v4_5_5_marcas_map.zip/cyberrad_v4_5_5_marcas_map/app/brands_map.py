from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from math import sqrt
from typing import Any
import re

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas
from reportlab.lib.utils import simpleSplit

from .rss import normalize_spaces, parse_datetime_to_dt

COUNTRY_POINTS: dict[str, dict[str, float | str]] = {
    'Spain': {'lon': -3.7, 'lat': 40.4, 'continent': 'Europe'},
    'Portugal': {'lon': -8.2, 'lat': 39.4, 'continent': 'Europe'},
    'France': {'lon': 2.2, 'lat': 46.2, 'continent': 'Europe'},
    'United Kingdom': {'lon': -1.8, 'lat': 52.5, 'continent': 'Europe'},
    'Ireland': {'lon': -8.0, 'lat': 53.4, 'continent': 'Europe'},
    'Germany': {'lon': 10.4, 'lat': 51.2, 'continent': 'Europe'},
    'Netherlands': {'lon': 5.3, 'lat': 52.1, 'continent': 'Europe'},
    'Belgium': {'lon': 4.5, 'lat': 50.8, 'continent': 'Europe'},
    'Italy': {'lon': 12.6, 'lat': 42.8, 'continent': 'Europe'},
    'Switzerland': {'lon': 8.2, 'lat': 46.8, 'continent': 'Europe'},
    'Austria': {'lon': 14.2, 'lat': 47.5, 'continent': 'Europe'},
    'Sweden': {'lon': 18.1, 'lat': 59.3, 'continent': 'Europe'},
    'Denmark': {'lon': 10.0, 'lat': 56.2, 'continent': 'Europe'},
    'Norway': {'lon': 10.7, 'lat': 59.9, 'continent': 'Europe'},
    'Poland': {'lon': 19.0, 'lat': 52.2, 'continent': 'Europe'},
    'Turkey': {'lon': 32.8, 'lat': 39.9, 'continent': 'Europe'},
    'United States': {'lon': -98.6, 'lat': 39.8, 'continent': 'North America'},
    'Canada': {'lon': -79.4, 'lat': 43.7, 'continent': 'North America'},
    'Mexico': {'lon': -99.1, 'lat': 19.4, 'continent': 'North America'},
    'Brazil': {'lon': -47.9, 'lat': -15.8, 'continent': 'South America'},
    'Argentina': {'lon': -58.4, 'lat': -34.6, 'continent': 'South America'},
    'Chile': {'lon': -70.7, 'lat': -33.4, 'continent': 'South America'},
    'Colombia': {'lon': -74.1, 'lat': 4.7, 'continent': 'South America'},
    'Japan': {'lon': 139.7, 'lat': 35.7, 'continent': 'Asia'},
    'South Korea': {'lon': 127.0, 'lat': 37.5, 'continent': 'Asia'},
    'China': {'lon': 116.4, 'lat': 39.9, 'continent': 'Asia'},
    'Hong Kong': {'lon': 114.1, 'lat': 22.3, 'continent': 'Asia'},
    'India': {'lon': 77.2, 'lat': 28.6, 'continent': 'Asia'},
    'Singapore': {'lon': 103.8, 'lat': 1.35, 'continent': 'Asia'},
    'United Arab Emirates': {'lon': 55.3, 'lat': 25.2, 'continent': 'Asia'},
    'Australia': {'lon': 151.2, 'lat': -33.9, 'continent': 'Oceania'},
    'New Zealand': {'lon': 174.8, 'lat': -41.3, 'continent': 'Oceania'},
    'South Africa': {'lon': 28.0, 'lat': -26.2, 'continent': 'Africa'},
    'Egypt': {'lon': 31.2, 'lat': 30.0, 'continent': 'Africa'},
    'Saudi Arabia': {'lon': 46.7, 'lat': 24.7, 'continent': 'Asia'},
}

COUNTRY_ALIASES: dict[str, tuple[str, ...]] = {
    'Spain': ('spain', 'spanish', 'españa', 'espana'),
    'Portugal': ('portugal', 'portuguese'),
    'France': ('france', 'french'),
    'United Kingdom': ('united kingdom', 'uk', 'britain', 'british', 'england', 'london'),
    'Ireland': ('ireland', 'irish', 'dublin'),
    'Germany': ('germany', 'german', 'deutschland'),
    'Netherlands': ('netherlands', 'dutch', 'holland'),
    'Belgium': ('belgium', 'belgian'),
    'Italy': ('italy', 'italian'),
    'Switzerland': ('switzerland', 'swiss'),
    'Austria': ('austria', 'austrian'),
    'Sweden': ('sweden', 'swedish'),
    'Denmark': ('denmark', 'danish'),
    'Norway': ('norway', 'norwegian'),
    'Poland': ('poland', 'polish'),
    'Turkey': ('turkey', 'turkish'),
    'United States': ('united states', 'us', 'usa', 'american', 'new york'),
    'Canada': ('canada', 'canadian', 'vancouver', 'montreal', 'toronto'),
    'Mexico': ('mexico', 'mexican'),
    'Brazil': ('brazil', 'brazilian'),
    'Argentina': ('argentina', 'argentinian'),
    'Chile': ('chile', 'chilean'),
    'Colombia': ('colombia', 'colombian'),
    'Japan': ('japan', 'japanese', 'tokyo'),
    'South Korea': ('south korea', 'korea', 'korean', 'seoul'),
    'China': ('china', 'chinese', 'beijing', 'shanghai'),
    'Hong Kong': ('hong kong',),
    'India': ('india', 'indian'),
    'Singapore': ('singapore',),
    'United Arab Emirates': ('uae', 'united arab emirates', 'dubai', 'abu dhabi'),
    'Australia': ('australia', 'australian', 'sydney', 'melbourne'),
    'New Zealand': ('new zealand',),
    'South Africa': ('south africa',),
    'Egypt': ('egypt', 'egyptian'),
    'Saudi Arabia': ('saudi arabia', 'saudi'),
}

BRAND_TO_COUNTRY: dict[str, str] = {
    'mango': 'Spain', 'inditex': 'Spain', 'zara': 'Spain', 'bershka': 'Spain', 'stradivarius': 'Spain', 'pull&bear': 'Spain', 'pull and bear': 'Spain', 'massimo dutti': 'Spain', 'oysho': 'Spain',
    'h&m': 'Sweden', 'hm': 'Sweden', 'hm group': 'Sweden', 'hennes': 'Sweden', 'arket': 'Sweden', 'cos': 'United Kingdom', 'weekday': 'Sweden', 'monki': 'Sweden',
    'nike': 'United States', 'adidas': 'Germany', 'puma': 'Germany', 'under armour': 'United States', 'lululemon': 'Canada', 'gap': 'United States', 'old navy': 'United States', 'banan republic': 'United States',
    'uniqlo': 'Japan', 'fast retailing': 'Japan', 'shein': 'Singapore', 'primark': 'Ireland', 'zalando': 'Germany', 'asos': 'United Kingdom', 'boohoo': 'United Kingdom', 'next plc': 'United Kingdom', 'river island': 'United Kingdom', 'marks and spencer': 'United Kingdom', 'm&s': 'United Kingdom',
    'burberry': 'United Kingdom', 'gucci': 'Italy', 'prada': 'Italy', 'armani': 'Italy', 'moncler': 'Italy', 'louis vuitton': 'France', 'dior': 'France', 'hermes': 'France', 'chanel': 'France', 'lvmh': 'France', 'kering': 'France', 'balenciaga': 'France', 'saint laurent': 'France',
    'sephora': 'France', 'farfetch': 'United Kingdom', 'yoox': 'Italy', 'net-a-porter': 'United Kingdom', 'saks': 'United States', "macy's": 'United States', 'macys': 'United States', 'nordstrom': 'United States', "victoria's secret": "United States",
    'ralph lauren': 'United States', 'tommy hilfiger': 'United States', 'calvin klein': 'United States', 'pvh': 'United States', 'coach': 'United States', 'kate spade': 'United States', 'michael kors': 'United States', 'tapestry': 'United States',
    'decathlon': 'France', 'otb group': 'Italy', 'superdry': 'United Kingdom', 'guess': 'United States', 'levi strauss': 'United States', 'levis': 'United States'
}

ATTACK_KEYWORDS = {
    'Ransomware': ('ransomware', 'extortion', 'encryptor'),
    'Brecha de datos': ('data breach', 'breach', 'leaked data', 'filtración', 'filtracion', 'customer data'),
    'Pagos comprometidos': ('payment breach', 'payment skimmer', 'magecart', 'carding', 'checkout compromise', 'compromiso de pagos'),
    'Robo de credenciales': ('credential theft', 'stolen credentials', 'account takeover', 'robo de credenciales'),
    'Phishing': ('phishing', 'smishing', 'vishing'),
    'Malware': ('malware', 'trojan', 'botnet', 'web skimmer'),
    'Incidente / hackeo': ('cyberattack', 'cyber attack', 'hack', 'hacked', 'ciberataque', 'ciberincidente', 'security incident', 'compromise', 'compromised'),
}

WORLD_SVG = """
<svg viewBox="0 0 1000 500" class="world-svg" xmlns="http://www.w3.org/2000/svg" aria-label="Mapa mundi cibernético">
  <defs>
    <linearGradient id="oceanGlow" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#07121d" />
      <stop offset="100%" stop-color="#04110a" />
    </linearGradient>
  </defs>
  <rect x="0" y="0" width="1000" height="500" rx="24" fill="url(#oceanGlow)" stroke="#1f5d3a" stroke-width="1.5" />
  <g stroke="#114f31" stroke-width="1" opacity="0.55">
    <path d="M40 120 H960"/><path d="M40 200 H960"/><path d="M40 280 H960"/><path d="M40 360 H960"/>
    <path d="M140 40 V460"/><path d="M280 40 V460"/><path d="M420 40 V460"/><path d="M560 40 V460"/><path d="M700 40 V460"/><path d="M840 40 V460"/>
  </g>
  <g fill="#0b2518" stroke="#22c55e" stroke-opacity="0.24" stroke-width="1.2">
    <path d="M88 92 146 74 226 90 258 127 254 162 219 180 200 213 150 212 122 198 116 164 96 137Z" />
    <path d="M238 218 286 235 308 282 286 347 266 405 236 420 222 382 228 328 216 280Z" />
    <path d="M430 82 474 63 557 74 610 100 608 130 582 153 541 146 520 182 484 173 462 145 437 125Z" />
    <path d="M470 184 515 194 552 232 573 272 564 334 537 389 500 414 476 395 489 350 470 306 450 268 447 229Z" />
    <path d="M611 93 652 76 737 84 804 118 836 146 862 191 849 221 812 214 784 194 750 182 722 191 710 220 676 241 645 220 632 188 618 154Z" />
    <path d="M736 240 781 254 818 279 858 336 835 382 785 396 760 361 742 314Z" />
    <path d="M848 326 875 338 899 360 894 395 868 411 846 395 842 360Z" />
  </g>
  <g id="map-dots"></g>
</svg>
""".strip()


def _norm(text: str | None) -> str:
    return normalize_spaces(text or '')


def infer_country_and_brand(article: dict[str, Any]) -> tuple[str | None, str | None, str]:
    text = ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
        article.get('content') or '',
        article.get('feed_name') or '',
    ])
    norm = _norm(text)
    for brand, country in BRAND_TO_COUNTRY.items():
        if brand in norm:
            return country, brand.title(), 'brand'
    for country, aliases in COUNTRY_ALIASES.items():
        for alias in aliases:
            if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', norm):
                return country, None, 'country'
    return None, None, 'unknown'


def infer_attack_label(article: dict[str, Any]) -> str:
    text = _norm(' '.join([article.get('title') or '', article.get('summary') or '', article.get('content') or '']))
    for label, keywords in ATTACK_KEYWORDS.items():
        for keyword in keywords:
            if keyword in text:
                return label
    return 'Incidente ciber'


def year_for_article(article: dict[str, Any]) -> int:
    raw = article.get('published_at') or article.get('created_at') or ''
    return parse_datetime_to_dt(raw).year


def world_xy(country: str, width: float = 1000, height: float = 500) -> tuple[float, float]:
    point = COUNTRY_POINTS[country]
    lon = float(point['lon'])
    lat = float(point['lat'])
    x = ((lon + 180.0) / 360.0) * width
    y = ((90.0 - lat) / 180.0) * height
    return x, y


def build_brands_map_data(articles: list[dict[str, Any]], selected_year: int | None = None) -> dict[str, Any]:
    marcas_rows = []
    available_years: set[int] = set()
    for article in articles:
        sectors = article.get('sector_categories') or []
        if 'marcas_retail' not in sectors:
            continue
        available_years.add(year_for_article(article))
        if selected_year is not None and year_for_article(article) != selected_year:
            continue
        if article.get('status') == 'excluded':
            continue
        marcas_rows.append(article)

    if selected_year is None:
        selected_year = max(available_years) if available_years else datetime.utcnow().year
        marcas_rows = [a for a in marcas_rows if year_for_article(a) == selected_year]

    country_counts: dict[str, int] = defaultdict(int)
    country_brands: dict[str, set[str]] = defaultdict(set)
    attack_counts: dict[str, int] = defaultdict(int)
    incidents: list[dict[str, Any]] = []
    unresolved = 0

    for article in marcas_rows:
        country, brand, source = infer_country_and_brand(article)
        attack = infer_attack_label(article)
        if country and country in COUNTRY_POINTS:
            country_counts[country] += 1
            if brand:
                country_brands[country].add(brand)
        else:
            unresolved += 1
        attack_counts[attack] += 1
        incidents.append({
            'id': article.get('id'),
            'title': article.get('title') or 'Sin título',
            'country': country or 'No inferido',
            'brand': brand or 'Marca no inferida',
            'attack_type': attack,
            'published_at': article.get('published_at') or article.get('created_at'),
            'article_url': article.get('article_url') or '',
            'source': source,
            'score': round(float(article.get('relevance_score') or 0), 3),
        })

    incidents.sort(key=lambda item: item.get('published_at') or '', reverse=True)
    points = []
    for country, count in sorted(country_counts.items(), key=lambda kv: (-kv[1], kv[0])):
        x, y = world_xy(country)
        points.append({
            'country': country,
            'count': count,
            'x': round(x, 2),
            'y': round(y, 2),
            'brands': sorted(country_brands[country]),
            'continent': COUNTRY_POINTS[country]['continent'],
        })

    top_countries = [
        {
            'country': point['country'],
            'count': point['count'],
            'brands': point['brands'][:4],
        }
        for point in points[:8]
    ]
    top_attacks = [
        {'label': label, 'count': count}
        for label, count in sorted(attack_counts.items(), key=lambda kv: (-kv[1], kv[0]))[:6]
    ]

    return {
        'year': selected_year,
        'available_years': sorted(available_years, reverse=True),
        'totals': {
            'incidents': len(marcas_rows),
            'countries': len(country_counts),
            'brands': len({incident['brand'] for incident in incidents if incident['brand'] != 'Marca no inferida'}),
            'unresolved': unresolved,
        },
        'points': points,
        'top_countries': top_countries,
        'top_attacks': top_attacks,
        'incidents': incidents[:18],
        'map_svg': WORLD_SVG,
        'methodology': 'País inferido principalmente por la marca o retailer afectado; si no se detecta, se intenta por país explícito en el texto. El mapa solo usa noticias con categoría interna marcas_retail y estado distinto de excluida.',
    }


def _draw_map_background(pdf: canvas.Canvas, x: float, y: float, w: float, h: float) -> None:
    pdf.setFillColor(colors.HexColor('#06111b'))
    pdf.roundRect(x, y, w, h, 16, fill=1, stroke=0)
    pdf.setStrokeColor(colors.HexColor('#114f31'))
    pdf.setLineWidth(0.7)
    for frac in (0.2, 0.4, 0.6, 0.8):
        pdf.line(x + 18, y + h * frac, x + w - 18, y + h * frac)
    for frac in (0.14, 0.28, 0.42, 0.56, 0.70, 0.84):
        pdf.line(x + w * frac, y + 18, x + w * frac, y + h - 18)
    pdf.setFillColor(colors.HexColor('#0b2518'))
    pdf.setStrokeColor(colors.HexColor('#2dd56f'))
    pdf.setLineWidth(0.5)
    blobs = [
        [(0.09,0.73),(0.14,0.77),(0.23,0.74),(0.26,0.66),(0.25,0.58),(0.21,0.55),(0.20,0.49),(0.15,0.49),(0.12,0.52),(0.10,0.58),(0.09,0.65)],
        [(0.24,0.48),(0.28,0.44),(0.31,0.35),(0.29,0.22),(0.27,0.14),(0.24,0.10),(0.22,0.18),(0.23,0.28),(0.22,0.36)],
        [(0.43,0.76),(0.48,0.80),(0.56,0.78),(0.61,0.72),(0.60,0.66),(0.57,0.61),(0.53,0.62),(0.51,0.55),(0.48,0.57),(0.46,0.63),(0.44,0.67)],
        [(0.47,0.54),(0.52,0.52),(0.56,0.45),(0.57,0.37),(0.56,0.25),(0.54,0.16),(0.50,0.11),(0.48,0.15),(0.49,0.24),(0.47,0.31),(0.45,0.38),(0.45,0.46)],
        [(0.61,0.76),(0.65,0.80),(0.73,0.78),(0.80,0.72),(0.84,0.67),(0.86,0.60),(0.85,0.54),(0.81,0.55),(0.78,0.59),(0.75,0.60),(0.71,0.58),(0.68,0.54),(0.65,0.58),(0.63,0.67)],
        [(0.74,0.43),(0.78,0.40),(0.82,0.35),(0.86,0.24),(0.84,0.15),(0.79,0.13),(0.76,0.19),(0.75,0.28)],
        [(0.85,0.26),(0.88,0.24),(0.90,0.20),(0.90,0.13),(0.87,0.10),(0.85,0.13),(0.84,0.20)],
    ]
    for blob in blobs:
        path = pdf.beginPath()
        sx = x + blob[0][0] * w
        sy = y + blob[0][1] * h
        path.moveTo(sx, sy)
        for bx, by in blob[1:]:
            path.lineTo(x + bx * w, y + by * h)
        path.close()
        pdf.drawPath(path, fill=1, stroke=1)


def export_brands_map_pdf(path: str, map_data: dict[str, Any]) -> str:
    page_w, page_h = landscape(A4)
    pdf = canvas.Canvas(path, pagesize=(page_w, page_h))
    pdf.setTitle(f"CyberRad Marcas Map {map_data['year']}")

    pdf.setFillColor(colors.HexColor('#020617'))
    pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 20)
    pdf.drawString(36, page_h - 34, f"CyberRad · Mapa anual de ciberincidentes en Marcas · {map_data['year']}")
    pdf.setFont('Helvetica', 10)
    pdf.setFillColor(colors.HexColor('#9ad9b0'))
    pdf.drawString(36, page_h - 50, 'Solo noticias del sector textil / moda / lujo / retail de moda con incidente ciber asociado.')

    stat_y = page_h - 84
    card_w = 112
    stats = [
        ('Incidentes', str(map_data['totals']['incidents'])),
        ('Países', str(map_data['totals']['countries'])),
        ('Marcas', str(map_data['totals']['brands'])),
        ('Sin país', str(map_data['totals']['unresolved'])),
    ]
    for index, (label, value) in enumerate(stats):
        x = 36 + index * (card_w + 12)
        pdf.setFillColor(colors.HexColor('#0b1622'))
        pdf.roundRect(x, stat_y - 42, card_w, 38, 10, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#8ab99c'))
        pdf.setFont('Helvetica', 8)
        pdf.drawString(x + 10, stat_y - 14, label)
        pdf.setFillColor(colors.HexColor('#d7ffe3'))
        pdf.setFont('Helvetica-Bold', 16)
        pdf.drawString(x + 10, stat_y - 32, value)

    map_x, map_y, map_w, map_h = 36, 126, 540, 340
    _draw_map_background(pdf, map_x, map_y, map_w, map_h)
    pdf.setFillColor(colors.HexColor('#4ade80'))
    pdf.setFont('Helvetica-Bold', 11)
    pdf.drawString(map_x + 16, map_y + map_h - 22, 'Mapa mundi cibernético · Marcas')

    max_count = max((point['count'] for point in map_data['points']), default=1)
    for point in map_data['points']:
        px = map_x + (point['x'] / 1000.0) * map_w
        py = map_y + ((500.0 - point['y']) / 500.0) * map_h
        radius = 4.5 + (10.0 * (sqrt(point['count']) / sqrt(max_count or 1)))
        pdf.setFillColor(colors.Color(0.13, 0.77, 0.37, alpha=0.28))
        pdf.circle(px, py, radius * 1.65, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#22c55e'))
        pdf.circle(px, py, radius, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#d9ffe8'))
        pdf.setFont('Helvetica-Bold', 8)
        pdf.drawString(px + radius + 2, py + radius + 1, f"{point['country']} ({point['count']})")

    panel_x = 596
    pdf.setFillColor(colors.HexColor('#0b1622'))
    pdf.roundRect(panel_x, 126, 228, 340, 16, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 12)
    pdf.drawString(panel_x + 16, 440, 'Top países')
    pdf.setFont('Helvetica', 9)
    y = 422
    for idx, item in enumerate(map_data['top_countries'][:6], start=1):
        brands = ', '.join(item.get('brands') or []) or 'Sin marcas inferidas'
        pdf.setFillColor(colors.HexColor('#94d8ad'))
        pdf.drawString(panel_x + 16, y, f"{idx}. {item['country']} · {item['count']} casos")
        pdf.setFillColor(colors.HexColor('#7fa790'))
        for line in simpleSplit(brands[:82], 'Helvetica', 8, 190):
            y -= 10
            pdf.drawString(panel_x + 28, y, line)
        y -= 16

    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 12)
    pdf.drawString(panel_x + 16, max(176, y), 'Tipos de incidente')
    y2 = max(158, y - 16)
    pdf.setFont('Helvetica', 9)
    for item in map_data['top_attacks'][:5]:
        pdf.setFillColor(colors.HexColor('#94d8ad'))
        pdf.drawString(panel_x + 16, y2, f"• {item['label']}: {item['count']}")
        y2 -= 14

    pdf.setFillColor(colors.HexColor('#94d8ad'))
    pdf.setFont('Helvetica', 8)
    methodology_lines = simpleSplit(map_data.get('methodology', ''), 'Helvetica', 8, page_w - 72)
    for index, line in enumerate(methodology_lines):
        pdf.drawString(36, 100 - (index * 10), line)

    pdf.showPage()
    pdf.setFillColor(colors.HexColor('#020617'))
    pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 18)
    pdf.drawString(36, page_h - 36, f"Detalle de incidentes · Marcas · {map_data['year']}")
    pdf.setFont('Helvetica', 9)
    y = page_h - 64
    for item in map_data['incidents'][:18]:
        if y < 58:
            pdf.showPage()
            pdf.setFillColor(colors.HexColor('#020617'))
            pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
            pdf.setFillColor(colors.HexColor('#d7ffe3'))
            pdf.setFont('Helvetica-Bold', 16)
            pdf.drawString(36, page_h - 36, f"Detalle de incidentes · Continuación · {map_data['year']}")
            pdf.setFont('Helvetica', 9)
            y = page_h - 64
        pdf.setFillColor(colors.HexColor('#d7ffe3'))
        pdf.setFont('Helvetica-Bold', 10)
        title_lines = simpleSplit(item['title'], 'Helvetica-Bold', 10, page_w - 72)
        for line in title_lines[:2]:
            pdf.drawString(36, y, line)
            y -= 12
        pdf.setFillColor(colors.HexColor('#94d8ad'))
        pdf.setFont('Helvetica', 8.5)
        meta = f"{item['country']} · {item['brand']} · {item['attack_type']} · score {item['score']:.2f}"
        for line in simpleSplit(meta, 'Helvetica', 8.5, page_w - 72):
            pdf.drawString(48, y, line)
            y -= 10
        pdf.setFillColor(colors.HexColor('#7fa790'))
        pdf.drawString(48, y, item.get('published_at') or '')
        y -= 16
        pdf.setStrokeColor(colors.HexColor('#12301d'))
        pdf.line(36, y, page_w - 36, y)
        y -= 12

    pdf.save()
    return path

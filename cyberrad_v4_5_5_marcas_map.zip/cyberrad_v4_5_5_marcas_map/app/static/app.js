const statsEl = document.getElementById('stats');
const feedsListEl = document.getElementById('feedsList');
const articlesContainer = document.getElementById('articlesContainer');
const dialog = document.getElementById('articleDialog');
const dialogContent = document.getElementById('articleDialogContent');
const promptInput = document.getElementById('promptInput');
const promptSaveStatusEl = document.getElementById('promptSaveStatus');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const intervalInput = document.getElementById('intervalInput');
const maxArticlesInput = document.getElementById('maxArticlesInput');
const autoRefreshInput = document.getElementById('autoRefreshInput');
const dateWindowInput = document.getElementById('dateWindowInput');
const relevanceModeInput = document.getElementById('relevanceModeInput');
const hideDuplicatesInput = document.getElementById('hideDuplicatesInput');
const brandsMapSection = document.getElementById('brandsMapSection');
const brandsMapYearSelect = document.getElementById('brandsMapYearSelect');
const brandsMapPdfBtn = document.getElementById('brandsMapPdfBtn');
const brandsMapStats = document.getElementById('brandsMapStats');
const brandsMapCanvas = document.getElementById('brandsMapCanvas');
const brandsMapTopCountries = document.getElementById('brandsMapTopCountries');
const brandsMapTopAttacks = document.getElementById('brandsMapTopAttacks');
const brandsMapIncidents = document.getElementById('brandsMapIncidents');

const PROMPT_DRAFT_KEY = 'cyberrad_prompt_draft_v451';
let currentStatus = 'all';
let currentSector = 'all';
let knownArticleIds = new Set();
let lastServerPrompt = '';
let promptDirty = false;
let autosaveTimer = null;
let saveInFlight = false;
let queuedPromptAutosave = false;
let isBootstrapped = false;
let lastRescoreInProgress = false;
let brandsMapData = null;
let brandsMapYear = new Date().getFullYear();

async function api(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(detail || 'Error en la petición');
  }
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function setPromptStatus(message, tone = 'muted') {
  promptSaveStatusEl.textContent = message;
  promptSaveStatusEl.className = `save-status ${tone}`;
}

function persistPromptDraft(value) {
  try {
    if (value && value !== lastServerPrompt) {
      localStorage.setItem(PROMPT_DRAFT_KEY, value);
    } else {
      localStorage.removeItem(PROMPT_DRAFT_KEY);
    }
  } catch (error) {
    console.warn('No se pudo guardar el borrador local del prompt', error);
  }
}

function loadLocalPromptDraft() {
  try {
    return localStorage.getItem(PROMPT_DRAFT_KEY) || '';
  } catch (error) {
    return '';
  }
}

function markPromptDirty() {
  promptDirty = promptInput.value !== lastServerPrompt;
  persistPromptDraft(promptInput.value);
  if (promptDirty) {
    setPromptStatus('Borrador local guardado. Esperando para autoguardar…', 'warning');
  } else {
    setPromptStatus('Prompt sincronizado con el servidor.', 'success');
  }
}

function schedulePromptAutosave() {
  clearTimeout(autosaveTimer);
  if (!promptDirty) return;
  autosaveTimer = setTimeout(() => {
    saveSettings({ promptOnly: true, source: 'autosave' }).catch(console.error);
  }, 900);
}

function renderStats(stats, feedback = {}) {
  statsEl.innerHTML = `
    <div class="stat-box"><span>Total</span><strong>${stats.total_articles}</strong></div>
    <div class="stat-box"><span>Feeds</span><strong>${stats.feed_count}</strong></div>
    <div class="stat-box"><span>Incluidas</span><strong>${stats.included_count}</strong></div>
    <div class="stat-box"><span>Pendientes</span><strong>${stats.pending_count}</strong></div>
    <div class="stat-box"><span>Excluidas</span><strong>${stats.excluded_count}</strong></div>
    <div class="stat-box"><span>Feedback</span><strong>${feedback.feedback_events || 0}</strong></div>
  `;
}

function applySettingsToForm(settings) {
  const focusedElement = document.activeElement;
  const serverPrompt = settings.prompt || '';
  const canOverwritePrompt = !promptDirty && focusedElement !== promptInput;
  if (canOverwritePrompt) {
    promptInput.value = serverPrompt;
    lastServerPrompt = serverPrompt;
    persistPromptDraft('');
    if (isBootstrapped) {
      setPromptStatus('Prompt sincronizado con el servidor.', 'success');
    }
  }
  if (focusedElement !== intervalInput) intervalInput.value = Number(settings.poll_interval_seconds || 300);
  if (focusedElement !== maxArticlesInput) maxArticlesInput.value = Number(settings.max_articles_per_feed || 20);
  if (focusedElement !== dateWindowInput) dateWindowInput.value = settings.date_window || 'all';
  if (focusedElement !== relevanceModeInput) relevanceModeInput.value = settings.relevance_mode || 'balanced';
  autoRefreshInput.checked = Boolean(settings.auto_refresh_enabled);
  hideDuplicatesInput.checked = Boolean(settings.hide_duplicates);
}

function renderFeeds(feeds) {
  if (!feeds.length) {
    feedsListEl.innerHTML = '<p class="empty-state">Todavía no hay feeds.</p>';
    return;
  }
  feedsListEl.innerHTML = feeds.map(feed => `
    <div class="feed-row">
      <div>
        <strong>${escapeHtml(feed.name)}</strong>
        <div class="article-meta wrap-anywhere">${escapeHtml(feed.url)}</div>
      </div>
      <div class="feed-actions">
        <button class="secondary-btn" onclick="toggleFeed(${feed.id}, ${feed.is_enabled ? 'false' : 'true'})">${feed.is_enabled ? 'Pausar' : 'Activar'}</button>
        <button class="secondary-btn" onclick="removeFeed(${feed.id})">Borrar</button>
      </div>
    </div>
  `).join('');
}

function statusChip(status) {
  const labels = { included: 'Incluida', pending: 'Pendiente', excluded: 'Excluida' };
  return `<span class="status-chip status-${status}">${labels[status] || status}</span>`;
}

function formatDate(value) {
  if (!value) return 'Sin fecha';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('es-ES');
}

function renderTags(tags = []) {
  if (!Array.isArray(tags) || !tags.length) return '';
  return `<div class="tag-row">${tags.slice(0, 6).map(tag => `<span class="tag-chip">${escapeHtml(tag)}</span>`).join('')}</div>`;
}

function sectorMeta(article) {
  return Array.isArray(article.sector_categories) && article.sector_categories.includes('marcas_retail')
    ? '<span class="sector-chip">Marcas</span>'
    : '';
}

function toggleBrandsMapVisibility() {
  const active = currentSector === 'marcas_retail';
  brandsMapSection.classList.toggle('hidden', !active);
}

function renderBrandsMapStats(totals = {}) {
  brandsMapStats.innerHTML = `
    <div class="stat-box"><span>Incidentes</span><strong>${totals.incidents || 0}</strong></div>
    <div class="stat-box"><span>Países</span><strong>${totals.countries || 0}</strong></div>
    <div class="stat-box"><span>Marcas</span><strong>${totals.brands || 0}</strong></div>
    <div class="stat-box"><span>Sin país</span><strong>${totals.unresolved || 0}</strong></div>
  `;
}

function renderMapList(el, items, formatter) {
  if (!items || !items.length) {
    el.innerHTML = '<div class="empty-mini">Sin datos todavía.</div>';
    return;
  }
  el.innerHTML = items.map(formatter).join('');
}

function buildMapSvg(data) {
  const maxCount = Math.max(...(data.points || []).map(point => point.count), 1);
  const dots = (data.points || []).map(point => {
    const radius = 6 + Math.round(18 * Math.sqrt(point.count / maxCount));
    const label = `${escapeHtml(point.country)} · ${point.count} incidentes`;
    const brands = (point.brands || []).slice(0, 5).join(', ');
    return `
      <g class="map-point" transform="translate(${point.x}, ${point.y})">
        <title>${label}${brands ? ` · ${escapeHtml(brands)}` : ''}</title>
        <circle r="${radius * 1.7}" class="dot-glow"></circle>
        <circle r="${radius}" class="dot-core"></circle>
        <text x="${radius + 4}" y="${-radius - 4}" class="dot-label">${escapeHtml(point.country)} (${point.count})</text>
      </g>
    `;
  }).join('');
  return (data.map_svg || '').replace('<g id="map-dots"></g>', `<g id="map-dots">${dots}</g>`);
}

function renderBrandsMap(data) {
  brandsMapData = data;
  const years = data.available_years || [];
  if (years.length) {
    brandsMapYearSelect.innerHTML = years.map(year => `<option value="${year}" ${Number(year) === Number(data.year) ? 'selected' : ''}>${year}</option>`).join('');
    brandsMapYear = Number(data.year);
  } else {
    brandsMapYearSelect.innerHTML = `<option value="${brandsMapYear}">${brandsMapYear}</option>`;
  }
  brandsMapPdfBtn.href = `/export/marcas-map.pdf?year=${encodeURIComponent(brandsMapYear)}`;
  renderBrandsMapStats(data.totals || {});
  if (!(data.totals || {}).incidents) {
    brandsMapCanvas.innerHTML = '<div class="map-empty">No hay noticias de Marcas para ese año todavía. Pulsa “Actualizar ahora” o cambia el año.</div>';
    brandsMapTopCountries.innerHTML = '<div class="empty-mini">Sin datos.</div>';
    brandsMapTopAttacks.innerHTML = '<div class="empty-mini">Sin datos.</div>';
    brandsMapIncidents.innerHTML = '<div class="empty-mini wide">Sin incidentes en ese año.</div>';
    return;
  }
  brandsMapCanvas.innerHTML = buildMapSvg(data);
  renderMapList(brandsMapTopCountries, data.top_countries, item => `
    <div class="map-list-item">
      <strong>${escapeHtml(item.country)}</strong>
      <span>${item.count} incidentes</span>
      <small>${escapeHtml((item.brands || []).join(', ') || 'Sin marcas inferidas')}</small>
    </div>
  `);
  renderMapList(brandsMapTopAttacks, data.top_attacks, item => `
    <div class="map-list-item compact">
      <strong>${escapeHtml(item.label)}</strong>
      <span>${item.count}</span>
    </div>
  `);
  renderMapList(brandsMapIncidents, data.incidents, item => `
    <article class="incident-row">
      <div>
        <h4>${escapeHtml(item.title)}</h4>
        <p>${escapeHtml(item.country)} · ${escapeHtml(item.brand)} · ${escapeHtml(item.attack_type)}</p>
      </div>
      <div class="incident-meta">
        <span>${escapeHtml(formatDate(item.published_at))}</span>
        <a class="button-link secondary-btn" href="${escapeAttribute(item.article_url)}" target="_blank" rel="noopener noreferrer">Abrir</a>
      </div>
    </article>
  `);
}

async function loadBrandsMap(forceYear = null) {
  toggleBrandsMapVisibility();
  if (currentSector !== 'marcas_retail') return;
  const year = Number(forceYear || brandsMapYear || new Date().getFullYear());
  brandsMapCanvas.innerHTML = '<div class="map-empty">Cargando mapa anual de Marcas…</div>';
  const params = new URLSearchParams({ year: String(year) });
  const data = await api(`/api/marcas-map?${params.toString()}`);
  renderBrandsMap(data);
}

function renderArticles(articles) {
  if (!articles.length) {
    articlesContainer.innerHTML = '<div class="card empty-state">No hay noticias para este filtro.</div>';
    return;
  }
  const newIds = new Set(articles.map(a => a.id));
  articlesContainer.innerHTML = articles.map(article => {
    const isNew = !knownArticleIds.has(article.id);
    return `
      <article class="article-card ${isNew ? 'slide-in' : ''}">
        ${article.image_url ? `<img class="article-image" src="${escapeAttribute(article.image_url)}" alt="${escapeAttribute(article.title)}" />` : '<div class="article-image"></div>'}
        <div class="article-body">
          <div class="article-meta">
            <span>${escapeHtml(article.feed_name || 'Feed')}</span>${sectorMeta(article)}
            <span>Híbrido ${Number(article.relevance_score || 0).toFixed(2)} · Sem ${Number(article.semantic_score || 0).toFixed(2)}</span>
          </div>
          <h3 class="article-title">${escapeHtml(article.title)}</h3>
          <p class="article-summary">${escapeHtml((article.summary || article.content || '').slice(0, 220))}</p>
          ${renderTags(article.match_tags)}
          ${article.campaign_cluster ? `<div class="article-meta"><span>Campaña: ${escapeHtml(article.campaign_cluster.replace('campaign:', ''))}</span></div>` : ''}
          <p class="article-rationale">${escapeHtml((article.rationale || 'Sin explicación').slice(0, 180))}</p>
          <div class="article-meta">
            <span>${formatDate(article.published_at || article.created_at)}</span>
            ${statusChip(article.status)}
          </div>
          <div class="status-actions">
            <button onclick="setArticleStatus(${article.id}, 'included')">Incluir</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'pending')">Pendiente</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'excluded')">Excluir</button>
          </div>
          <div class="article-actions">
            <button class="secondary-btn" onclick="showArticle(${article.id})">VER</button>
            <a class="button-link secondary-btn" href="${escapeAttribute(article.article_url)}" target="_blank" rel="noopener noreferrer">WEB</a>
          </div>
        </div>
      </article>
    `;
  }).join('');
  knownArticleIds = newIds;
}

function handleJobs(jobs = {}) {
  const inProgress = Boolean(jobs.rescore_in_progress);
  if (inProgress) {
    setPromptStatus('Guardado. Recalculando noticias en segundo plano…', 'progress');
  } else if (lastRescoreInProgress && !inProgress && !promptDirty) {
    setPromptStatus('Cambios aplicados. Noticias recalculadas.', 'success');
    loadArticles().catch(console.error);
  }
  if (jobs.rescore_last_error) {
    setPromptStatus(`Guardado con aviso: ${jobs.rescore_last_error}`, 'error');
  }
  lastRescoreInProgress = inProgress;
}

async function loadState() {
  const state = await api('/api/state');
  renderStats(state.stats, state.feedback || {});
  renderFeeds(state.feeds);
  applySettingsToForm(state.settings);
  handleJobs(state.jobs || {});
  return state;
}

async function loadArticles() {
  const params = new URLSearchParams({ limit: '60', status: currentStatus, sector: currentSector });
  const payload = await api(`/api/articles?${params.toString()}`);
  renderArticles(payload.articles);
  toggleBrandsMapVisibility();
}

async function showArticle(articleId) {
  const article = await api(`/api/articles/${articleId}`);
  dialogContent.innerHTML = `
    <h2>${escapeHtml(article.title)}</h2>
    ${article.image_url ? `<img class="dialog-image" src="${escapeAttribute(article.image_url)}" alt="${escapeAttribute(article.title)}" />` : ''}
    <p><strong>Fuente:</strong> ${escapeHtml(article.feed_name || 'N/D')}</p>
    <p><strong>Fecha:</strong> ${escapeHtml(formatDate(article.published_at || article.created_at))}</p>
    <p><strong>Tags:</strong> ${(article.match_tags || []).map(escapeHtml).join(', ') || 'Sin tags'}</p>
    ${Array.isArray(article.sector_categories) && article.sector_categories.includes('marcas_retail') ? '<p><strong>Categoría interna:</strong> marcas_retail · <strong>Etiqueta:</strong> Marcas</p>' : ''}
    <p><strong>Score híbrido:</strong> ${Number(article.relevance_score || 0).toFixed(2)} · <strong>Semántico:</strong> ${Number(article.semantic_score || 0).toFixed(2)} · <strong>Feedback:</strong> ${Number(article.feedback_score || 0).toFixed(2)}</p>
    ${article.campaign_cluster ? `<p><strong>Cluster temático:</strong> ${escapeHtml(article.campaign_cluster.replace('campaign:', ''))}</p>` : ''}
    ${article.duplicate_group ? `<p><strong>Grupo duplicado:</strong> ${escapeHtml(article.duplicate_group.replace('dup:', ''))}</p>` : ''}
    <p><strong>Explicación:</strong> ${escapeHtml(article.rationale || 'Sin explicación')}</p>
    <p>${escapeHtml(article.summary || '')}</p>
    <p>${escapeHtml(article.content || '')}</p>
    ${article.video_url ? `<p><strong>Vídeo:</strong> <a href="${escapeAttribute(article.video_url)}" target="_blank" rel="noopener noreferrer">Abrir vídeo</a></p>` : ''}
    <p><strong>Artículo:</strong> <a href="${escapeAttribute(article.article_url)}" target="_blank" rel="noopener noreferrer">Abrir noticia</a></p>
  `;
  dialog.showModal();
}
window.showArticle = showArticle;

async function setArticleStatus(articleId, status) {
  const result = await api(`/api/articles/${articleId}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  handleJobs(result.jobs || {});
  await Promise.all([loadState(), loadArticles()]);
  if (currentSector === 'marcas_retail') {
    await loadBrandsMap(brandsMapYear);
  }
}
window.setArticleStatus = setArticleStatus;

async function toggleFeed(feedId, is_enabled) {
  await api(`/api/feeds/${feedId}`, { method: 'PATCH', body: JSON.stringify({ is_enabled }) });
  await Promise.all([loadState(), loadArticles()]);
}
window.toggleFeed = toggleFeed;

async function removeFeed(feedId) {
  await api(`/api/feeds/${feedId}`, { method: 'DELETE' });
  await Promise.all([loadState(), loadArticles()]);
}
window.removeFeed = removeFeed;

function escapeHtml(value = '') {
  return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}
function escapeAttribute(value = '') { return escapeHtml(value); }

function currentSettingsPayload({ promptOnly = false } = {}) {
  if (promptOnly) return { prompt: promptInput.value };
  return {
    prompt: promptInput.value,
    poll_interval_seconds: Number(intervalInput.value),
    max_articles_per_feed: Number(maxArticlesInput.value),
    auto_refresh_enabled: autoRefreshInput.checked,
    date_window: dateWindowInput.value,
    relevance_mode: relevanceModeInput.value,
    hide_duplicates: hideDuplicatesInput.checked,
  };
}

async function saveSettings({ promptOnly = false, source = 'manual' } = {}) {
  if (saveInFlight) {
    if (promptOnly) queuedPromptAutosave = true;
    return;
  }
  saveInFlight = true;
  saveSettingsBtn.disabled = true;
  const originalButtonText = saveSettingsBtn.textContent;
  saveSettingsBtn.textContent = source === 'manual' ? 'Guardando…' : 'Autoguardando…';
  const payload = currentSettingsPayload({ promptOnly });
  const savingPromptValue = payload.prompt ?? promptInput.value;
  setPromptStatus(source === 'manual' ? 'Guardando configuración…' : 'Autoguardando prompt…', 'progress');
  try {
    const result = await api('/api/settings', { method: 'PATCH', body: JSON.stringify(payload) });
    if (typeof payload.prompt === 'string') {
      lastServerPrompt = savingPromptValue;
      promptDirty = promptInput.value !== lastServerPrompt;
      persistPromptDraft(promptDirty ? promptInput.value : '');
    }
    if (!promptOnly) {
      applySettingsToForm(result.settings || {});
    }
    handleJobs(result.jobs || {});
    if (!promptDirty && !(result.jobs || {}).rescore_in_progress) {
      setPromptStatus('Configuración guardada.', 'success');
    }
    if (!promptOnly) {
      await Promise.all([loadState(), loadArticles()]);
    }
  } catch (error) {
    setPromptStatus(`Error al guardar: ${error.message}`, 'error');
    throw error;
  } finally {
    saveInFlight = false;
    saveSettingsBtn.disabled = false;
    saveSettingsBtn.textContent = originalButtonText;
    if (queuedPromptAutosave) {
      queuedPromptAutosave = false;
      if (promptDirty) {
        schedulePromptAutosave();
      }
    }
  }
}

async function addFeed() {
  const payload = { name: document.getElementById('feedNameInput').value || null, url: document.getElementById('feedUrlInput').value };
  await api('/api/feeds', { method: 'POST', body: JSON.stringify(payload) });
  document.getElementById('feedNameInput').value = '';
  document.getElementById('feedUrlInput').value = '';
  await Promise.all([loadState(), loadArticles()]);
}

async function refreshNow() {
  setPromptStatus('Actualizando feeds…', 'progress');
  await api('/api/refresh', { method: 'POST' });
  await Promise.all([loadState(), loadArticles()]);
  if (currentSector === 'marcas_retail') {
    await loadBrandsMap(brandsMapYear);
  }
}

saveSettingsBtn.addEventListener('click', () => saveSettings({ promptOnly: false, source: 'manual' }));
document.getElementById('addFeedBtn').addEventListener('click', addFeed);
document.getElementById('refreshBtn').addEventListener('click', refreshNow);

promptInput.addEventListener('input', () => {
  markPromptDirty();
  schedulePromptAutosave();
});

promptInput.addEventListener('blur', () => {
  if (promptDirty) {
    saveSettings({ promptOnly: true, source: 'autosave' }).catch(console.error);
  }
});

window.addEventListener('beforeunload', () => {
  persistPromptDraft(promptInput.value);
});

window.addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
    event.preventDefault();
    saveSettings({ promptOnly: false, source: 'manual' }).catch(console.error);
  }
});

document.querySelectorAll('.status-filter').forEach(button => {
  button.addEventListener('click', async () => {
    document.querySelectorAll('.status-filter').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    currentStatus = button.dataset.status;
    await loadArticles();
  });
});

document.querySelectorAll('.sector-filter').forEach(button => {
  button.addEventListener('click', async () => {
    const willActivate = !button.classList.contains('active');
    document.querySelectorAll('.sector-filter').forEach(btn => btn.classList.remove('active'));
    if (willActivate) {
      button.classList.add('active');
      currentSector = button.dataset.sector || 'all';
    } else {
      currentSector = 'all';
    }
    toggleBrandsMapVisibility();
    await loadArticles();
    if (currentSector === 'marcas_retail') {
      await loadBrandsMap();
    }
  });
});

brandsMapYearSelect.addEventListener('change', async () => {
  brandsMapYear = Number(brandsMapYearSelect.value);
  await loadBrandsMap(brandsMapYear);
});

async function boot() {
  const state = await loadState();
  isBootstrapped = true;
  const localDraft = loadLocalPromptDraft();
  if (localDraft && localDraft !== (state.settings?.prompt || '')) {
    promptInput.value = localDraft;
    promptDirty = true;
    setPromptStatus('Borrador local recuperado. Se guardará solo.', 'warning');
    schedulePromptAutosave();
  }
  await loadArticles();
  toggleBrandsMapVisibility();
  setInterval(async () => {
    await loadArticles();
    if (currentSector === 'marcas_retail') {
      await loadBrandsMap(brandsMapYear);
    }
  }, 15000);
  setInterval(loadState, 5000);
}

boot().catch(error => {
  console.error(error);
  articlesContainer.innerHTML = `<div class="card empty-state">Error al cargar: ${escapeHtml(error.message)}</div>`;
  setPromptStatus(`Error al iniciar: ${error.message}`, 'error');
});

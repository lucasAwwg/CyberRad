
from __future__ import annotations

import html
import json
import re
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import feedparser
import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response

from app.feed_builder import build_google_news_brand_queries
from app.filters import MarcasFilter
from app.map_builder import build_map_payload
from app.trusted_sources import DIRECT_SOURCE_FEEDS

USER_AGENT = "CyberRad/5.0.5 OldUI MapFix (+https://localhost)"
REQUEST_TIMEOUT = 10
CACHE_TTL_SECONDS = 900
MAX_SCAN_ITEMS = 500
APP_PORT = 3001

api = FastAPI(title="CyberRad 5.0.5", version="5.0.5")
filter_engine = MarcasFilter()

_cache_lock = threading.Lock()
_cache_payload: dict[str, Any] | None = None
_cache_generated_at = 0.0

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"


@api.get("/", response_class=HTMLResponse)
def home() -> str:
    return build_home_html()


@api.get("/static/map.png")
def static_map() -> FileResponse:
    return FileResponse(STATIC_DIR / "map.png", media_type="image/png")


@api.get("/favicon.ico")
def favicon() -> Response:
    return Response(status_code=204)


@api.get("/health")
def health() -> dict[str, Any]:
    payload = get_dashboard_bundle(limit=40, force=False)
    return {
        "status": "ok",
        "service": "cyberrad",
        "version": "5.0.5",
        "port": APP_PORT,
        "cache_generated_at": payload["meta"]["generated_at"],
        "cache_age_seconds": payload["meta"]["cache_age_seconds"],
        "general": payload["summary"]["general_included"],
        "marcas": payload["summary"]["marcas_included"],
    }


@api.get("/api/dashboard")
def api_dashboard(limit: int = Query(default=40, ge=1, le=150), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    return JSONResponse(get_dashboard_bundle(limit=limit, force=bool(refresh)))


@api.get("/scan/general")
def scan_general(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["general_items"])


@api.get("/scan/marcas")
def scan_marcas(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["marcas_items"])


@api.get("/scan/map")
def scan_map(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["map_markers"])


def get_dashboard_bundle(limit: int, force: bool = False) -> dict[str, Any]:
    payload = get_or_refresh_cache(force=force)
    generated_at = payload["generated_at"]
    general_items = payload["general_items"][:limit]
    marcas_items = payload["marcas_items"][:limit]
    map_markers = payload["map_markers"][:limit]
    cache_age = max(0, int(time.time() - generated_at))

    summary = dict(payload["summary"])
    summary["showing_general"] = len(general_items)
    summary["showing_marcas"] = len(marcas_items)
    summary["showing_markers"] = len(map_markers)

    return {
        "meta": {
            "generated_at": isoformat_from_ts(generated_at),
            "cache_age_seconds": cache_age,
            "cache_ttl_seconds": CACHE_TTL_SECONDS,
            "cache_hit": not force,
            "feed_count": payload["feed_count"],
        },
        "summary": summary,
        "general_items": general_items,
        "marcas_items": marcas_items,
        "map_markers": map_markers,
    }


def get_or_refresh_cache(force: bool = False) -> dict[str, Any]:
    global _cache_payload, _cache_generated_at
    now = time.time()
    with _cache_lock:
        if not force and _cache_payload and (now - _cache_generated_at) < CACHE_TTL_SECONDS:
            return _cache_payload

    payload = build_fresh_payload()

    with _cache_lock:
        _cache_payload = payload
        _cache_generated_at = payload["generated_at"]
        return _cache_payload


def build_fresh_payload() -> dict[str, Any]:
    feeds = DIRECT_SOURCE_FEEDS + build_google_news_brand_queries()
    raw_items = fetch_all_feeds(feeds)
    deduped = dedupe_items(raw_items)

    general_items: list[dict[str, Any]] = []
    marcas_decisions: list[dict[str, Any]] = []

    for item in deduped:
        general = filter_engine.classify_general(item)
        if general:
            general_items.append(general)

        decision = filter_engine.classify(item).to_dict()
        decision["published"] = item.get("published")
        marcas_decisions.append(decision)

    general_items.sort(key=lambda item: (item["score"], item.get("published") or ""), reverse=True)
    marcas_decisions.sort(key=lambda item: (item["include"], item["score"], item.get("published") or ""), reverse=True)
    marcas_included = [item for item in marcas_decisions if item.get("include")]

    payload = {
        "generated_at": time.time(),
        "feed_count": len(feeds),
        "general_items": general_items[:MAX_SCAN_ITEMS],
        "marcas_items": marcas_included[:MAX_SCAN_ITEMS],
        "map_markers": build_map_payload(marcas_included[:MAX_SCAN_ITEMS]),
        "summary": build_summary(deduped, general_items, marcas_decisions, marcas_included),
    }
    return payload


def fetch_all_feeds(feeds: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not feeds:
        return []
    max_workers = min(14, max(4, len(feeds)))
    items: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(fetch_feed, feed) for feed in feeds]
        for future in as_completed(futures):
            try:
                items.extend(future.result())
            except Exception:
                continue
    return items


def fetch_feed(feed: dict[str, Any]) -> list[dict[str, Any]]:
    headers = {"User-Agent": USER_AGENT}
    try:
        response = requests.get(feed["url"], headers=headers, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        parsed = feedparser.parse(response.content)
    except Exception:
        return []

    items: list[dict[str, Any]] = []
    for entry in parsed.entries:
        article_url = extract_article_url(entry.get("link", ""))
        title = clean_html(entry.get("title", ""))
        summary = clean_html(entry.get("summary", ""))
        content = ""
        if entry.get("content"):
            first = entry["content"][0]
            content = clean_html(first.get("value", ""))
        source = feed.get("name")
        if entry.get("source") and isinstance(entry["source"], dict):
            source = entry["source"].get("title") or source
        published = normalize_published(entry)
        items.append(
            {
                "title": title,
                "summary": summary,
                "content": content,
                "url": entry.get("link", ""),
                "article_url": article_url,
                "source": source,
                "publisher_domain": urlparse(article_url if article_url else feed["url"]).netloc,
                "published": published,
                "discovery_only_source": bool(feed.get("discovery_only")),
            }
        )
    return items


def build_summary(raw_items: list[dict[str, Any]], general_items: list[dict[str, Any]], all_marcas: list[dict[str, Any]], included_marcas: list[dict[str, Any]]) -> dict[str, Any]:
    unique_brands = sorted({item.get("brand") for item in included_marcas if item.get("brand")})
    unique_countries = sorted({item.get("map_country_label") for item in included_marcas if item.get("map_country_label")})
    return {
        "total_scanned": len(raw_items),
        "general_included": len(general_items),
        "marcas_included": len(included_marcas),
        "marcas_rejected_or_pending": max(0, len(all_marcas) - len(included_marcas)),
        "unique_brands": len(unique_brands),
        "unique_countries": len(unique_countries),
        "top_brands": top_counts(included_marcas, "brand"),
        "top_countries": top_counts(included_marcas, "map_country_label"),
        "top_general_sources": top_counts(general_items, "source"),
        "top_marcas_sources": top_counts(included_marcas, "source"),
    }


def top_counts(items: list[dict[str, Any]], key: str, limit: int = 8) -> list[dict[str, Any]]:
    counts: dict[str, int] = {}
    for item in items:
        value = str(item.get(key) or "").strip()
        if not value:
            continue
        counts[value] = counts.get(value, 0) + 1
    ordered = sorted(counts.items(), key=lambda x: (-x[1], x[0]))
    return [{"name": name, "count": count} for name, count in ordered[:limit]]


def dedupe_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: OrderedDict[str, dict[str, Any]] = OrderedDict()
    for item in items:
        key = make_key(item)
        if key not in seen:
            seen[key] = item
    return list(seen.values())


def make_key(item: dict[str, Any]) -> str:
    title = re.sub(r"\s+", " ", (item.get("title") or "").lower()).strip()
    article_url = (item.get("article_url") or "").strip().lower()
    return article_url or title


def extract_article_url(value: str) -> str:
    if not value:
        return ""
    if "news.google.com" not in value:
        return value
    parsed = urlparse(value)
    q = parse_qs(parsed.query)
    if q.get("url"):
        return q["url"][0]
    return value


def clean_html(value: str) -> str:
    if not value:
        return ""
    soup = BeautifulSoup(value, "html.parser")
    text = soup.get_text(" ", strip=True)
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def normalize_published(entry: dict[str, Any]) -> str | None:
    for key in ("published_parsed", "updated_parsed"):
        struct_time = entry.get(key)
        if struct_time:
            try:
                dt = datetime(*struct_time[:6], tzinfo=timezone.utc)
                return dt.isoformat()
            except Exception:
                pass
    for key in ("published", "updated"):
        value = entry.get(key)
        if value:
            return str(value)
    return None


def isoformat_from_ts(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


def short_date(value: str | None) -> str:
    if not value:
        return "sin fecha"
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.strftime("%d/%m/%Y %H:%M")
    except Exception:
        return value[:16]



def build_home_html() -> str:
    return """
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>CyberRad 5.0.5</title>
<style>
:root{
  --bg:#020814;
  --bg2:#071327;
  --panel:#0d1628;
  --panel2:#101d33;
  --line:#1d2c49;
  --text:#eef4ff;
  --muted:#97aac0;
  --green:#28d366;
  --green2:#24bf60;
  --purple:#b567ff;
  --chip:#11243d;
  --shadow:0 16px 36px rgba(0,0,0,.34);
}
*{box-sizing:border-box}
html,body{margin:0;padding:0;font-family:Inter,Arial,sans-serif;background:radial-gradient(circle at top left,#0a1733 0,#061120 28%,#030915 62%,#02060f 100%);color:var(--text)}
a{text-decoration:none;color:inherit}
button,input,select{font:inherit}
.wrap{max-width:1860px;margin:0 auto;padding:16px}
.topbar{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin-bottom:14px}
.brand{display:flex;gap:14px;align-items:flex-start}
.logo{width:56px;height:56px;border-radius:14px;background:radial-gradient(circle at 35% 35%,rgba(40,211,102,.32),transparent 32%),linear-gradient(180deg,#081a32,#05111f);border:1px solid rgba(40,211,102,.24);box-shadow:0 0 0 1px rgba(40,211,102,.05), inset 0 0 28px rgba(40,211,102,.06);position:relative}
.logo:before{content:"";position:absolute;inset:14px;border:2px solid rgba(40,211,102,.82);border-radius:50%;box-shadow:0 0 16px rgba(40,211,102,.3)}
.title{font-size:26px;font-weight:900;line-height:1.05;margin-top:2px}
.subtitle{max-width:1120px;margin-top:8px;color:var(--muted);font-size:14px;line-height:1.42}
.header-actions{display:flex;gap:10px;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 22px;border-radius:14px;border:1px solid rgba(255,255,255,.08);font-weight:800;cursor:pointer;transition:.16s transform,.16s opacity;background:#17253e;color:#ecf4ff}
.btn:hover{transform:translateY(-1px);opacity:.97}
.btn.green{background:linear-gradient(180deg,var(--green),var(--green2));color:#041109;border:none}
.layout{display:grid;grid-template-columns:340px minmax(0,1fr);gap:14px}
.sidebar{background:linear-gradient(180deg,#0d1628,#09111d);border:1px solid var(--line);border-radius:18px;min-height:760px;padding:14px;box-shadow:var(--shadow);position:sticky;top:14px}
.main{min-width:0}
.panel{background:linear-gradient(180deg,#0d1628,#09111d);border:1px solid var(--line);border-radius:18px;box-shadow:var(--shadow)}
.panel-title{font-size:18px;font-weight:900;margin-bottom:12px}
.status-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-bottom:18px}
.stat-box{background:linear-gradient(180deg,#141f36,#101a30);border:1px solid rgba(255,255,255,.06);border-radius:16px;padding:14px}
.stat-k{color:#9fb4cb;font-size:14px;margin-bottom:6px}
.stat-v{font-size:18px;font-weight:900}
.prompt-box{background:#111a2d;border:1px solid rgba(255,255,255,.06);border-radius:16px;padding:14px;min-height:220px;color:var(--muted);line-height:1.48}
.prompt-footer{display:flex;gap:10px;margin-top:12px;flex-wrap:wrap}
.mini-btn{border-radius:14px;padding:12px 16px;font-weight:800;border:none}
.mini-btn.green{background:linear-gradient(180deg,var(--green),var(--green2));color:#041109}
.mini-btn.dark{background:#11243d;color:#d9e8ff;border:1px solid rgba(255,255,255,.08)}
.toolbar{background:linear-gradient(180deg,#0d1628,#0a1425);border:1px solid var(--line);border-radius:18px;padding:14px;display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:14px}
.tabs{display:flex;gap:10px;flex-wrap:wrap}
.tab{padding:10px 18px;border-radius:14px;background:#17253e;color:#f0f4ff;border:1px solid rgba(255,255,255,.06);font-weight:800;cursor:pointer}
.tab.active{background:linear-gradient(180deg,var(--green),#28bf63);color:#08130d;border:none}
.tab.purple.active{background:linear-gradient(180deg,#c66eff,#a54cff);color:#180725}
.toolbar-right{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.select{height:40px;background:#07111f;color:#fff;border:2px solid rgba(255,255,255,.36);border-radius:16px;padding:0 12px;min-width:102px;font-weight:700}
.map-card,.section{padding:16px}
.map-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:14px}
.map-head h2,.section-head h2{margin:0;font-size:19px}
.map-head p,.section-head p{margin:6px 0 0;color:var(--muted);line-height:1.45}
.map-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:14px}
.map-stat{background:linear-gradient(180deg,rgba(6,34,26,.52),rgba(6,22,20,.38));border:1px solid rgba(40,211,102,.14);border-radius:16px;padding:14px}
.map-stat .k{color:#a6b8c9;font-size:13px;margin-bottom:6px}
.map-stat .v{font-size:18px;font-weight:900}
.map-grid{display:grid;grid-template-columns:minmax(0,1fr) 380px;gap:14px}
.world{position:relative;background:#000;border:1px solid rgba(255,255,255,.08);border-radius:22px;overflow:hidden;min-height:434px}
.world img{display:block;width:100%;height:100%;object-fit:cover;filter:brightness(1.02)}
.marker{position:absolute;transform:translate(-50%,-50%);border-radius:999px;background:radial-gradient(circle,rgba(68,255,148,.98) 0,rgba(39,210,103,.96) 48%,rgba(11,78,38,.72) 74%,rgba(11,78,38,.18) 100%);color:#021109;font-weight:900;display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 7px rgba(39,210,103,.08),0 0 18px rgba(39,210,103,.28);cursor:pointer;transition:transform .14s ease, box-shadow .14s ease;border:none}
.marker:hover{transform:translate(-50%,-50%) scale(1.06);box-shadow:0 0 0 10px rgba(39,210,103,.11),0 0 22px rgba(39,210,103,.34)}
.marker-count{position:relative;z-index:2}
.tooltip{position:absolute;pointer-events:none;opacity:0;transform:translate(-50%,-120%);background:rgba(4,10,18,.96);border:1px solid rgba(40,211,102,.22);border-radius:14px;padding:10px 12px;min-width:180px;max-width:260px;box-shadow:var(--shadow);transition:opacity .12s ease;z-index:9}
.tooltip.visible{opacity:1}
.tooltip .t1{font-weight:900;margin-bottom:4px}
.tooltip .t2{color:#cdd9e7;font-size:13px;line-height:1.35}
.side-stack{display:grid;grid-template-rows:1fr 1fr;gap:14px}
.side-box{background:linear-gradient(180deg,rgba(6,34,26,.52),rgba(6,22,20,.38));border:1px solid rgba(40,211,102,.14);border-radius:16px;padding:16px;min-height:208px}
.side-box h3{margin:0 0 14px;font-size:16px}
.ranking{display:flex;flex-direction:column;gap:10px}
.rank-row{display:flex;justify-content:space-between;gap:12px;padding:10px 12px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.04);border-radius:12px}
.rank-row .name{color:#eaf3ff;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rank-row .num{color:#7dffac;font-weight:900}
.section{margin-top:14px}
.section-head{display:flex;justify-content:space-between;align-items:flex-end;gap:12px;margin-bottom:14px;flex-wrap:wrap}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:14px}
.card{background:linear-gradient(180deg,#0d1830,#0b1426 76%,#09111d);border:1px solid #253252;border-radius:20px;overflow:hidden;display:flex;flex-direction:column;min-height:542px}
.thumb{height:190px;background:radial-gradient(circle at 18% 18%,rgba(200,60,255,.62),transparent 25%),radial-gradient(circle at 75% 28%,rgba(44,154,255,.44),transparent 28%),linear-gradient(180deg,#152545,#0c1731)}
.card-body{padding:16px;display:flex;flex-direction:column;gap:12px;height:100%}
.source-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;color:#b9c7d7;font-size:14px}
.badge{padding:10px 15px;border-radius:999px;background:#4d2d8e;color:#f2e8ff;font-weight:800}
.badge.general{background:#163a61;color:#d9efff}
.meta-mini{color:#9cb0c8}
.card-title{font-size:17px;font-weight:900;line-height:1.26}
.card-summary{color:#dce9f6;line-height:1.58;min-height:120px}
.tag-row{display:flex;gap:8px;flex-wrap:wrap}
.tag{padding:7px 11px;border-radius:999px;background:#07292a;color:#a8ffcd;border:1px solid rgba(40,211,102,.18);font-size:14px;font-weight:700}
.tag.score{background:#3f3211;color:#ffd967;border-color:rgba(255,217,103,.2)}
.card-bottom{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:auto;flex-wrap:wrap}
.date{color:#dce8f6;font-size:14px}
.empty{padding:18px;border-radius:16px;background:#111a2d;border:1px dashed rgba(255,255,255,.08);color:#bdd1e6}
.small-note{font-size:13px;color:var(--muted)}
.loader{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(1,7,14,.82);backdrop-filter:blur(5px);z-index:9999}
.loader.hidden{display:none}
.loader-box{background:#0c1628;border:1px solid rgba(40,211,102,.24);border-radius:22px;padding:24px 28px;display:flex;flex-direction:column;align-items:center;gap:14px;min-width:280px;box-shadow:var(--shadow)}
.spinner{width:72px;height:72px;border-radius:50%;border:5px solid rgba(255,255,255,.08);border-top-color:#28df72;border-right-color:#28df72;animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.hidden{display:none !important}
@media (max-width:1250px){.layout{grid-template-columns:1fr}.sidebar{position:static;min-height:auto}.map-grid{grid-template-columns:1fr}.side-stack{grid-template-rows:auto}}
@media (max-width:900px){.topbar{flex-direction:column}.map-stats{grid-template-columns:1fr}.cards{grid-template-columns:1fr}.status-grid{grid-template-columns:1fr 1fr}.toolbar-right{width:100%}}
</style>
</head>
<body>
<div class="loader" id="loader"><div class="loader-box"><div class="spinner"></div><div style="font-size:22px;font-weight:900">Cargando CyberRad</div><div class="small-note">Consultando feeds, normalizando noticias y pintando el mapa…</div></div></div>
<div class="wrap">
  <div class="topbar">
    <div class="brand">
      <div class="logo"></div>
      <div>
        <div class="title">CyberRad V5.0.5</div>
        <div class="subtitle">Formato antiguo rehecho, filtro Marcas estricto, noticias generales separadas y mapa corregido sin puntos incrustados en la imagen.</div>
      </div>
    </div>
    <div class="header-actions">
      <button class="btn green" onclick="loadDashboard(true)">Actualizar ahora</button>
      <button class="btn green" onclick="downloadMapJson()">Exportar JSON</button>
    </div>
  </div>

  <div class="layout">
    <aside class="sidebar">
      <div class="panel-title">Estado</div>
      <div class="status-grid" id="statusGrid"></div>
      <div class="panel-title" style="margin-top:18px">Prompt / filtro interno</div>
      <div class="prompt-box">
        Este texto no se envía a ningún servicio externo.<br/><br/>
        CyberRad convierte el filtro de Marcas en una consulta local con aliases, sinónimos, exclusiones, scoring por incidente, validación de marca real y agrupación por país para el mapa.<br/><br/>
        Ejemplo: breach, ransomware, skimming, retail, fashion, ecommerce, -advice, -guide, -podcast.
      </div>
      <div class="prompt-footer">
        <button class="mini-btn dark">Prompt sincronizado</button>
        <button class="mini-btn green" onclick="loadDashboard(true)">Guardar / recargar</button>
      </div>
    </aside>

    <main class="main">
      <div class="toolbar panel">
        <div class="tabs">
          <button class="tab active" data-view="all">Todas</button>
          <button class="tab" data-view="general">General</button>
          <button class="tab purple" data-view="marcas">Marcas</button>
          <button class="tab" data-view="mapa">Mapa</button>
        </div>
        <div class="toolbar-right">
          <label class="small-note">Límite</label>
          <input class="select" id="limit" type="number" min="1" max="150" value="40" />
          <label class="small-note">Año</label>
          <select class="select" id="yearSelect"><option>2024</option><option>2025</option><option selected>2026</option></select>
          <button class="btn green" onclick="window.scrollTo({top:0,behavior:'smooth'})">Subir</button>
        </div>
      </div>

      <section class="panel map-card" id="mapSection">
        <div class="map-head">
          <div>
            <h2>Mapa anual · Marcas</h2>
            <p>Solo incidentes ciber válidos del sector textil, moda, lujo, retail y ecommerce detectados en la categoría Marcas. Los puntos se dibujan encima del mapa limpio y ya no vienen incrustados en la imagen.</p>
          </div>
          <div class="toolbar-right">
            <button class="btn green" onclick="downloadMapJson()">Descargar JSON</button>
          </div>
        </div>
        <div class="map-stats" id="mapStats"></div>
        <div class="map-grid">
          <div class="world" id="mapPanel">
            <img src="/static/map.png" alt="Mapa mundial oscuro" />
            <div class="tooltip" id="mapTooltip"></div>
          </div>
          <div class="side-stack">
            <div class="side-box">
              <h3>Top países</h3>
              <div id="topCountries" class="ranking"></div>
            </div>
            <div class="side-box">
              <h3>Tipos de incidente</h3>
              <div id="topIncidents" class="ranking"></div>
            </div>
          </div>
        </div>
      </section>

      <section class="panel section" id="generalSection">
        <div class="section-head">
          <div>
            <h2>Noticias generales de ciberseguridad</h2>
            <p>Noticias ciber relevantes fuera del filtro estricto de Marcas.</p>
          </div>
          <div class="small-note" id="generalCount"></div>
        </div>
        <div class="cards" id="cardsGeneral"></div>
      </section>

      <section class="panel section" id="marcasSection">
        <div class="section-head">
          <div>
            <h2>Últimos incidentes de Marcas</h2>
            <p>Solo víctimas válidas del sector textil / retail / moda / ecommerce con señal ciber real.</p>
          </div>
          <div class="small-note" id="marcasCount"></div>
        </div>
        <div class="cards" id="cardsMarcas"></div>
      </section>
    </main>
  </div>
</div>

<script>
let currentPayload = null;
const $ = (id) => document.getElementById(id);
const fmtNum = (v) => new Intl.NumberFormat('es-ES').format(Number(v || 0));
function esc(v){return String(v ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')}
function formatDate(v){if(!v) return 'sin fecha'; try{const d=new Date(v); if(isNaN(d)) return String(v).slice(0,16); return d.toLocaleString('es-ES')}catch{return String(v).slice(0,16)}}
function trimText(v, max=235){const t=String(v ?? ''); return t.length>max ? t.slice(0,max-1)+'…' : t}
function buildTags(item, mode){
  const tags=[];
  (item.incident_terms || []).slice(0,4).forEach(t=>tags.push(`<span class="tag">${esc(t)}</span>`));
  if(item.brand) tags.push(`<span class="tag">${esc(item.brand)}</span>`);
  if(mode==='general' && item.source) tags.push(`<span class="tag">${esc(item.source)}</span>`);
  if(item.score!=null) tags.push(`<span class="tag score">Score ${esc(item.score)}</span>`);
  return tags.join('');
}
function renderCard(item, mode){
  const badge = mode === 'marcas' ? '<span class="badge">Marcas</span>' : '<span class="badge general">General</span>';
  const source = esc(item.source || 'Fuente');
  const title = esc(item.title || 'Sin título');
  const summary = esc(trimText(item.summary || item.content || '', 250));
  const date = esc(formatDate(item.published));
  const country = esc(item.map_country_label || item.country_label || '');
  const article = esc(item.article_url || '#');
  const sem = item.semantic_score ?? item.score ?? 0;
  return `
  <article class="card">
    <div class="thumb"></div>
    <div class="card-body">
      <div class="source-row"><span>${source}</span>${badge}<span class="meta-mini">${country}</span><span class="meta-mini">Híbrido ${esc(Number(sem).toFixed ? Number(sem).toFixed(2) : sem)}</span></div>
      <div class="card-title">${title}</div>
      <div class="card-summary">${summary || 'Sin resumen.'}</div>
      <div class="tag-row">${buildTags(item, mode)}</div>
      <div class="small-note">${mode==='marcas' ? 'Filtro estricto de marca víctima + incidente real.' : 'Bloque general fuera del filtro estricto de Marcas.'}</div>
      <div class="card-bottom">
        <div class="date">${date}</div>
        <a class="btn green" style="min-height:46px;padding:0 18px" href="${article}" target="_blank" rel="noreferrer">Abrir noticia</a>
      </div>
    </div>
  </article>`;
}
function renderStatus(summary, meta){
  const items = [
    ['Total', summary.total_scanned],
    ['Feeds', meta.feed_count],
    ['Generales', summary.general_included],
    ['Marcas', summary.marcas_included],
    ['Países', summary.unique_countries],
    ['Caché', meta.cache_age_seconds + 's'],
  ];
  $('statusGrid').innerHTML = items.map(([k,v])=>`<div class="stat-box"><div class="stat-k">${esc(k)}</div><div class="stat-v">${esc(v)}</div></div>`).join('');
}
function renderMapStats(summary){
  const items = [
    ['Noticias Marcas', summary.marcas_included, 'Incluidas por filtro estricto'],
    ['Países', summary.unique_countries, 'Con punto en mapa'],
    ['En mapa', summary.showing_markers, 'Países visibles ahora'],
    ['Ventana', $('yearSelect').value, 'Vista temporal seleccionada'],
  ];
  $('mapStats').innerHTML = items.map(([k,v,s])=>`<div class="map-stat"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div><div class="small-note">${esc(s)}</div></div>`).join('');
}
function renderRanking(targetId, rows, fallback='Sin datos todavía.'){
  const el = $(targetId);
  if(!rows || !rows.length){ el.innerHTML = `<div class="empty">${esc(fallback)}</div>`; return; }
  el.innerHTML = rows.map(r => `<div class="rank-row"><div class="name">${esc(r.name)}</div><div class="num">${esc(r.count)}</div></div>`).join('');
}
function getTopIncidents(items){
  const counts = {};
  (items || []).forEach(item => (item.incident_terms || []).forEach(t => { const k=String(t||'').trim(); if(k) counts[k]=(counts[k]||0)+1; }));
  return Object.entries(counts).sort((a,b)=>b[1]-a[1] || a[0].localeCompare(b[0])).slice(0,8).map(([name,count])=>({name,count}));
}
function markerSize(count){
  const n = Number(count || 0);
  if(n >= 100) return 58;
  if(n >= 50) return 48;
  if(n >= 20) return 40;
  if(n >= 10) return 34;
  return 28;
}
function showTooltip(marker){
  const tip = $('mapTooltip');
  if(!tip) return;
  const brands = (marker.brands || []).slice(0,3).join(', ');
  const incidents = (marker.incident_terms || []).slice(0,3).join(', ');
  tip.innerHTML = `<div class="t1">${esc(marker.country_label || marker.country_iso2 || 'País')}</div><div class="t2">${esc(marker.count || 0)} incidente(s)</div><div class="t2">${brands ? 'Marcas: ' + esc(brands) : ''}</div><div class="t2">${incidents ? 'Tipos: ' + esc(incidents) : ''}</div>`;
  tip.style.left = ((marker.x_pct ?? 0.5) * 100).toFixed(2) + '%';
  tip.style.top = ((marker.y_pct ?? 0.5) * 100).toFixed(2) + '%';
  tip.classList.add('visible');
}
function hideTooltip(){ const tip = $('mapTooltip'); if(tip) tip.classList.remove('visible'); }
function renderMarkers(markers){
  const panel = $('mapPanel');
  panel.querySelectorAll('.marker,.empty').forEach(n => n.remove());
  hideTooltip();
  if(!markers || !markers.length){
    panel.insertAdjacentHTML('beforeend', `<div class="empty" style="position:absolute;left:18px;right:18px;bottom:18px">No hay datos suficientes para pintar el mapa todavía.</div>`);
    return;
  }
  markers.forEach((m) => {
    const count = Number(m.count || 0);
    const size = markerSize(count);
    const x = ((m.x_pct ?? 0.5) * 100).toFixed(2) + '%';
    const y = ((m.y_pct ?? 0.5) * 100).toFixed(2) + '%';
    const node = document.createElement('button');
    node.type = 'button';
    node.className = 'marker';
    node.style.left = x;
    node.style.top = y;
    node.style.width = size + 'px';
    node.style.height = size + 'px';
    node.innerHTML = `<span class="marker-count">${esc(count)}</span>`;
    node.title = `${m.country_label || m.country_iso2 || 'País'}: ${count}`;
    node.addEventListener('mouseenter', () => showTooltip(m));
    node.addEventListener('focus', () => showTooltip(m));
    node.addEventListener('mouseleave', hideTooltip);
    node.addEventListener('blur', hideTooltip);
    panel.appendChild(node);
  });
}
function setCards(generalItems, marcasItems){
  $('cardsGeneral').innerHTML = generalItems?.length ? generalItems.map(i => renderCard(i,'general')).join('') : `<div class="empty">No se encontraron noticias generales válidas.</div>`;
  $('cardsMarcas').innerHTML = marcasItems?.length ? marcasItems.map(i => renderCard(i,'marcas')).join('') : `<div class="empty">No hay incidentes válidos de Marcas todavía.</div>`;
  $('generalCount').textContent = `${generalItems?.length || 0} visibles`;
  $('marcasCount').textContent = `${marcasItems?.length || 0} visibles`;
}
async function loadDashboard(force){
  $('loader').classList.remove('hidden');
  try{
    const limit = Number($('limit').value || 40);
    const res = await fetch(`/api/dashboard?limit=${limit}&refresh=${force ? 1 : 0}`);
    const data = await res.json();
    currentPayload = data;
    renderStatus(data.summary, data.meta);
    renderMapStats(data.summary);
    renderRanking('topCountries', data.summary.top_countries, 'Sin países todavía.');
    renderRanking('topIncidents', getTopIncidents(data.marcas_items), 'Sin tipos de incidente todavía.');
    renderMarkers(data.map_markers || []);
    setCards(data.general_items || [], data.marcas_items || []);
    applyView(document.querySelector('.tab.active')?.dataset.view || 'all');
  }catch(e){
    $('cardsGeneral').innerHTML = `<div class="empty">Error cargando noticias generales.</div>`;
    $('cardsMarcas').innerHTML = `<div class="empty">Error cargando noticias de Marcas.</div>`;
  }finally{
    $('loader').classList.add('hidden');
  }
}
function applyView(view){
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.view === view));
  $('mapSection').classList.toggle('hidden', !(view === 'all' || view === 'marcas' || view === 'mapa'));
  $('generalSection').classList.toggle('hidden', !(view === 'all' || view === 'general'));
  $('marcasSection').classList.toggle('hidden', !(view === 'all' || view === 'marcas'));
}
function downloadMapJson(){
  if(!currentPayload) return;
  const blob = new Blob([JSON.stringify(currentPayload.map_markers || [], null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'cyberrad-marcas-map.json'; a.click();
  URL.revokeObjectURL(url);
}
document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => applyView(btn.dataset.view)));
loadDashboard(false);
</script>
</body>
</html>
""".strip()

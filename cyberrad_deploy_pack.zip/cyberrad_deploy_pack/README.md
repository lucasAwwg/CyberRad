# CyberRad - deploy pack

Este paquete añade despliegue Docker y pipeline GitHub Actions con *self-hosted runner*.

## Archivos incluidos
- `Dockerfile`
- `docker-compose.yml`
- `.github/workflows/deploy-self-hosted.yml`
- `deploy/install_docker_ubuntu.sh`
- `deploy/install_runner_mint.sh`
- `deploy/README_DEPLOY_ES.md`

## Cómo usarlo
1. Copia estos archivos en la raíz del proyecto CyberRad.
2. Asegúrate de tener `requirements.txt` y `app/main.py`.
3. Sube el repo a GitHub.
4. Da de alta el *self-hosted runner*.
5. Haz `push` a `main`.

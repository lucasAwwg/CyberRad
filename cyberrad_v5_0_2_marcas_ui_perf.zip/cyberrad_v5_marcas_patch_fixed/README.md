# CyberRad Marcas 5.0.2

Patch centrado en marcas del sector textil, retail, moda y ecommerce afectadas por incidentes de ciberseguridad.

## Mejoras incluidas

- UI rehecha con estética oscura más cercana al panel anterior
- Mapa global interactivo
- Loader profesional con animación en pantalla
- Caché en memoria para acelerar cargas repetidas
- Descarga concurrente de feeds para reducir tiempos de espera
- Puerto 3001
- `docker-compose.kali.yml` incluido

## Kali / Docker

```bash
cd ~
docker rm -f cyberrad-web 2>/dev/null || true
rm -rf ~/CyberRad
mkdir -p ~/CyberRad
cd ~/CyberRad

wget -O cyberrad_v5_0_2_marcas_ui_perf.zip "https://raw.githubusercontent.com/lucasAwwg/CyberRad/main/cyberrad_v5_0_2_marcas_ui_perf.zip"
unzip -o cyberrad_v5_0_2_marcas_ui_perf.zip
cd ~/CyberRad/cyberrad_v5_marcas_patch_fixed

docker compose -f docker-compose.kali.yml down --remove-orphans 2>/dev/null || true
docker rm -f cyberrad-web 2>/dev/null || true
docker compose -f docker-compose.kali.yml up -d --build
```

Abrir en navegador:

- http://127.0.0.1:3001

Endpoints:

- `/health`
- `/api/dashboard?limit=40`
- `/scan/marcas?limit=40`
- `/scan/map?limit=40`

from __future__ import annotations

import json
import re
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any
from urllib.parse import parse_qs, urlparse

import feedparser
import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse, JSONResponse, Response

from app.feed_builder import build_google_news_brand_queries
from app.filters import MarcasFilter
from app.map_builder import build_map_payload
from app.trusted_sources import DIRECT_SOURCE_FEEDS

USER_AGENT = "CyberRad/5.0 Marcas Textil UI+Perf Patch (+https://localhost)"
REQUEST_TIMEOUT = 10
CACHE_TTL_SECONDS = 900
MAX_SCAN_ITEMS = 500
APP_PORT = 3001

api = FastAPI(title="CyberRad Marcas 5.0.2", version="5.0.2")
filter_engine = MarcasFilter()

_cache_lock = threading.Lock()
_cache_payload: dict[str, Any] | None = None
_cache_generated_at = 0.0


@api.get("/", response_class=HTMLResponse)
def home() -> str:
    return build_home_html()


@api.get("/favicon.ico")
def favicon() -> Response:
    return Response(status_code=204)


@api.get("/health")
def health() -> dict[str, Any]:
    payload = get_dashboard_bundle(limit=40, force=False)
    return {
        "status": "ok",
        "service": "cyberrad-marcas",
        "version": "5.0.2",
        "port": APP_PORT,
        "cache_generated_at": payload["meta"]["generated_at"],
        "cache_age_seconds": payload["meta"]["cache_age_seconds"],
        "included": payload["summary"]["included"],
    }


@api.get("/api/dashboard")
def api_dashboard(limit: int = Query(default=40, ge=1, le=150), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    return JSONResponse(get_dashboard_bundle(limit=limit, force=bool(refresh)))


@api.get("/scan/marcas")
def scan_marcas(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["items"])


@api.get("/scan/map")
def scan_map(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["map_markers"])


@api.get("/scan/summary")
def scan_summary(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["summary"])


@api.get("/docs-quick", response_class=HTMLResponse)
def docs_quick() -> str:
    return """
    <html><body style='background:#08131d;color:#e8fff3;font-family:Arial;padding:24px'>
    <h1>CyberRad Marcas 5.0.2</h1>
    <p>Endpoints rápidos:</p>
    <ul>
      <li><a href='/health' style='color:#85ffb4'>/health</a></li>
      <li><a href='/api/dashboard?limit=40' style='color:#85ffb4'>/api/dashboard?limit=40</a></li>
      <li><a href='/scan/marcas?limit=40' style='color:#85ffb4'>/scan/marcas?limit=40</a></li>
      <li><a href='/scan/map?limit=40' style='color:#85ffb4'>/scan/map?limit=40</a></li>
      <li><a href='/docs' style='color:#85ffb4'>/docs</a></li>
    </ul>
    </body></html>
    """.strip()


def get_dashboard_bundle(limit: int, force: bool = False) -> dict[str, Any]:
    payload = get_or_refresh_cache(force=force)
    generated_at = payload["generated_at"]
    included_items = payload["included_items"][:limit]
    map_markers = payload["map_markers"]
    if len(map_markers) > limit:
        map_markers = map_markers[:limit]

    summary = dict(payload["summary"])
    summary["showing_items"] = len(included_items)
    summary["showing_markers"] = len(map_markers)

    cache_age = max(0, int(time.time() - generated_at))
    return {
        "meta": {
            "generated_at": isoformat_from_ts(generated_at),
            "cache_age_seconds": cache_age,
            "cache_ttl_seconds": CACHE_TTL_SECONDS,
            "cache_hit": not force,
            "feed_count": payload["feed_count"],
        },
        "summary": summary,
        "items": included_items,
        "map_markers": map_markers,
    }


def get_or_refresh_cache(force: bool = False) -> dict[str, Any]:
    global _cache_payload, _cache_generated_at
    now = time.time()
    with _cache_lock:
        if not force and _cache_payload and (now - _cache_generated_at) < CACHE_TTL_SECONDS:
            return _cache_payload

    payload = build_fresh_payload()

    with _cache_lock:
        _cache_payload = payload
        _cache_generated_at = payload["generated_at"]
        return _cache_payload


def build_fresh_payload() -> dict[str, Any]:
    feeds = DIRECT_SOURCE_FEEDS + build_google_news_brand_queries()
    raw_items = fetch_all_feeds(feeds)
    deduped = dedupe_items(raw_items)
    decisions = [
        filter_engine.classify(item).to_dict() | {"published": item.get("published")}
        for item in deduped
    ]
    decisions.sort(key=lambda item: (item["include"], item["score"], item.get("published") or ""), reverse=True)

    included = [item for item in decisions if item.get("include")]
    summary = build_summary(decisions, included)

    payload = {
        "generated_at": time.time(),
        "feed_count": len(feeds),
        "all_items": decisions[:MAX_SCAN_ITEMS],
        "included_items": included[:MAX_SCAN_ITEMS],
        "map_markers": build_map_payload(included[:MAX_SCAN_ITEMS]),
        "summary": summary,
    }
    return payload


def fetch_all_feeds(feeds: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not feeds:
        return []
    max_workers = min(12, max(4, len(feeds)))
    items: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(fetch_feed, feed) for feed in feeds]
        for future in as_completed(futures):
            try:
                items.extend(future.result())
            except Exception:
                continue
    return items


def fetch_feed(feed: dict[str, Any]) -> list[dict[str, Any]]:
    headers = {"User-Agent": USER_AGENT}
    try:
        response = requests.get(feed["url"], headers=headers, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        parsed = feedparser.parse(response.content)
    except Exception:
        return []

    items: list[dict[str, Any]] = []
    for entry in parsed.entries:
        article_url = extract_article_url(entry.get("link", ""))
        title = clean_html(entry.get("title", ""))
        summary = clean_html(entry.get("summary", ""))
        content = ""
        if entry.get("content"):
            first = entry["content"][0]
            content = clean_html(first.get("value", ""))
        source = feed.get("name")
        if entry.get("source") and isinstance(entry["source"], dict):
            source = entry["source"].get("title") or source
        published = normalize_published(entry)
        items.append(
            {
                "title": title,
                "summary": summary,
                "content": content,
                "url": entry.get("link", ""),
                "article_url": article_url,
                "source": source,
                "publisher_domain": urlparse(article_url if article_url else feed["url"]).netloc,
                "published": published,
                "discovery_only_source": bool(feed.get("discovery_only")),
            }
        )
    return items


def build_summary(all_items: list[dict[str, Any]], included_items: list[dict[str, Any]]) -> dict[str, Any]:
    unique_brands = sorted({item.get("brand") for item in included_items if item.get("brand")})
    unique_countries = sorted({item.get("map_country_label") for item in included_items if item.get("map_country_label")})
    return {
        "total_scanned": len(all_items),
        "included": len(included_items),
        "excluded_or_pending": max(0, len(all_items) - len(included_items)),
        "unique_brands": len(unique_brands),
        "unique_countries": len(unique_countries),
        "top_brands": top_counts(included_items, "brand"),
        "top_countries": top_counts(included_items, "map_country_label"),
        "top_sources": top_counts(included_items, "source"),
    }


def top_counts(items: list[dict[str, Any]], key: str, limit: int = 8) -> list[dict[str, Any]]:
    counts: dict[str, int] = {}
    for item in items:
        value = str(item.get(key) or "").strip()
        if not value:
            continue
        counts[value] = counts.get(value, 0) + 1
    ordered = sorted(counts.items(), key=lambda x: (-x[1], x[0]))
    return [{"name": name, "count": count} for name, count in ordered[:limit]]


def dedupe_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: OrderedDict[str, dict[str, Any]] = OrderedDict()
    for item in items:
        key = make_key(item)
        if key not in seen:
            seen[key] = item
    return list(seen.values())


def make_key(item: dict[str, Any]) -> str:
    title = re.sub(r"\s+", " ", (item.get("title") or "").lower()).strip()
    article_url = (item.get("article_url") or "").strip().lower()
    return article_url or title


def extract_article_url(url: str) -> str:
    if not url:
        return ""
    parsed = urlparse(url)
    if "news.google.com" not in parsed.netloc:
        return url
    qs = parse_qs(parsed.query)
    direct = qs.get("url")
    if direct:
        return direct[0]
    return url


def clean_html(value: str) -> str:
    if not value:
        return ""
    soup = BeautifulSoup(value, "html.parser")
    text = soup.get_text(" ", strip=True)
    return re.sub(r"\s+", " ", text).strip()


def normalize_published(entry: Any) -> str:
    if getattr(entry, "published_parsed", None):
        dt = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
        return dt.isoformat()
    if entry.get("published"):
        return str(entry.get("published"))
    return ""


def isoformat_from_ts(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


def build_home_html() -> str:
    return """
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CyberRad Marcas 5.0.2</title>
  <meta name="theme-color" content="#06111a">
  <style>
    :root{
      --bg:#06111a;
      --panel:#0b1521;
      --panel-2:#0d1b29;
      --panel-3:#0a1320;
      --line:#15354b;
      --line-soft:rgba(82,255,170,.15);
      --text:#eafcf2;
      --muted:#9cb8c6;
      --accent:#23d76b;
      --accent-2:#7dffb3;
      --danger:#ff6b6b;
      --shadow:0 0 0 1px rgba(125,255,179,.06), 0 18px 60px rgba(0,0,0,.35);
      --radius:20px;
    }
    *{box-sizing:border-box}
    html,body{margin:0;padding:0;background:radial-gradient(circle at top,#0d2131 0%, #06111a 38%, #040b11 100%);color:var(--text);font-family:Inter,Arial,Helvetica,sans-serif}
    a{color:inherit}
    .app{max-width:1520px;margin:0 auto;padding:20px 14px 48px}
    .topbar{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px;padding:12px 16px;border:1px solid var(--line-soft);background:rgba(8,18,28,.7);backdrop-filter:blur(12px);border-radius:18px;box-shadow:var(--shadow)}
    .brand{display:flex;align-items:center;gap:14px}
    .brand-badge{width:44px;height:44px;border-radius:14px;background:radial-gradient(circle at 30% 30%,rgba(125,255,179,.35),rgba(35,215,107,.18) 32%,rgba(35,215,107,.02) 70%);border:1px solid rgba(125,255,179,.35);display:grid;place-items:center;box-shadow:0 0 24px rgba(35,215,107,.15)}
    .brand-badge:before{content:"";width:18px;height:18px;border:3px solid var(--accent-2);border-radius:50%;box-shadow:0 0 18px rgba(125,255,179,.4)}
    .brand h1{font-size:18px;margin:0 0 3px 0;letter-spacing:.2px}
    .brand p{margin:0;color:var(--muted);font-size:13px}
    .top-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
    .chip{padding:10px 14px;border-radius:999px;border:1px solid rgba(125,255,179,.2);background:#0b1722;color:#d7f9e5;font-weight:700;font-size:13px;cursor:pointer;transition:.18s ease;text-decoration:none}
    .chip:hover{transform:translateY(-1px);border-color:rgba(125,255,179,.45)}
    .chip.primary{background:linear-gradient(180deg,#24dd6f,#18ba58);color:#04110a;border-color:rgba(255,255,255,.08)}
    .hero{margin-bottom:18px;padding:22px;border-radius:24px;background:linear-gradient(180deg,rgba(6,21,30,.96),rgba(5,14,22,.98));border:1px solid var(--line-soft);box-shadow:var(--shadow)}
    .hero-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;align-items:start}
    .hero h2{margin:0 0 10px 0;font-size:22px;color:var(--accent-2)}
    .hero p{margin:0 0 14px 0;color:#d8eaf4;line-height:1.5}
    .bullet-row{display:flex;gap:10px;flex-wrap:wrap}
    .pill{padding:9px 12px;border-radius:999px;border:1px solid rgba(125,255,179,.18);background:#0a1520;color:#bbd8e7;font-size:12px;font-weight:700}
    .control-box{display:flex;flex-wrap:wrap;gap:10px;align-items:end;justify-content:flex-end}
    .field{display:flex;flex-direction:column;gap:8px;min-width:130px}
    .field label{font-size:12px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.08em}
    .field input{height:46px;background:#08131d;border:1px solid #224056;border-radius:14px;color:#fff;padding:0 14px;font-size:16px;outline:none}
    .btn{height:46px;padding:0 18px;border:none;border-radius:14px;font-weight:800;cursor:pointer;transition:.18s ease;background:#1a2636;color:#d8ebf6;border:1px solid #29445e}
    .btn:hover{transform:translateY(-1px)}
    .btn.primary{background:linear-gradient(180deg,#28df73,#1bc35f);color:#031108;border-color:rgba(255,255,255,.06);box-shadow:0 10px 30px rgba(23,215,96,.18)}
    .stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:18px}
    .stat{padding:18px;border-radius:20px;background:linear-gradient(180deg,#0b1724,#0a1520);border:1px solid var(--line-soft);box-shadow:var(--shadow);min-height:122px}
    .stat .k{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;font-weight:800;margin-bottom:12px}
    .stat .v{font-size:36px;line-height:1;margin-bottom:8px;color:var(--accent-2);font-weight:900}
    .stat .s{font-size:13px;color:#bfd4df}
    .main-grid{display:grid;grid-template-columns:1.5fr .95fr;gap:18px;align-items:start}
    .panel{background:linear-gradient(180deg,#0a1520,#09131d);border:1px solid var(--line-soft);box-shadow:var(--shadow);border-radius:24px;overflow:hidden}
    .panel-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 18px 0 18px}
    .panel h3{margin:0;font-size:28px;color:#f0fff6;line-height:1.1}
    .sub{color:var(--muted);font-size:13px}
    .map-wrap{padding:12px 16px 16px 16px}
    #map{height:500px;width:100%;border-radius:18px;overflow:hidden;background:radial-gradient(circle at top,rgba(18,44,60,.8),rgba(4,9,14,.96));border:1px solid rgba(255,255,255,.06)}
    .map-fallback{height:500px;display:none;align-items:center;justify-content:center;text-align:center;padding:20px;color:#bdd7e8}
    .side-stack{display:grid;gap:18px}
    .meta-list,.source-list{padding:16px 18px 18px}
    .mini-list{display:grid;gap:12px}
    .mini-item{display:flex;justify-content:space-between;gap:10px;align-items:center;padding:12px 14px;border-radius:16px;background:#091420;border:1px solid rgba(255,255,255,.05)}
    .mini-item .name{font-weight:700;color:#edfef4}
    .mini-item .count{min-width:42px;height:32px;display:grid;place-items:center;border-radius:999px;background:rgba(35,215,107,.18);color:var(--accent-2);font-weight:900}
    .news-section{margin-top:18px}
    .section-head{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:12px}
    .section-head h3{margin:0;font-size:22px}
    .cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px}
    .card{background:linear-gradient(180deg,#10192b,#0a1220);border:1px solid rgba(134,227,178,.12);border-radius:22px;overflow:hidden;position:relative;min-height:320px;display:flex;flex-direction:column;box-shadow:var(--shadow)}
    .card .cover{height:170px;background:radial-gradient(circle at 20% 20%,rgba(207,0,255,.26),transparent 23%),radial-gradient(circle at 70% 30%,rgba(41,151,255,.22),transparent 28%),linear-gradient(135deg,#021424,#0b1530 50%,#12152a 100%);position:relative;border-bottom:1px solid rgba(255,255,255,.05)}
    .card .cover:after{content:"";position:absolute;inset:18px;border-radius:18px;border:1px solid rgba(125,255,179,.08);background:linear-gradient(120deg,rgba(255,255,255,.06),transparent 38%,rgba(0,255,175,.05));box-shadow:inset 0 0 40px rgba(0,0,0,.28)}
    .card-body{padding:16px;display:flex;flex-direction:column;gap:12px;height:100%}
    .meta-line{display:flex;align-items:center;gap:10px;flex-wrap:wrap;color:#b6cad6;font-size:13px}
    .badge{padding:8px 12px;border-radius:999px;background:rgba(91,47,159,.35);border:1px solid rgba(162,107,255,.28);font-size:12px;font-weight:800;color:#e4d7ff}
    .badge.green{background:rgba(35,215,107,.16);border-color:rgba(35,215,107,.26);color:#95ffc0}
    .badge.yellow{background:rgba(255,193,7,.12);border-color:rgba(255,193,7,.2);color:#ffd76b}
    .title{font-size:18px;line-height:1.3;font-weight:900;color:#f3fff7}
    .excerpt{font-size:14px;line-height:1.6;color:#d7e8f2;flex:1}
    .tag-row{display:flex;gap:8px;flex-wrap:wrap}
    .tag{padding:8px 10px;border-radius:999px;background:#071a17;border:1px solid rgba(35,215,107,.2);font-size:12px;color:#b7f6cf;font-weight:700}
    .foot{display:flex;justify-content:space-between;gap:12px;align-items:center;color:#aac0cf;font-size:13px}
    .foot a{text-decoration:none}
    .card-link{display:inline-flex;align-items:center;gap:8px;padding:11px 14px;border-radius:14px;background:#1bd06a;color:#03150a;font-weight:900;text-decoration:none}
    .loader-overlay{position:fixed;inset:0;background:rgba(2,8,12,.84);backdrop-filter:blur(14px);display:flex;align-items:center;justify-content:center;z-index:999;transition:.24s ease}
    .loader-overlay.hidden{opacity:0;pointer-events:none}
    .loader-box{width:min(480px,92vw);padding:28px;border-radius:24px;background:linear-gradient(180deg,#081521,#060f17);border:1px solid rgba(125,255,179,.22);box-shadow:0 30px 90px rgba(0,0,0,.45);text-align:center}
    .loader-ring{width:68px;height:68px;margin:0 auto 18px;border-radius:50%;border:4px solid rgba(125,255,179,.12);border-top-color:var(--accent-2);animation:spin 1s linear infinite;box-shadow:0 0 26px rgba(35,215,107,.18)}
    .loader-title{font-size:24px;font-weight:900;color:#f2fff7;margin-bottom:8px}
    .loader-text{color:#c4d9e6;line-height:1.5}
    .loader-bar{height:10px;background:#0a1722;border-radius:999px;overflow:hidden;margin-top:18px;border:1px solid rgba(255,255,255,.06)}
    .loader-bar span{display:block;height:100%;width:38%;background:linear-gradient(90deg,#0f5,#8fffc6);border-radius:999px;animation:progress 1.6s ease-in-out infinite}
    .skeleton-card{min-height:320px;border-radius:22px;background:linear-gradient(90deg,#0a1320 20%,#112034 38%,#0a1320 54%);background-size:200% 100%;animation:shine 1.5s linear infinite;border:1px solid rgba(255,255,255,.04)}
    .muted-note{color:var(--muted);font-size:12px}
    @keyframes spin{to{transform:rotate(360deg)}}
    @keyframes progress{0%{transform:translateX(-120%)}50%{transform:translateX(120%)}100%{transform:translateX(240%)}}
    @keyframes shine{to{background-position:-200% 0}}
    @media (max-width:1200px){.main-grid{grid-template-columns:1fr}.hero-grid{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,1fr)}}
    @media (max-width:720px){.stats{grid-template-columns:1fr}.cards{grid-template-columns:1fr}.topbar{padding:12px}.panel h3{font-size:22px}.hero{padding:18px}#map,.map-fallback{height:380px}}
  </style>
</head>
<body>
  <div class="loader-overlay" id="loader">
    <div class="loader-box">
      <div class="loader-ring"></div>
      <div class="loader-title">Cargando CyberRad Marcas</div>
      <div class="loader-text" id="loaderText">Consultando feeds fiables, cruzando marcas textiles y preparando el mapa global.</div>
      <div class="loader-bar"><span></span></div>
    </div>
  </div>

  <div class="app">
    <div class="topbar">
      <div class="brand">
        <div class="brand-badge"></div>
        <div>
          <h1>CyberRad · Marcas 5.0.2</h1>
          <p>Monitor textil / retail / moda / ecommerce con mapa global y caché rápida.</p>
        </div>
      </div>
      <div class="top-actions">
        <a class="chip" href="/health" target="_blank">Health</a>
        <a class="chip" href="/docs" target="_blank">Docs</a>
        <button class="chip primary" id="refreshTop">Refrescar ahora</button>
      </div>
    </div>

    <section class="hero">
      <div class="hero-grid">
        <div>
          <h2>Últimos incidentes de Marcas</h2>
          <p>Filtra noticias de ciberseguridad enfocadas en marcas reales del sector textil, retail, moda y ecommerce. Solo muestra víctimas concretas con incidente claro y dominio HTTPS confiable.</p>
          <div class="bullet-row">
            <div class="pill">Marcas reales</div>
            <div class="pill">Mapa centrado por país</div>
            <div class="pill">Caché para ir más rápido</div>
            <div class="pill">Carga profesional con animación</div>
          </div>
        </div>
        <div class="control-box">
          <div class="field">
            <label for="limit">Límite</label>
            <input id="limit" type="number" min="10" max="120" step="10" value="40">
          </div>
          <button class="btn primary" id="loadBtn">Cargar panel</button>
          <button class="btn" id="refreshBtn">Forzar refresh</button>
        </div>
      </div>
    </section>

    <section class="stats" id="stats">
      <div class="stat"><div class="k">Noticias incluidas</div><div class="v">—</div><div class="s">Esperando carga</div></div>
      <div class="stat"><div class="k">Marcas detectadas</div><div class="v">—</div><div class="s">Esperando carga</div></div>
      <div class="stat"><div class="k">Países con incidentes</div><div class="v">—</div><div class="s">Esperando carga</div></div>
      <div class="stat"><div class="k">Última actualización</div><div class="v" style="font-size:22px">—</div><div class="s">Esperando carga</div></div>
    </section>

    <section class="main-grid">
      <div class="panel">
        <div class="panel-head">
          <div>
            <h3>Mapa global de incidentes</h3>
            <div class="sub">Los puntos se colocan por centro visual del país y se dibujan sobre mapa mundial oscuro.</div>
          </div>
          <div class="sub" id="cacheMeta">Sin datos todavía</div>
        </div>
        <div class="map-wrap">
          <div id="map"></div>
          <div class="map-fallback" id="mapFallback">No se pudo cargar el mapa interactivo. La API sigue funcionando y las tarjetas están disponibles abajo.</div>
        </div>
      </div>

      <div class="side-stack">
        <div class="panel">
          <div class="panel-head"><div><h3 style="font-size:22px">Top marcas</h3><div class="sub">Más incidentes detectados</div></div></div>
          <div class="meta-list"><div class="mini-list" id="brandsList"></div></div>
        </div>
        <div class="panel">
          <div class="panel-head"><div><h3 style="font-size:22px">Top fuentes</h3><div class="sub">Dominios que aportaron noticias válidas</div></div></div>
          <div class="source-list"><div class="mini-list" id="sourcesList"></div></div>
        </div>
      </div>
    </section>

    <section class="news-section">
      <div class="section-head">
        <div>
          <h3>Noticias incluidas en Marcas</h3>
          <div class="sub">Solo víctimas válidas del sector textil / retail / moda / ecommerce.</div>
        </div>
        <div class="muted-note" id="newsMeta">Pendiente de carga</div>
      </div>
      <div class="cards" id="cards"></div>
    </section>
  </div>

  <script src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>
  <script>
    const loader = document.getElementById('loader');
    const loaderText = document.getElementById('loaderText');
    const limitInput = document.getElementById('limit');
    const cardsEl = document.getElementById('cards');
    const brandsList = document.getElementById('brandsList');
    const sourcesList = document.getElementById('sourcesList');
    const cacheMeta = document.getElementById('cacheMeta');
    const newsMeta = document.getElementById('newsMeta');
    const mapFallback = document.getElementById('mapFallback');
    const loaderMessages = [
      'Consultando feeds fiables y cacheando resultados…',
      'Cruzando marcas textiles con incidentes reales…',
      'Preparando el mapa global y las tarjetas de noticias…'
    ];
    let loaderIdx = 0;
    let msgTimer = null;

    function startLoader(){
      loader.classList.remove('hidden');
      loaderText.textContent = loaderMessages[0];
      if (msgTimer) clearInterval(msgTimer);
      msgTimer = setInterval(() => {
        loaderIdx = (loaderIdx + 1) % loaderMessages.length;
        loaderText.textContent = loaderMessages[loaderIdx];
      }, 1200);
      renderSkeletons();
    }

    function stopLoader(){
      loader.classList.add('hidden');
      if (msgTimer) clearInterval(msgTimer);
    }

    function renderSkeletons(){
      cardsEl.innerHTML = '';
      for (let i = 0; i < 6; i++) {
        const div = document.createElement('div');
        div.className = 'skeleton-card';
        cardsEl.appendChild(div);
      }
      brandsList.innerHTML = '<div class="mini-item"><div class="name">Cargando…</div><div class="count">…</div></div>';
      sourcesList.innerHTML = '<div class="mini-item"><div class="name">Cargando…</div><div class="count">…</div></div>';
    }

    function escapeHtml(value){
      return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    }

    function fmtDate(value){
      if (!value) return 'Sin fecha';
      try {
        return new Date(value).toLocaleString('es-ES');
      } catch (e) {
        return value;
      }
    }

    function shortText(text, max=220){
      if (!text) return 'Sin resumen disponible.';
      return text.length > max ? text.slice(0,max).trim() + '…' : text;
    }

    function renderStats(summary, meta){
      const generated = fmtDate(meta.generated_at);
      document.getElementById('stats').innerHTML = `
        <div class="stat"><div class="k">Noticias incluidas</div><div class="v">${summary.included}</div><div class="s">Mostrando ${summary.showing_items} tarjetas</div></div>
        <div class="stat"><div class="k">Marcas detectadas</div><div class="v">${summary.unique_brands}</div><div class="s">Solo marcas válidas del sector</div></div>
        <div class="stat"><div class="k">Países con incidentes</div><div class="v">${summary.unique_countries}</div><div class="s">Marcadores en el mapa</div></div>
        <div class="stat"><div class="k">Última actualización</div><div class="v" style="font-size:22px">${generated}</div><div class="s">Caché ${meta.cache_age_seconds}s · feeds ${meta.feed_count}</div></div>
      `;
      cacheMeta.textContent = `Actualizado ${generated} · caché ${meta.cache_age_seconds}s`;
      newsMeta.textContent = `${summary.included} noticias válidas · ${summary.unique_brands} marcas · ${summary.unique_countries} países`;
    }

    function renderMiniList(target, rows, emptyText){
      if (!rows || !rows.length) {
        target.innerHTML = `<div class="mini-item"><div class="name">${emptyText}</div><div class="count">0</div></div>`;
        return;
      }
      target.innerHTML = rows.map(row => `
        <div class="mini-item">
          <div class="name">${escapeHtml(row.name)}</div>
          <div class="count">${escapeHtml(row.count)}</div>
        </div>
      `).join('');
    }

    function renderCards(items){
      if (!items || !items.length) {
        cardsEl.innerHTML = '<div class="panel" style="padding:22px">No hay noticias incluidas ahora mismo. Prueba con refresh o sube el límite.</div>';
        return;
      }
      cardsEl.innerHTML = items.map(item => {
        const tags = [...(item.incident_terms || []).slice(0,4), item.brand, item.sector].filter(Boolean).slice(0,6);
        const rationale = (item.rationale || []).slice(0,2).join(' · ');
        const excerpt = shortText(item.summary || item.title || rationale, 220);
        return `
          <article class="card">
            <div class="cover"></div>
            <div class="card-body">
              <div class="meta-line">
                <span>${escapeHtml(item.source || 'Fuente desconocida')}</span>
                <span class="badge">Marcas</span>
                <span>${escapeHtml(item.brand_country_label || item.map_country_label || 'Sin país')}</span>
              </div>
              <div class="title">${escapeHtml(item.title || 'Sin título')}</div>
              <div class="excerpt">${escapeHtml(excerpt)}</div>
              <div class="tag-row">${tags.map(tag => `<span class="tag">${escapeHtml(tag)}</span>`).join('')}</div>
              <div class="meta-line">
                <span class="badge green">${escapeHtml(item.brand || 'Marca')}</span>
                <span class="badge yellow">Score ${escapeHtml(item.score)}</span>
              </div>
              <div class="foot">
                <span>${escapeHtml(fmtDate(item.published))}</span>
                <a class="card-link" href="${escapeHtml(item.article_url || '#')}" target="_blank" rel="noopener noreferrer">Abrir noticia</a>
              </div>
            </div>
          </article>
        `;
      }).join('');
    }

    function renderMap(markers){
      if (!window.Plotly) {
        document.getElementById('map').style.display = 'none';
        mapFallback.style.display = 'flex';
        return;
      }
      document.getElementById('map').style.display = 'block';
      mapFallback.style.display = 'none';
      const rows = markers || [];
      const data = [{
        type: 'scattergeo',
        mode: 'markers+text',
        lon: rows.map(r => r.lng),
        lat: rows.map(r => r.lat),
        text: rows.map(r => `${r.country_label}<br>${r.count}`),
        hovertemplate: rows.map(r => {
          const brands = (r.brands || []).slice(0,6).join(', ');
          return `<b>${r.country_label}</b><br>Incidentes: ${r.count}<br>Marcas: ${brands || '—'}<extra></extra>`;
        }),
        textposition: 'top center',
        textfont: {color:'#eafff1', size:12},
        marker: {
          size: rows.map(r => Math.max(16, Math.min(48, 14 + r.count * 4))),
          color: 'rgba(38,220,110,0.95)',
          line: {color:'rgba(210,255,228,0.95)', width:1.5},
          opacity: 0.92
        }
      }];
      const layout = {
        margin: {l:0,r:0,t:0,b:0},
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        geo: {
          projection: {type:'equirectangular'},
          bgcolor: 'rgba(0,0,0,0)',
          showframe: false,
          showcoastlines: true,
          coastlinecolor: '#d7dee6',
          showcountries: true,
          countrycolor: '#d7dee6',
          showland: true,
          landcolor: '#05090d',
          showocean: true,
          oceancolor: '#000000',
          lataxis: {range:[-58,85]},
        }
      };
      Plotly.react('map', data, layout, {displayModeBar:false, responsive:true});
    }

    async function loadDashboard(forceRefresh=false){
      startLoader();
      const limit = Number(limitInput.value || 40);
      const url = `/api/dashboard?limit=${encodeURIComponent(limit)}&refresh=${forceRefresh ? 1 : 0}`;
      try {
        const res = await fetch(url, {headers:{'Accept':'application/json'}});
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        renderStats(data.summary, data.meta);
        renderMiniList(brandsList, data.summary.top_brands, 'Sin marcas todavía');
        renderMiniList(sourcesList, data.summary.top_sources, 'Sin fuentes todavía');
        renderCards(data.items);
        renderMap(data.map_markers);
      } catch (err) {
        cardsEl.innerHTML = `<div class="panel" style="padding:22px;border-color:rgba(255,107,107,.3)">Error cargando datos: ${escapeHtml(err.message || err)}</div>`;
        brandsList.innerHTML = '<div class="mini-item"><div class="name">Error de carga</div><div class="count">!</div></div>';
        sourcesList.innerHTML = '<div class="mini-item"><div class="name">Error de carga</div><div class="count">!</div></div>';
        mapFallback.style.display = 'flex';
      } finally {
        stopLoader();
      }
    }

    document.getElementById('loadBtn').addEventListener('click', () => loadDashboard(false));
    document.getElementById('refreshBtn').addEventListener('click', () => loadDashboard(true));
    document.getElementById('refreshTop').addEventListener('click', () => loadDashboard(true));
    window.addEventListener('load', () => loadDashboard(false));
  </script>
</body>
</html>
    """.strip()


if __name__ == "__main__":
    output = build_fresh_payload()
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = f"/app/out/marcas_scan_{ts}.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(output, fh, ensure_ascii=False, indent=2)
    print(path)

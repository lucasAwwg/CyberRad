from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import unquote, urlparse, quote_plus

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / 'cyberrad_v4.db'



def google_news_rss(query: str, hl: str = "en-US", gl: str = "US", ceid: str = "US:en") -> str:
    return f"https://news.google.com/rss/search?q={quote_plus(query)}&hl={hl}&gl={gl}&ceid={ceid}"


def year_bounded_query(query: str, year: int) -> str:
    next_year = year + 1
    return f"{query} after:{year}-01-01 before:{next_year}-01-01"


def _site_query(name: str, sites: str, sector_terms: str, cyber_terms: str, *, hl: str = "en-US", gl: str = "US", ceid: str = "US:en") -> tuple[str, str]:
    query = f"({sites}) ({sector_terms}) ({cyber_terms})"
    return (name, google_news_rss(query, hl=hl, gl=gl, ceid=ceid))


def brand_discovery_feeds() -> list[tuple[str, str]]:
    cyber_en = 'cyberattack OR "data breach" OR ransomware OR malware OR phishing OR hacked OR breach OR compromise OR "security incident" OR "credential theft" OR magecart OR "payment breach"'
    cyber_es = 'ciberataque OR "brecha de datos" OR ransomware OR malware OR phishing OR hackeo OR filtración OR filtracion OR "incidente de ciberseguridad" OR "robo de credenciales" OR "compromiso de pagos"'
    cyber_fr = 'cyberattaque OR "violation de données" OR rançongiciel OR ransomware OR malware OR phishing OR piratage'
    cyber_de = 'cyberangriff OR datenleck OR ransomware OR malware OR phishing OR kompromittiert'
    cyber_it = 'attacco informatico OR violazione dei dati OR ransomware OR malware OR phishing'
    cyber_pt = 'ciberataque OR violação de dados OR ransomware OR malware OR phishing'

    sector_global = 'fashion OR apparel OR clothing OR textile OR luxury OR footwear OR retailer OR ecommerce OR webshop OR marketplace OR boutique OR brand OR store OR shop OR retail OR direct-to-consumer OR dtc'
    sector_es = 'moda OR textil OR ropa OR lujo OR calzado OR retail OR ecommerce OR marca OR marcas OR tienda OR tiendas OR boutique OR marketplace OR "tiendas de ropa" OR "retail de moda"'
    sector_fr = 'mode OR textile OR luxe OR habillement OR chaussure OR commerce OR ecommerce OR marque OR magasin'
    sector_de = 'mode OR textil OR luxus OR bekleidung OR schuhe OR einzelhandel OR ecommerce OR marke OR shop'
    sector_it = 'moda OR tessile OR lusso OR abbigliamento OR calzature OR retail OR ecommerce OR marchio OR negozio'
    sector_pt = 'moda OR têxtil OR luxo OR vestuário OR calçado OR varejo OR ecommerce OR marca OR loja'

    direct_brand_names = 'zara OR mango OR "h&m" OR nike OR adidas OR puma OR primark OR decathlon OR asos OR shein OR boohoo OR prettylittlething OR farfetch OR yoox OR "net-a-porter" OR zalando OR uniqlo OR revolve OR ssense OR mytheresa OR vinted OR stockx OR goat OR "urban outfitters"'

    feeds: list[tuple[str, str]] = [
        ("Google News - Global Fashion Retail Cyber", google_news_rss(f'({sector_global}) ({cyber_en})')),
        ("Google News - Global Fashion Retail Cyber Brands", google_news_rss(f'({direct_brand_names}) ({cyber_en})')),
        ("Google News - Fashion Ecommerce Incidents", google_news_rss(f'("online fashion retailer" OR "online clothing store" OR "fashion ecommerce" OR "fashion webshop" OR "digital fashion marketplace" OR "streetwear ecommerce" OR "sneaker marketplace" OR ecommerce OR webshop OR marketplace) ({cyber_en})')),
        ("Google News - Retail Payments and Magecart", google_news_rss(f'(retail OR retailer OR store OR webshop OR marketplace OR checkout OR online store) ("payment breach" OR magecart OR "payment skimmer" OR "customer data" OR "credential theft" OR fraud) (fashion OR apparel OR clothing OR luxury OR footwear OR textile OR brand)')),
        ("Google News - Moda y Textil Ciber ES", google_news_rss(f'({sector_es}) ({cyber_es})', hl='es-419', gl='ES', ceid='ES:es')),
        ("Google News - France Mode Cyber", google_news_rss(f'({sector_fr}) ({cyber_fr})', hl='fr', gl='FR', ceid='FR:fr')),
        ("Google News - Germany Retail Cyber", google_news_rss(f'({sector_de}) ({cyber_de})', hl='de', gl='DE', ceid='DE:de')),
        ("Google News - Italy Moda Cyber", google_news_rss(f'({sector_it}) ({cyber_it})', hl='it', gl='IT', ceid='IT:it')),
        ("Google News - Portugal Moda Cyber", google_news_rss(f'({sector_pt}) ({cyber_pt})', hl='pt-PT', gl='PT', ceid='PT:pt-150')),
        _site_query('Google News - BBC Fashion Cyber', 'site:bbc.com OR site:bbc.co.uk', sector_global, cyber_en),
        _site_query('Google News - The Guardian Fashion Cyber', 'site:theguardian.com', sector_global, cyber_en),
        _site_query('Google News - The Independent Fashion Cyber', 'site:independent.co.uk', sector_global, cyber_en),
        _site_query('Google News - Financial Times Retail Cyber', 'site:ft.com', sector_global, cyber_en),
        _site_query('Google News - Telegraph Retail Cyber', 'site:telegraph.co.uk', sector_global, cyber_en),
        _site_query('Google News - El Pais Moda Ciber', 'site:elpais.com', sector_es, cyber_es, hl='es-419', gl='ES', ceid='ES:es'),
        _site_query('Google News - El Mundo Moda Ciber', 'site:elmundo.es', sector_es, cyber_es, hl='es-419', gl='ES', ceid='ES:es'),
        _site_query('Google News - La Vanguardia Moda Ciber', 'site:lavanguardia.com', sector_es, cyber_es, hl='es-419', gl='ES', ceid='ES:es'),
        _site_query('Google News - elDiario Moda Ciber', 'site:eldiario.es', sector_es, cyber_es, hl='es-419', gl='ES', ceid='ES:es'),
        _site_query('Google News - Expansion Retail Ciber', 'site:expansion.com', sector_es, cyber_es, hl='es-419', gl='ES', ceid='ES:es'),
        _site_query('Google News - Marca Retail Ciber', 'site:marca.com', f'{sector_es} OR {direct_brand_names}', cyber_es, hl='es-419', gl='ES', ceid='ES:es'),
        _site_query('Google News - Le Monde Mode Cyber', 'site:lemonde.fr', sector_fr, cyber_fr, hl='fr', gl='FR', ceid='FR:fr'),
        _site_query('Google News - Le Figaro Mode Cyber', 'site:lefigaro.fr', sector_fr, cyber_fr, hl='fr', gl='FR', ceid='FR:fr'),
        _site_query('Google News - Les Echos Retail Cyber', 'site:lesechos.fr', sector_fr, cyber_fr, hl='fr', gl='FR', ceid='FR:fr'),
        _site_query('Google News - FAZ Retail Cyber', 'site:faz.net', sector_de, cyber_de, hl='de', gl='DE', ceid='DE:de'),
        _site_query('Google News - Spiegel Retail Cyber', 'site:spiegel.de', sector_de, cyber_de, hl='de', gl='DE', ceid='DE:de'),
        _site_query('Google News - Handelsblatt Retail Cyber', 'site:handelsblatt.com OR site:handelsblatt.de', sector_de, cyber_de, hl='de', gl='DE', ceid='DE:de'),
        _site_query('Google News - Corriere Moda Cyber', 'site:corriere.it', sector_it, cyber_it, hl='it', gl='IT', ceid='IT:it'),
        _site_query('Google News - Repubblica Moda Cyber', 'site:repubblica.it', sector_it, cyber_it, hl='it', gl='IT', ceid='IT:it'),
        _site_query('Google News - Il Sole 24 Ore Retail Cyber', 'site:ilsole24ore.com', sector_it, cyber_it, hl='it', gl='IT', ceid='IT:it'),
        _site_query('Google News - NYT Retail Cyber', 'site:nytimes.com', sector_global, cyber_en),
        _site_query('Google News - Washington Post Retail Cyber', 'site:washingtonpost.com', sector_global, cyber_en),
        _site_query('Google News - WSJ Retail Cyber', 'site:wsj.com', sector_global, cyber_en),
        _site_query('Google News - CNBC Retail Cyber', 'site:cnbc.com', sector_global, cyber_en),
        _site_query('Google News - CNN Retail Cyber', 'site:cnn.com', sector_global, cyber_en),
        _site_query('Google News - Reuters Retail Cyber', 'site:reuters.com', sector_global, cyber_en),
        _site_query('Google News - AP Retail Cyber', 'site:apnews.com', sector_global, cyber_en),
        _site_query('Google News - Arab News Retail Cyber', 'site:arabnews.com', sector_global, cyber_en, hl='en', gl='SA', ceid='SA:en'),
        _site_query('Google News - Gulf News Retail Cyber', 'site:gulfnews.com', sector_global, cyber_en, hl='en', gl='AE', ceid='AE:en'),
        _site_query('Google News - The National Retail Cyber', 'site:thenationalnews.com', sector_global, cyber_en, hl='en', gl='AE', ceid='AE:en'),
        _site_query('Google News - Khaleej Times Retail Cyber', 'site:khaleejtimes.com', sector_global, cyber_en, hl='en', gl='AE', ceid='AE:en'),
        _site_query('Google News - Economic Times Retail Cyber', 'site:economictimes.indiatimes.com', sector_global, cyber_en, hl='en-IN', gl='IN', ceid='IN:en'),
        _site_query('Google News - Indian Express Retail Cyber', 'site:indianexpress.com', sector_global, cyber_en, hl='en-IN', gl='IN', ceid='IN:en'),
        _site_query('Google News - Hindustan Times Retail Cyber', 'site:hindustantimes.com', sector_global, cyber_en, hl='en-IN', gl='IN', ceid='IN:en'),
        _site_query('Google News - ABC Australia Retail Cyber', 'site:abc.net.au', sector_global, cyber_en, hl='en-AU', gl='AU', ceid='AU:en'),
        _site_query('Google News - SMH Retail Cyber', 'site:smh.com.au', sector_global, cyber_en, hl='en-AU', gl='AU', ceid='AU:en'),
        _site_query('Google News - The Age Retail Cyber', 'site:theage.com.au', sector_global, cyber_en, hl='en-AU', gl='AU', ceid='AU:en'),
        _site_query('Google News - South China Morning Post Retail Cyber', 'site:scmp.com', sector_global, cyber_en, hl='en', gl='HK', ceid='HK:en'),
        _site_query('Google News - Japan Times Retail Cyber', 'site:japantimes.co.jp', sector_global, cyber_en, hl='en', gl='JP', ceid='JP:en'),
        _site_query('Google News - Korea Herald Retail Cyber', 'site:koreaherald.com', sector_global, cyber_en, hl='en', gl='KR', ceid='KR:en'),
        _site_query('Google News - Folha Moda Cyber', 'site:folha.uol.com.br', sector_pt, cyber_pt, hl='pt-BR', gl='BR', ceid='BR:pt-419'),
        _site_query('Google News - O Globo Moda Cyber', 'site:oglobo.globo.com OR site:oglobo.com.br', sector_pt, cyber_pt, hl='pt-BR', gl='BR', ceid='BR:pt-419'),
        _site_query('Google News - Clarin Moda Cyber', 'site:clarin.com', sector_es, cyber_es, hl='es-419', gl='AR', ceid='AR:es-419'),
        _site_query('Google News - El Universal Moda Cyber', 'site:eluniversal.com.mx', sector_es, cyber_es, hl='es-419', gl='MX', ceid='MX:es-419'),
    ]

    current_year = datetime.now().year
    yearly_specs = [
        ("Global Fashion Retail Cyber", sector_global, cyber_en, "en-US", "US", "US:en"),
        ("Direct Fashion Brands Cyber", direct_brand_names, cyber_en, "en-US", "US", "US:en"),
        ("Moda y Textil Ciber ES", sector_es, cyber_es, "es-419", "ES", "ES:es"),
    ]
    for year in range(2024, current_year + 1):
        for base_name, sector_terms, cyber_terms, hl, gl, ceid in yearly_specs:
            bounded = year_bounded_query(f'({sector_terms}) ({cyber_terms})', year)
            feeds.append((f'Google News - {base_name} {year}', google_news_rss(bounded, hl=hl, gl=gl, ceid=ceid)))

    deduped: list[tuple[str, str]] = []
    seen_urls: set[str] = set()
    for name, url in feeds:
        if url in seen_urls:
            continue
        seen_urls.add(url)
        deduped.append((name, url))
    return deduped


DEFAULT_SETTINGS = {
    'prompt': '',
    'poll_interval_seconds': '300',
    'max_articles_per_feed': '0',
    'auto_refresh_enabled': '1',
    'date_window': 'all',
    'relevance_mode': 'balanced',
    'hide_duplicates': '1',
    'semantic_reranking': '1',
    'feedback_learning': '1',
}


DEFAULT_FEED_URLS = ['https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.bleepingcomputer.com%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fadvisories.feedly.com%2Fcisa%2FexploitedCve%2Ffeed.json', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fnvd.nist.gov%2Fdownload%2Fnvd-rss.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.us-cert.gov%2Fcurrent%2Findex.rdf', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.incibe.es%2Fincibe-cert%2Falerta-temprana%2Favisos%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.ninjaone.com%2Fblog%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fblogs.technet.com%2Fb%2Ftrustworthycomputing%2Frss.aspx', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.crowdstrike.com%2Fblog%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.cisecurity.org%2Ffeed%2Fadvisories', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fcybersecuritynews.es%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.darkreading.com%2Frss%2Fall.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fstatus.duo.com%2Fhistory.rss', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fcommunity.fortinet.com%2Ftpykb84852%2Frss%2Fboard%3Fboard.id%3DTKB20', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fepvuln.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fir.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Foutbreakalert.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fthreatsignal.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fipsdatabase.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fisdb.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fotips.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Findsec.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fwebsecurity.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fsupport.fortinet.com%2Frss%2Ffirmware.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fadvisories.feedly.com%2Fgoogle%2Fchrome%2Ffeed.json', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fcloud.google.com%2Ffeeds%2Fgoogle-cloud-security-bulletins.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fgoogleonlinesecurity.blogspot.com%2Fatom.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fhackmanac.com%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.incibe.es%2Fincibe-cert%2Fblog%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffeedproxy.feedly.com%2Fe9051d2d-e920-4448-b985-c1e1ec259092', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fblogs.msdn.com%2Fsdl%2Frss.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fadvisories.feedly.com%2Fmicrosoft%2Ffeed.json', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.microsoft.com%2Fen-us%2Fsecurity%2Fblog%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fblogs.technet.com%2Fmmpc%2Frss.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.ninjaone.com%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fonapsis.com%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fblog.documentfoundation.org%2Fblog%2Fcategory%2Fpress-releases%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fgrafana.com%2Fsecurity%2Fsecurity-advisories%2Findex.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fgrafana.com%2Ftags%2Fsecurity%2Findex.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.synology.com%2Fapi%2Frssfeed%2Fsecurity%2Fen-global', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fblog.documentfoundation.org%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fstatus.teamviewer.com%2Fhistory.rss', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Ffeeds.feedburner.com%2Fduosecurity', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fthehackernews.com%2Ffeeds%2Fposts%2Fdefault', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.microsoft.com%2Fsecurity%2Fblog%2Ftag%2Fmicrosoft-security-intelligence%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fubuntu.com%2Fblog%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fubuntu.com%2Fsecurity%2Fnotices%2Fatom.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fcommunity.qualys.com%2Fblogs%2Fsecuritylabs%2Ffeeds%2Fposts', 'https://news.google.com/rss/search?q=(fashion%20OR%20apparel%20OR%20textile%20OR%20clothing%20OR%20%22luxury%20brand%22%20OR%20%22fashion%20retailer%22)%20(cyberattack%20OR%20%22data%20breach%22%20OR%20ransomware%20OR%20malware%20OR%20phishing%20OR%20%22security%20incident%22%20OR%20%22credential%20theft%22)&hl=en-US&gl=US&ceid=US:en', 'https://news.google.com/rss/search?q=(%22online%20store%22%20OR%20ecommerce%20OR%20checkout%20OR%20%22fashion%20ecommerce%22%20OR%20%22luxury%20brand%22)%20(%22payment%20breach%22%20OR%20magecart%20OR%20%22payment%20skimmer%22%20OR%20%22stolen%20credentials%22%20OR%20ransomware%20OR%20phishing)&hl=en-US&gl=US&ceid=US:en', 'https://news.google.com/rss/search?q=(moda%20OR%20textil%20OR%20lujo%20OR%20%22tiendas%20de%20ropa%22%20OR%20%22cadena%20textil%22)%20(ciberataque%20OR%20%22brecha%20de%20datos%22%20OR%20ransomware%20OR%20filtraci%C3%B3n%20OR%20phishing%20OR%20malware%20OR%20%22robo%20de%20credenciales%22)&hl=es-419&gl=ES&ceid=ES:es', 'https://news.google.com/rss/search?q=(retailer%20OR%20retail%20OR%20brand%20OR%20store)%20(%22payment%20breach%22%20OR%20%22digital%20fraud%22%20OR%20magecart%20OR%20%22stolen%20credentials%22%20OR%20%22customer%20data%22)%20(fashion%20OR%20apparel%20OR%20textile%20OR%20luxury)&hl=en-US&gl=US&ceid=US:en']
KNOWN_FEED_NAMES = {'news.google.com/rss/search?q=(fashion%20OR%20apparel%20OR%20textile%20OR%20%22luxury%20brand%22%20OR%20retailer%20OR%20%22online%20store%22)%20(cyberattack%20OR%20%22data%20breach%22%20OR%20ransomware%20OR%20phishing%20OR%20malware%20OR%20hacked%20OR%20breach)&hl=en-US&gl=US&ceid=US:en': 'Google News - Fashion Retail Cyber', 'news.google.com/rss/search?q=(fashion%20ecommerce%20OR%20apparel%20ecommerce%20OR%20%22fashion%20retailer%22%20OR%20%22luxury%20brand%22)%20(%22security%20incident%22%20OR%20%22payment%20breach%22%20OR%20%22credential%20theft%22%20OR%20malware%20OR%20phishing%20OR%20ransomware)&hl=en-US&gl=US&ceid=US:en': 'Google News - Fashion Ecommerce Incidentes', 'news.google.com/rss/search?q=(moda%20OR%20textil%20OR%20marcas%20OR%20lujo%20OR%20%22tiendas%20de%20ropa%22)%20(ciberataque%20OR%20%22brecha%20de%20datos%22%20OR%20ransomware%20OR%20filtraci%C3%B3n%20OR%20phishing%20OR%20malware)&hl=es-419&gl=ES&ceid=ES:es': 'Google News - Moda/Textil Ciber', 'news.google.com/rss/search?q=(retail%20OR%20retailer%20OR%20ecommerce%20OR%20store)%20(%22payment%20skimmer%22%20OR%20magecart%20OR%20%22digital%20fraud%22%20OR%20%22stolen%20credentials%22%20OR%20%22customer%20data%22)&hl=en-US&gl=US&ceid=US:en': 'Google News - Retail Moda Fraude/Payments', 'www.bleepingcomputer.com/feed/': 'BleepingComputer', 'advisories.feedly.com/cisa/exploitedCve/feed.json': 'CISA Known Exploited Vulnerabilities', 'nvd.nist.gov/download/nvd-rss.xml': 'NVD RSS', 'www.us-cert.gov/current/index.rdf': 'US-CERT Current Activity', 'www.incibe.es/incibe-cert/alerta-temprana/avisos/feed': 'INCIBE Avisos', 'www.ninjaone.com/blog/feed/': 'NinjaOne Blog', 'blogs.technet.com/b/trustworthycomputing/rss.aspx': 'Microsoft Trustworthy Computing', 'www.crowdstrike.com/blog/feed': 'CrowdStrike Blog', 'www.cisecurity.org/feed/advisories': 'CIS Advisories', 'cybersecuritynews.es/feed/': 'CyberSecurityNews.es', 'www.darkreading.com/rss/all.xml': 'Dark Reading', 'status.duo.com/history.rss': 'Duo Status', 'community.fortinet.com/tpykb84852/rss/board?board.id=TKB20': 'Fortinet Community', 'filestore.fortinet.com/fortiguard/rss/epvuln.xml': 'FortiGuard EPVuln', 'filestore.fortinet.com/fortiguard/rss/ir.xml': 'FortiGuard IR', 'filestore.fortinet.com/fortiguard/rss/outbreakalert.xml': 'FortiGuard Outbreak Alert', 'filestore.fortinet.com/fortiguard/rss/threatsignal.xml': 'FortiGuard Threat Signal', 'filestore.fortinet.com/fortiguard/rss/ipsdatabase.xml': 'FortiGuard IPS Database', 'filestore.fortinet.com/fortiguard/rss/isdb.xml': 'FortiGuard ISDB', 'filestore.fortinet.com/fortiguard/rss/otips.xml': 'FortiGuard OTIPS', 'filestore.fortinet.com/fortiguard/rss/indsec.xml': 'FortiGuard Industrial Security', 'filestore.fortinet.com/fortiguard/rss/websecurity.xml': 'FortiGuard Web Security', 'support.fortinet.com/rss/firmware.xml': 'Fortinet Firmware', 'advisories.feedly.com/google/chrome/feed.json': 'Google Chrome Advisories', 'cloud.google.com/feeds/google-cloud-security-bulletins.xml': 'Google Cloud Security Bulletins', 'googleonlinesecurity.blogspot.com/atom.xml': 'Google Online Security Blog', 'hackmanac.com/feed': 'Hackmageddon / Hackmanac', 'www.incibe.es/incibe-cert/blog/feed': 'INCIBE Blog', 'feedproxy.feedly.com/e9051d2d-e920-4448-b985-c1e1ec259092': 'Feedly Proxy Feed', 'blogs.msdn.com/sdl/rss.xml': 'Microsoft SDL Blog', 'advisories.feedly.com/microsoft/feed.json': 'Microsoft Advisories', 'www.microsoft.com/en-us/security/blog/feed/': 'Microsoft Security Blog', 'blogs.technet.com/mmpc/rss.xml': 'Microsoft Malware Protection Center', 'www.ninjaone.com/feed/': 'NinjaOne Feed', 'onapsis.com/feed/': 'Onapsis', 'blog.documentfoundation.org/blog/category/press-releases/feed/': 'Document Foundation Press Releases', 'grafana.com/security/security-advisories/index.xml': 'Grafana Security Advisories', 'grafana.com/tags/security/index.xml': 'Grafana Security Tag', 'www.synology.com/api/rssfeed/security/en-global': 'Synology Security', 'blog.documentfoundation.org/feed/': 'Document Foundation Blog', 'status.teamviewer.com/history.rss': 'TeamViewer Status', 'feeds.feedburner.com/duosecurity': 'Duo Security Blog', 'thehackernews.com/feeds/posts/default': 'The Hacker News', 'www.microsoft.com/security/blog/tag/microsoft-security-intelligence/feed/': 'Microsoft Security Intelligence', 'ubuntu.com/blog/feed': 'Ubuntu Blog', 'ubuntu.com/security/notices/atom.xml': 'Ubuntu Security Notices', 'community.qualys.com/blogs/securitylabs/feeds/posts': 'Qualys Security Labs'}


for _name, _url in brand_discovery_feeds():
    if _url not in DEFAULT_FEED_URLS:
        DEFAULT_FEED_URLS.append(_url)
    normalized_key = f"{urlparse(_url).netloc}{urlparse(_url).path}"
    if urlparse(_url).query:
        normalized_key = f"{normalized_key}?{urlparse(_url).query}"
    KNOWN_FEED_NAMES.setdefault(normalized_key, _name)


def row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    data = {k: row[k] for k in row.keys()}
    tags = data.get('match_tags')
    if isinstance(tags, str) and tags:
        try:
            data['match_tags'] = json.loads(tags)
        except Exception:
            data['match_tags'] = [item.strip() for item in tags.split('|') if item.strip()]
    else:
        data['match_tags'] = []
    entities = data.get('entities_json')
    if isinstance(entities, str) and entities:
        try:
            data['entities'] = json.loads(entities)
        except Exception:
            data['entities'] = {}
    else:
        data['entities'] = {}
    sector_categories = data.get('sector_categories')
    if isinstance(sector_categories, str) and sector_categories:
        try:
            data['sector_categories'] = json.loads(sector_categories)
        except Exception:
            data['sector_categories'] = [item.strip() for item in sector_categories.split('|') if item.strip()]
    else:
        data['sector_categories'] = []
    return data


@contextmanager
def get_conn() -> Iterable[sqlite3.Connection]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


SCHEMA = '''
CREATE TABLE IF NOT EXISTS feeds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    url TEXT NOT NULL UNIQUE,
    is_enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unique_key TEXT NOT NULL UNIQUE,
    feed_id INTEGER,
    feed_name TEXT,
    feed_url TEXT,
    title TEXT NOT NULL,
    article_url TEXT NOT NULL,
    feedly_url TEXT,
    summary TEXT,
    content TEXT,
    published_at TEXT,
    image_url TEXT,
    video_url TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    status_origin TEXT NOT NULL DEFAULT 'auto',
    match_tags TEXT,
    cluster_key TEXT,
    duplicate_group TEXT,
    duplicate_rank INTEGER DEFAULT 1,
    campaign_cluster TEXT,
    entities_json TEXT,
    sector_categories TEXT,
    semantic_score REAL NOT NULL DEFAULT 0,
    feedback_score REAL NOT NULL DEFAULT 0,
    relevance_score REAL NOT NULL DEFAULT 0,
    rationale TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(feed_id) REFERENCES feeds(id)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS feedback_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL,
    previous_status TEXT,
    new_status TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(article_id) REFERENCES articles(id)
);

CREATE INDEX IF NOT EXISTS idx_articles_created_at ON articles(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_cluster_key ON articles(cluster_key);
'''


def normalize_feed_url(url: str) -> str:
    value = (url or '').strip()
    if not value:
        return ''
    parsed = urlparse(value)
    marker = '/i/subscription/content/feed%2F'
    if parsed.netloc.lower().endswith('feedly.com') and marker in parsed.path:
        raw = parsed.path.split(marker, 1)[1]
        return unquote(raw).strip()
    if parsed.netloc.lower().endswith('feedly.com') and '/i/subscription/content/' in parsed.path:
        tail = parsed.path.rsplit('/', 1)[-1]
        if tail.startswith('feed%2F'):
            return unquote(tail[len('feed%2F'):]).strip()
    return value


BRANDS_PRIORITY_FEED_NAMES = {name for name, _ in brand_discovery_feeds()}
BRANDS_PRIORITY_FEED_URLS = {normalize_feed_url(url) for _, url in brand_discovery_feeds()}


def is_brands_priority_feed(feed: dict[str, Any] | None) -> bool:
    if not feed:
        return False
    name = (feed.get('name') or '').strip()
    url = normalize_feed_url(feed.get('url') or '')
    if name in BRANDS_PRIORITY_FEED_NAMES:
        return True
    return url in BRANDS_PRIORITY_FEED_URLS


def derive_feed_name(url: str) -> str:
    normalized = normalize_feed_url(url)
    parsed = urlparse(normalized)
    key = f"{parsed.netloc}{parsed.path}"
    if parsed.query:
        key = f"{key}?{parsed.query}"
    if key in KNOWN_FEED_NAMES:
        return KNOWN_FEED_NAMES[key]
    host = parsed.netloc.replace('www.', '')
    if not host:
        return 'Feed RSS'
    path = parsed.path.strip('/').split('/')
    host_title = host.split(':', 1)[0].split('.')[0].replace('-', ' ').title()
    if path and path[0]:
        suffix = path[-1].replace('-', ' ').replace('_', ' ')
        suffix = suffix.replace('.xml', '').replace('.rss', '').replace('.rdf', '').replace('.json', '')
        suffix = suffix.replace('.aspx', '').strip().title()
        if suffix and suffix.lower() not in {'feed', 'atom', 'rss', 'index'}:
            return f'{host_title} - {suffix}'
    return host_title


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, definition: str) -> None:
    existing = {row['name'] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in existing:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        _ensure_column(conn, 'articles', 'status_origin', "TEXT NOT NULL DEFAULT 'auto'")
        _ensure_column(conn, 'articles', 'match_tags', 'TEXT')
        _ensure_column(conn, 'articles', 'cluster_key', 'TEXT')
        _ensure_column(conn, 'articles', 'duplicate_group', 'TEXT')
        _ensure_column(conn, 'articles', 'duplicate_rank', 'INTEGER DEFAULT 1')
        _ensure_column(conn, 'articles', 'campaign_cluster', 'TEXT')
        _ensure_column(conn, 'articles', 'entities_json', 'TEXT')
        _ensure_column(conn, 'articles', 'semantic_score', 'REAL NOT NULL DEFAULT 0')
        _ensure_column(conn, 'articles', 'feedback_score', 'REAL NOT NULL DEFAULT 0')
        _ensure_column(conn, 'articles', 'sector_categories', 'TEXT')
        conn.execute("CREATE TABLE IF NOT EXISTS feedback_events (id INTEGER PRIMARY KEY AUTOINCREMENT, article_id INTEGER NOT NULL, previous_status TEXT, new_status TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(article_id) REFERENCES articles(id))")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_duplicate_group ON articles(duplicate_group)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_campaign_cluster ON articles(campaign_cluster)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles(published_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_status_published ON articles(status, published_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_feed_id_created ON articles(feed_id, created_at DESC)")
        for key, value in DEFAULT_SETTINGS.items():
            conn.execute('INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)', (key, value))


def list_feeds() -> list[dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute('SELECT * FROM feeds ORDER BY is_enabled DESC, name COLLATE NOCASE ASC').fetchall()
    return [row_to_dict(row) for row in rows]


def add_feed(name: str | None, url: str) -> dict[str, Any]:
    normalized_url = normalize_feed_url(url)
    final_name = (name or '').strip() or derive_feed_name(normalized_url)
    with get_conn() as conn:
        conn.execute('INSERT OR IGNORE INTO feeds(name, url, is_enabled) VALUES(?, ?, 1)', (final_name, normalized_url))
        row = conn.execute('SELECT * FROM feeds WHERE url = ?', (normalized_url,)).fetchone()
    return row_to_dict(row) or {}


def toggle_feed(feed_id: int, is_enabled: bool) -> dict[str, Any] | None:
    with get_conn() as conn:
        conn.execute('UPDATE feeds SET is_enabled = ? WHERE id = ?', (1 if is_enabled else 0, feed_id))
        row = conn.execute('SELECT * FROM feeds WHERE id = ?', (feed_id,)).fetchone()
    return row_to_dict(row)


def delete_feed(feed_id: int) -> None:
    with get_conn() as conn:
        conn.execute('DELETE FROM feeds WHERE id = ?', (feed_id,))


def get_settings() -> dict[str, Any]:
    with get_conn() as conn:
        rows = conn.execute('SELECT key, value FROM settings').fetchall()
    settings = {row['key']: row['value'] for row in rows}
    merged = DEFAULT_SETTINGS | settings
    merged['poll_interval_seconds'] = int(merged['poll_interval_seconds'])
    merged['max_articles_per_feed'] = int(merged['max_articles_per_feed'])
    merged['auto_refresh_enabled'] = str(merged['auto_refresh_enabled']) == '1'
    merged['hide_duplicates'] = str(merged['hide_duplicates']) == '1'
    merged['semantic_reranking'] = str(merged.get('semantic_reranking', '1')) == '1'
    merged['feedback_learning'] = str(merged.get('feedback_learning', '1')) == '1'
    return merged


def update_settings(changes: dict[str, Any]) -> dict[str, Any]:
    allowed = {'prompt', 'poll_interval_seconds', 'max_articles_per_feed', 'auto_refresh_enabled', 'date_window', 'relevance_mode', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'}
    with get_conn() as conn:
        for key, value in changes.items():
            if key not in allowed or value is None:
                continue
            if key in {'auto_refresh_enabled', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'}:
                value = '1' if bool(value) else '0'
            else:
                value = str(value)
            conn.execute('''
                INSERT INTO settings(key, value) VALUES(?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
            ''', (key, value))
    return get_settings()


def upsert_articles(articles: list[dict[str, Any]]) -> int:
    inserted = 0
    with get_conn() as conn:
        for article in articles:
            exists = conn.execute("SELECT id, status, COALESCE(status_origin, 'auto') AS status_origin FROM articles WHERE unique_key = ?", (article['unique_key'],)).fetchone()
            if exists:
                if exists['status_origin'] == 'manual':
                    conn.execute('''
                        UPDATE articles
                        SET feed_id = ?, feed_name = ?, feed_url = ?, title = ?, article_url = ?, feedly_url = ?,
                            summary = ?, content = ?, published_at = ?, image_url = ?, video_url = ?,
                            match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?, entities_json = ?, sector_categories = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE unique_key = ?
                    ''', (
                        article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'),
                        article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'),
                        article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('sector_categories', '[]'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''), article['unique_key'],
                    ))
                else:
                    conn.execute('''
                        UPDATE articles
                        SET feed_id = ?, feed_name = ?, feed_url = ?, title = ?, article_url = ?, feedly_url = ?,
                            summary = ?, content = ?, published_at = ?, image_url = ?, video_url = ?, status = ?, status_origin = ?,
                            match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?, entities_json = ?, sector_categories = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE unique_key = ?
                    ''', (
                        article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'),
                        article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'),
                        article.get('status', 'pending'), article.get('status_origin', 'auto'), article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('sector_categories', '[]'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''), article['unique_key'],
                    ))
                continue
            conn.execute('''
                INSERT INTO articles(
                    unique_key, feed_id, feed_name, feed_url, title, article_url, feedly_url,
                    summary, content, published_at, image_url, video_url, status,
                    status_origin, match_tags, cluster_key, duplicate_group, duplicate_rank, campaign_cluster, entities_json, sector_categories, semantic_score, feedback_score, relevance_score, rationale
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                article['unique_key'], article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'), article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'), article.get('status', 'pending'), article.get('status_origin', 'auto'), article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('sector_categories', '[]'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''),
            ))
            inserted += 1
    return inserted


SECTOR_ALIASES = {
    'marcas_retail': ('marcas_retail', 'marcas', 'marca', 'brand', 'brands', 'retail_brands'),
    'general': (),
}


def sector_aliases(sector: str) -> tuple[str, ...]:
    sector_norm = (sector or '').strip().lower()
    if not sector_norm or sector_norm == 'all':
        return ()
    return SECTOR_ALIASES.get(sector_norm, (sector_norm,))


def _sector_clause(aliases: tuple[str, ...]) -> tuple[str, list[str]]:
    if not aliases:
        return '', []
    parts = ["instr(COALESCE(sector_categories, ''), ?) > 0" for _ in aliases]
    params = [f'"{alias}"' for alias in aliases]
    return '(' + ' OR '.join(parts) + ')', params


def _dedupe_rows(rows: list[sqlite3.Row]) -> list[sqlite3.Row]:
    settings = get_settings()
    if not settings.get('hide_duplicates', True):
        return rows
    seen: set[str] = set()
    output: list[sqlite3.Row] = []
    for row in rows:
        key = row['duplicate_group'] or row['cluster_key'] or row['title']
        if key in seen:
            continue
        seen.add(key)
        output.append(row)
    return output


def list_articles(limit: int = 100, status: str = 'all', sector: str = 'all') -> list[dict[str, Any]]:
    query = 'SELECT * FROM articles'
    params: list[Any] = []
    clauses: list[str] = []
    if status != 'all':
        clauses.append('status = ?')
        params.append(status)
    if sector != 'all':
        aliases = sector_aliases(sector)
        sector_clause, sector_params = _sector_clause(aliases)
        if sector_clause:
            clauses.append(sector_clause)
            params.extend(sector_params)
    if clauses:
        query += ' WHERE ' + ' AND '.join(clauses)
    query += '''
        ORDER BY
            COALESCE(NULLIF(published_at, ''), created_at) DESC,
            relevance_score DESC,
            id DESC
        LIMIT ?
    '''
    params.append(max(limit * 4, 200))
    with get_conn() as conn:
        rows = conn.execute(query, params).fetchall()
    rows = _dedupe_rows(rows)[:limit]
    return [row_to_dict(row) for row in rows]


def list_articles_unbounded(status: str = 'all', sector: str = 'all', dedupe: bool = True) -> list[dict[str, Any]]:
    query = 'SELECT * FROM articles'
    params: list[Any] = []
    clauses: list[str] = []
    if status != 'all':
        clauses.append('status = ?')
        params.append(status)
    if sector == 'general':
        sector_clause, sector_params = _sector_clause(sector_aliases('marcas_retail'))
        if sector_clause:
            clauses.append(f'NOT {sector_clause}')
            params.extend(sector_params)
    elif sector != 'all':
        aliases = sector_aliases(sector)
        sector_clause, sector_params = _sector_clause(aliases)
        if sector_clause:
            clauses.append(sector_clause)
            params.extend(sector_params)
    if clauses:
        query += ' WHERE ' + ' AND '.join(clauses)
    query += '''
        ORDER BY
            COALESCE(NULLIF(published_at, ''), created_at) DESC,
            relevance_score DESC,
            id DESC
    '''
    with get_conn() as conn:
        rows = conn.execute(query, params).fetchall()
    if dedupe:
        rows = _dedupe_rows(rows)
    return [row_to_dict(row) for row in rows]




def list_sector_articles(sector: str = 'marcas_retail', include_excluded: bool = False) -> list[dict[str, Any]]:
    aliases = sector_aliases(sector)
    sector_clause, sector_params = _sector_clause(aliases)
    query = 'SELECT * FROM articles'
    clauses: list[str] = []
    params: list[Any] = []
    if sector_clause:
        clauses.append(sector_clause)
        params.extend(sector_params)
    if not include_excluded:
        clauses.append("status != 'excluded'")
    if clauses:
        query += ' WHERE ' + ' AND '.join(clauses)
    query += ' ORDER BY COALESCE(NULLIF(published_at, ""), created_at) DESC, relevance_score DESC, id DESC'
    with get_conn() as conn:
        rows = conn.execute(query, params).fetchall()
    return [row_to_dict(row) for row in rows]

def get_article(article_id: int) -> dict[str, Any] | None:
    with get_conn() as conn:
        row = conn.execute('SELECT * FROM articles WHERE id = ?', (article_id,)).fetchone()
    return row_to_dict(row)


def update_article_status(article_id: int, status: str) -> dict[str, Any] | None:
    with get_conn() as conn:
        before = conn.execute('SELECT status FROM articles WHERE id = ?', (article_id,)).fetchone()
        previous_status = before['status'] if before else None
        conn.execute("UPDATE articles SET status = ?, status_origin = 'manual', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (status, article_id))
        conn.execute('INSERT INTO feedback_events(article_id, previous_status, new_status) VALUES(?, ?, ?)', (article_id, previous_status, status))
        row = conn.execute('SELECT * FROM articles WHERE id = ?', (article_id,)).fetchone()
    return row_to_dict(row)


def rescore_articles(prompt: str, date_window: str = 'all', relevance_mode: str = 'balanced') -> int:
    from .intelligence import analyze_articles
    with get_conn() as conn:
        rows = [row_to_dict(row) for row in conn.execute('SELECT * FROM articles').fetchall()]
        analyzed = analyze_articles([row or {} for row in rows], prompt, date_window=date_window, relevance_mode=relevance_mode)
        for row in analyzed:
            if row.get('status_origin') == 'manual':
                conn.execute('''
                    UPDATE articles
                    SET match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?,
                        entities_json = ?, sector_categories = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (json.dumps(row.get('match_tags') or [], ensure_ascii=False), row.get('cluster_key'), row.get('duplicate_group'), row.get('duplicate_rank', 1), row.get('campaign_cluster'), json.dumps(row.get('entities') or {}, ensure_ascii=False), json.dumps(row.get('sector_categories') or [], ensure_ascii=False), row.get('semantic_score', 0), row.get('feedback_score', 0), row.get('hybrid_score', row.get('relevance_score', 0)), row.get('rationale', ''), row['id']))
            else:
                conn.execute('''
                    UPDATE articles
                    SET status = ?, status_origin = 'auto', match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?,
                        entities_json = ?, sector_categories = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (row.get('computed_status', row.get('status', 'pending')), json.dumps(row.get('match_tags') or [], ensure_ascii=False), row.get('cluster_key'), row.get('duplicate_group'), row.get('duplicate_rank', 1), row.get('campaign_cluster'), json.dumps(row.get('entities') or {}, ensure_ascii=False), json.dumps(row.get('sector_categories') or [], ensure_ascii=False), row.get('semantic_score', 0), row.get('feedback_score', 0), row.get('hybrid_score', row.get('relevance_score', 0)), row.get('rationale', ''), row['id']))
    return len(analyzed)


def stats() -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute('''
            SELECT COUNT(*) AS total_articles,
                SUM(CASE WHEN status = 'included' THEN 1 ELSE 0 END) AS included_count,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_count,
                SUM(CASE WHEN status = 'excluded' THEN 1 ELSE 0 END) AS excluded_count
            FROM articles
        ''').fetchone()
        feed_count = conn.execute('SELECT COUNT(*) AS c FROM feeds').fetchone()['c']
    return {'total_articles': row['total_articles'] or 0, 'included_count': row['included_count'] or 0, 'pending_count': row['pending_count'] or 0, 'excluded_count': row['excluded_count'] or 0, 'feed_count': feed_count}



def feedback_summary() -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute("SELECT COUNT(*) AS total, SUM(CASE WHEN new_status = 'included' THEN 1 ELSE 0 END) AS included, SUM(CASE WHEN new_status = 'excluded' THEN 1 ELSE 0 END) AS excluded FROM feedback_events").fetchone()
    return {'feedback_events': row['total'] or 0, 'feedback_included': row['included'] or 0, 'feedback_excluded': row['excluded'] or 0}

def seed_default_feeds() -> None:
    for url in DEFAULT_FEED_URLS:
        add_feed(name=derive_feed_name(url), url=url)
    seed = os.getenv('CYBERRAD_SEED_FEEDS', '').strip()
    if not seed:
        return
    entries = [item.strip() for item in seed.split(',') if item.strip()]
    for entry in entries:
        if '|' in entry:
            name, url = entry.split('|', 1)
        else:
            name, url = '', entry
        add_feed(name=name.strip(), url=url.strip())

# HOTFIX19_SQLITE_PERF_OVERRIDE
import time

DB_TIMEOUT_SECONDS = float(os.getenv('CYBERRAD_SQLITE_TIMEOUT', '30'))
SETTINGS_CACHE_TTL_SECONDS = 5.0
SHORT_CACHE_TTL_SECONDS = 2.0
_RUNTIME_CACHE: dict[str, dict[str, Any]] = {}
_DB_REVISION = 0

ARTICLE_LIGHT_COLUMNS = '''
    id,
    unique_key,
    feed_id,
    feed_name,
    feed_url,
    title,
    article_url,
    feedly_url,
    summary,
    content,
    published_at,
    image_url,
    video_url,
    status,
    status_origin,
    match_tags,
    cluster_key,
    duplicate_group,
    duplicate_rank,
    campaign_cluster,
    entities_json,
    sector_categories,
    semantic_score,
    feedback_score,
    relevance_score,
    rationale,
    created_at,
    updated_at
'''


def _invalidate_runtime_caches() -> None:
    global _DB_REVISION
    _DB_REVISION += 1
    _RUNTIME_CACHE.clear()


def _cached_payload(name: str, ttl_seconds: float, loader, *, force: bool = False):
    now = time.monotonic()
    entry = None if force else _RUNTIME_CACHE.get(name)
    if entry and entry.get('revision') == _DB_REVISION and (now - float(entry.get('ts', 0.0))) <= ttl_seconds:
        return entry.get('data')
    data = loader()
    _RUNTIME_CACHE[name] = {'revision': _DB_REVISION, 'ts': now, 'data': data}
    return data


def _sqlite_connect(*, read_only: bool = False) -> sqlite3.Connection:
    if read_only:
        dsn = f'file:{DB_PATH}?mode=ro'
        conn = sqlite3.connect(dsn, uri=True, timeout=DB_TIMEOUT_SECONDS, isolation_level=None, check_same_thread=False)
    else:
        conn = sqlite3.connect(DB_PATH, timeout=DB_TIMEOUT_SECONDS, isolation_level=None, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute(f'PRAGMA busy_timeout={int(DB_TIMEOUT_SECONDS * 1000)}')
    conn.execute('PRAGMA temp_store=MEMORY')
    if read_only:
        conn.execute('PRAGMA query_only=ON')
    else:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
        conn.execute('PRAGMA wal_autocheckpoint=1000')
    return conn


@contextmanager
def get_conn(read_only: bool = False) -> Iterable[sqlite3.Connection]:
    conn = _sqlite_connect(read_only=read_only)
    try:
        if not read_only:
            conn.execute('BEGIN')
        yield conn
        if not read_only:
            conn.commit()
    except Exception:
        if not read_only:
            conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        _ensure_column(conn, 'articles', 'status_origin', "TEXT NOT NULL DEFAULT 'auto'")
        _ensure_column(conn, 'articles', 'match_tags', 'TEXT')
        _ensure_column(conn, 'articles', 'cluster_key', 'TEXT')
        _ensure_column(conn, 'articles', 'duplicate_group', 'TEXT')
        _ensure_column(conn, 'articles', 'duplicate_rank', 'INTEGER DEFAULT 1')
        _ensure_column(conn, 'articles', 'campaign_cluster', 'TEXT')
        _ensure_column(conn, 'articles', 'entities_json', 'TEXT')
        _ensure_column(conn, 'articles', 'semantic_score', 'REAL NOT NULL DEFAULT 0')
        _ensure_column(conn, 'articles', 'feedback_score', 'REAL NOT NULL DEFAULT 0')
        _ensure_column(conn, 'articles', 'sector_categories', 'TEXT')
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_duplicate_group ON articles(duplicate_group)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_campaign_cluster ON articles(campaign_cluster)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles(published_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_status_published ON articles(status, published_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_feed_id_created ON articles(feed_id, created_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_unique_key ON articles(unique_key)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_updated_at ON articles(updated_at DESC)")
        for key, value in DEFAULT_SETTINGS.items():
            conn.execute('INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)', (key, value))
    _invalidate_runtime_caches()


def list_feeds() -> list[dict[str, Any]]:
    def _loader():
        with get_conn(read_only=True) as conn:
            rows = conn.execute('SELECT * FROM feeds ORDER BY is_enabled DESC, name COLLATE NOCASE ASC').fetchall()
        return [row_to_dict(row) for row in rows]
    return _cached_payload('feeds', SHORT_CACHE_TTL_SECONDS, _loader)


def add_feed(name: str | None, url: str) -> dict[str, Any]:
    normalized_url = normalize_feed_url(url)
    final_name = (name or '').strip() or derive_feed_name(normalized_url)
    with get_conn() as conn:
        conn.execute('INSERT OR IGNORE INTO feeds(name, url, is_enabled) VALUES(?, ?, 1)', (final_name, normalized_url))
        row = conn.execute('SELECT * FROM feeds WHERE url = ?', (normalized_url,)).fetchone()
    _invalidate_runtime_caches()
    return row_to_dict(row) or {}


def toggle_feed(feed_id: int, is_enabled: bool) -> dict[str, Any] | None:
    with get_conn() as conn:
        conn.execute('UPDATE feeds SET is_enabled = ? WHERE id = ?', (1 if is_enabled else 0, feed_id))
        row = conn.execute('SELECT * FROM feeds WHERE id = ?', (feed_id,)).fetchone()
    _invalidate_runtime_caches()
    return row_to_dict(row)


def delete_feed(feed_id: int) -> None:
    with get_conn() as conn:
        conn.execute('DELETE FROM feeds WHERE id = ?', (feed_id,))
    _invalidate_runtime_caches()


def get_settings(*, force: bool = False) -> dict[str, Any]:
    def _loader():
        with get_conn(read_only=True) as conn:
            rows = conn.execute('SELECT key, value FROM settings').fetchall()
        settings = {row['key']: row['value'] for row in rows}
        merged = DEFAULT_SETTINGS | settings
        merged['poll_interval_seconds'] = int(merged['poll_interval_seconds'])
        merged['max_articles_per_feed'] = int(merged['max_articles_per_feed'])
        merged['auto_refresh_enabled'] = str(merged['auto_refresh_enabled']) == '1'
        merged['hide_duplicates'] = str(merged['hide_duplicates']) == '1'
        merged['semantic_reranking'] = str(merged.get('semantic_reranking', '1')) == '1'
        merged['feedback_learning'] = str(merged.get('feedback_learning', '1')) == '1'
        return merged
    return _cached_payload('settings', SETTINGS_CACHE_TTL_SECONDS, _loader, force=force)


def update_settings(changes: dict[str, Any]) -> dict[str, Any]:
    allowed = {'prompt', 'poll_interval_seconds', 'max_articles_per_feed', 'auto_refresh_enabled', 'date_window', 'relevance_mode', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'}
    with get_conn() as conn:
        for key, value in changes.items():
            if key not in allowed or value is None:
                continue
            if key in {'auto_refresh_enabled', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'}:
                value = '1' if bool(value) else '0'
            else:
                value = str(value)
            conn.execute('''
                INSERT INTO settings(key, value) VALUES(?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
            ''', (key, value))
    _invalidate_runtime_caches()
    return get_settings(force=True)


def _fetch_article_rows(*, limit: int, offset: int = 0, status: str = 'all', sector: str = 'all', columns: str = '*') -> list[sqlite3.Row]:
    query = f'SELECT {columns} FROM articles'
    params: list[Any] = []
    clauses: list[str] = []
    if status != 'all':
        clauses.append('status = ?')
        params.append(status)
    if sector == 'general':
        sector_clause, sector_params = _sector_clause(sector_aliases('marcas_retail'))
        if sector_clause:
            clauses.append(f'NOT {sector_clause}')
            params.extend(sector_params)
    elif sector != 'all':
        aliases = sector_aliases(sector)
        sector_clause, sector_params = _sector_clause(aliases)
        if sector_clause:
            clauses.append(sector_clause)
            params.extend(sector_params)
    if clauses:
        query += ' WHERE ' + ' AND '.join(clauses)
    query += '''
        ORDER BY
            COALESCE(NULLIF(published_at, ''), created_at) DESC,
            relevance_score DESC,
            id DESC
        LIMIT ? OFFSET ?
    '''
    params.extend([max(1, int(limit)), max(0, int(offset))])
    with get_conn(read_only=True) as conn:
        return conn.execute(query, params).fetchall()


def fetch_articles_batch(limit: int = 250, offset: int = 0, status: str = 'all', sector: str = 'all', columns: str | None = None) -> list[dict[str, Any]]:
    rows = _fetch_article_rows(limit=limit, offset=offset, status=status, sector=sector, columns=columns or ARTICLE_LIGHT_COLUMNS)
    return [row_to_dict(row) for row in rows]


def _dedupe_rows(rows: list[sqlite3.Row], hide_duplicates: bool | None = None) -> list[sqlite3.Row]:
    if hide_duplicates is None:
        hide_duplicates = bool(get_settings().get('hide_duplicates', True))
    if not hide_duplicates:
        return rows
    seen: set[str] = set()
    output: list[sqlite3.Row] = []
    for row in rows:
        key = row['duplicate_group'] or row['cluster_key'] or row['title']
        if key in seen:
            continue
        seen.add(key)
        output.append(row)
    return output


def list_articles(limit: int = 100, status: str = 'all', sector: str = 'all') -> list[dict[str, Any]]:
    hide_duplicates = bool(get_settings().get('hide_duplicates', True))
    rows = _fetch_article_rows(limit=max(limit * 4, 200), offset=0, status=status, sector=sector, columns='*')
    rows = _dedupe_rows(rows, hide_duplicates=hide_duplicates)[:limit]
    return [row_to_dict(row) for row in rows]


def list_articles_unbounded(status: str = 'all', sector: str = 'all', dedupe: bool = True) -> list[dict[str, Any]]:
    rows = _fetch_article_rows(limit=1000000, offset=0, status=status, sector=sector, columns=ARTICLE_LIGHT_COLUMNS)
    if dedupe:
        rows = _dedupe_rows(rows, hide_duplicates=bool(get_settings().get('hide_duplicates', True)))
    return [row_to_dict(row) for row in rows]


def list_sector_articles(sector: str = 'marcas_retail', include_excluded: bool = False) -> list[dict[str, Any]]:
    status = 'all' if include_excluded else 'pending'
    rows = _fetch_article_rows(limit=1000000, offset=0, status='all', sector=sector, columns=ARTICLE_LIGHT_COLUMNS)
    if not include_excluded:
        rows = [row for row in rows if row['status'] != 'excluded']
    return [row_to_dict(row) for row in rows]


def get_article(article_id: int) -> dict[str, Any] | None:
    with get_conn(read_only=True) as conn:
        row = conn.execute('SELECT * FROM articles WHERE id = ?', (article_id,)).fetchone()
    return row_to_dict(row)


def _iter_chunks(items: list[Any], size: int = 400):
    for start in range(0, len(items), size):
        yield items[start:start + size]


def upsert_articles(articles: list[dict[str, Any]]) -> int:
    inserted = 0
    if not articles:
        return inserted
    unique_keys = [str(article.get('unique_key') or '') for article in articles if str(article.get('unique_key') or '').strip()]
    with get_conn() as conn:
        existing: dict[str, sqlite3.Row] = {}
        for chunk in _iter_chunks(unique_keys, 400):
            placeholders = ','.join('?' for _ in chunk)
            rows = conn.execute(f"SELECT unique_key, id, status, COALESCE(status_origin, 'auto') AS status_origin FROM articles WHERE unique_key IN ({placeholders})", chunk).fetchall()
            for row in rows:
                existing[row['unique_key']] = row

        for article in articles:
            unique_key = str(article.get('unique_key') or '')
            if not unique_key:
                continue
            exists = existing.get(unique_key)
            if exists:
                if exists['status_origin'] == 'manual':
                    conn.execute('''
                        UPDATE articles
                        SET feed_id = ?, feed_name = ?, feed_url = ?, title = ?, article_url = ?, feedly_url = ?,
                            summary = ?, content = ?, published_at = ?, image_url = ?, video_url = ?,
                            match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?, entities_json = ?, sector_categories = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE unique_key = ?
                    ''', (
                        article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'),
                        article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'),
                        article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('sector_categories', '[]'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''), unique_key,
                    ))
                else:
                    conn.execute('''
                        UPDATE articles
                        SET feed_id = ?, feed_name = ?, feed_url = ?, title = ?, article_url = ?, feedly_url = ?,
                            summary = ?, content = ?, published_at = ?, image_url = ?, video_url = ?, status = ?, status_origin = ?,
                            match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?, entities_json = ?, sector_categories = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE unique_key = ?
                    ''', (
                        article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'),
                        article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'),
                        article.get('status', 'pending'), article.get('status_origin', 'auto'), article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('sector_categories', '[]'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''), unique_key,
                    ))
                continue
            conn.execute('''
                INSERT INTO articles(
                    unique_key, feed_id, feed_name, feed_url, title, article_url, feedly_url,
                    summary, content, published_at, image_url, video_url, status,
                    status_origin, match_tags, cluster_key, duplicate_group, duplicate_rank, campaign_cluster, entities_json, sector_categories, semantic_score, feedback_score, relevance_score, rationale
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                unique_key, article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'), article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'), article.get('status', 'pending'), article.get('status_origin', 'auto'), article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('sector_categories', '[]'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''),
            ))
            inserted += 1
    _invalidate_runtime_caches()
    return inserted


def update_article_status(article_id: int, status: str) -> dict[str, Any] | None:
    with get_conn() as conn:
        before = conn.execute('SELECT status FROM articles WHERE id = ?', (article_id,)).fetchone()
        previous_status = before['status'] if before else None
        conn.execute("UPDATE articles SET status = ?, status_origin = 'manual', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (status, article_id))
        conn.execute('INSERT INTO feedback_events(article_id, previous_status, new_status) VALUES(?, ?, ?)', (article_id, previous_status, status))
        row = conn.execute('SELECT * FROM articles WHERE id = ?', (article_id,)).fetchone()
    _invalidate_runtime_caches()
    return row_to_dict(row)


def rescore_articles(prompt: str, date_window: str = 'all', relevance_mode: str = 'balanced') -> int:
    from .intelligence import analyze_articles
    with get_conn(read_only=True) as conn:
        rows = [row_to_dict(row) for row in conn.execute('SELECT * FROM articles').fetchall()]
    analyzed = analyze_articles([row or {} for row in rows], prompt, date_window=date_window, relevance_mode=relevance_mode)
    with get_conn() as conn:
        for row in analyzed:
            if row.get('status_origin') == 'manual':
                conn.execute('''
                    UPDATE articles
                    SET match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?,
                        entities_json = ?, sector_categories = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (json.dumps(row.get('match_tags') or [], ensure_ascii=False), row.get('cluster_key'), row.get('duplicate_group'), row.get('duplicate_rank', 1), row.get('campaign_cluster'), json.dumps(row.get('entities') or {}, ensure_ascii=False), json.dumps(row.get('sector_categories') or [], ensure_ascii=False), row.get('semantic_score', 0), row.get('feedback_score', 0), row.get('hybrid_score', row.get('relevance_score', 0)), row.get('rationale', ''), row['id']))
            else:
                conn.execute('''
                    UPDATE articles
                    SET status = ?, status_origin = 'auto', match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?,
                        entities_json = ?, sector_categories = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (row.get('computed_status', row.get('status', 'pending')), json.dumps(row.get('match_tags') or [], ensure_ascii=False), row.get('cluster_key'), row.get('duplicate_group'), row.get('duplicate_rank', 1), row.get('campaign_cluster'), json.dumps(row.get('entities') or {}, ensure_ascii=False), json.dumps(row.get('sector_categories') or [], ensure_ascii=False), row.get('semantic_score', 0), row.get('feedback_score', 0), row.get('hybrid_score', row.get('relevance_score', 0)), row.get('rationale', ''), row['id']))
    _invalidate_runtime_caches()
    return len(analyzed)


def stats() -> dict[str, Any]:
    def _loader():
        with get_conn(read_only=True) as conn:
            row = conn.execute('''
                SELECT COUNT(*) AS total_articles,
                    SUM(CASE WHEN status = 'included' THEN 1 ELSE 0 END) AS included_count,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_count,
                    SUM(CASE WHEN status = 'excluded' THEN 1 ELSE 0 END) AS excluded_count
                FROM articles
            ''').fetchone()
            feed_count = conn.execute('SELECT COUNT(*) AS c FROM feeds').fetchone()['c']
        return {'total_articles': row['total_articles'] or 0, 'included_count': row['included_count'] or 0, 'pending_count': row['pending_count'] or 0, 'excluded_count': row['excluded_count'] or 0, 'feed_count': feed_count}
    return _cached_payload('stats', SHORT_CACHE_TTL_SECONDS, _loader)


def feedback_summary() -> dict[str, Any]:
    def _loader():
        with get_conn(read_only=True) as conn:
            row = conn.execute("SELECT COUNT(*) AS total, SUM(CASE WHEN new_status = 'included' THEN 1 ELSE 0 END) AS included, SUM(CASE WHEN new_status = 'excluded' THEN 1 ELSE 0 END) AS excluded FROM feedback_events").fetchone()
        return {'feedback_events': row['total'] or 0, 'feedback_included': row['included'] or 0, 'feedback_excluded': row['excluded'] or 0}
    return _cached_payload('feedback', SHORT_CACHE_TTL_SECONDS, _loader)

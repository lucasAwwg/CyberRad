from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
import re

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import simpleSplit
from reportlab.pdfgen import canvas

from .brands_map import (
    ATTACK_KEYWORDS,
    GLOBAL_COUNTRY_TERMS,
    COUNTRY_ALIASES,
    MAP_IMAGE_HEIGHT,
    MAP_IMAGE_PATH,
    MAP_IMAGE_WIDTH,
    MIN_BRANDS_MAP_YEAR,
    country_key,
    has_marcas_sector,
    infer_attack_label,
    BRAND_TO_COUNTRY,
    infer_country_and_brand,
    normalize_country_name,
    project_country_to_map,
    world_xy,
    year_for_article,
)
from .rss import normalize_spaces, source_profile, satisfies_strict_cyber_requirement

DIRECT_INCIDENT_TERMS = {
    'ransomware', 'breach', 'breached', 'data breach', 'data leak', 'hack', 'hacked', 'attack', 'attacked',
    'cyberattack', 'cyber attack', 'ciberataque', 'cybersecurity incident', 'security incident',
    'compromise', 'compromised', 'leak', 'leaked', 'ddos', 'distributed denial of service',
    'service disruption', 'outage', 'unauthorized access', 'phishing', 'malware', 'intrusion',
    'extortion', 'stolen data', 'customer data', 'credential theft', 'credential stuffing',
    'account takeover', 'magecart', 'payment breach', 'skimmer', 'web skimmer',
    'checkout compromise', 'exfiltration', 'data exposure', 'website defacement',
    'supply chain attack', 'infostealer'
}
ADVISORY_NOISE_TERMS = {
    'practical advice', 'advice', 'guide', 'guidance', 'analysis', 'research', 'report',
    'fundamentals', 'define goals', 'read actionable advice', 'best practices', 'podcast',
    'webinar', 'survey', 'newsletter', 'predictions', 'forecast', 'roundup'
}

STRONG_INCIDENT_CORE = {
    'ransomware', 'breach', 'breached', 'data breach', 'data leak', 'hacked', 'hack', 'attack', 'attacked',
    'cyberattack', 'cyber attack', 'cybersecurity incident', 'security incident',
    'compromise', 'compromised', 'leak', 'leaked', 'ddos', 'distributed denial of service',
    'service disruption', 'outage', 'unauthorized access', 'malware', 'intrusion', 'extortion',
    'magecart', 'payment breach', 'skimmer', 'stolen data', 'customer data',
    'credential theft', 'credential stuffing', 'account takeover', 'web skimmer',
    'checkout compromise', 'exfiltration', 'website defacement', 'supply chain attack', 'infostealer'
}

EXPLICIT_INCIDENT_OUTCOME_TERMS = {
    'breach', 'breached', 'data breach', 'data leak', 'hacked', 'attack', 'attacked',
    'cyberattack', 'cyber attack', 'security incident', 'cybersecurity incident',
    'compromise', 'compromised', 'leak', 'leaked', 'ddos', 'service disruption',
    'outage', 'unauthorized access', 'intrusion', 'extortion', 'payment breach',
    'skimmer', 'stolen data', 'customer data', 'credential theft', 'credential stuffing',
    'account takeover', 'checkout compromise', 'exfiltration', 'website defacement', 'supply chain attack'
}

ENTERTAINMENT_NOISE_TERMS = {
    'kanye west', ' ye ', " ye's", 'perdón público', 'perdon publico', 'fans', 'celebrity',
    'album', 'music', 'grammys', 'oscars', 'fashion week', 'runway', 'red carpet', 'festival',
    'gossip', 'viral', 'influencer', 'podcast', 'opinion', 'editorial', 'review', 'street style'
}

RETAIL_CONTEXT_TERMS = {
    'fashion', 'apparel', 'clothing', 'textile', 'retail', 'retailer', 'brand', 'brands', 'store', 'shop',
    'ecommerce', 'e-commerce', 'marketplace', 'luxury', 'footwear', 'sneaker', 'moda', 'ropa', 'textil', 'lujo', 'calzado'
}

TITLE_CYBER_CONTEXT_TERMS = {
    'cyber', 'cybersecurity', 'security', 'ransomware', 'breach', 'data breach', 'data leak', 'hack', 'hacked',
    'cyberattack', 'cyber attack', 'incident', 'security incident', 'malware', 'phishing', 'outage', 'compromise'
}

AMBIGUOUS_BRANDS = {'next', 'guess', 'coach', 'gap', 'goat', 'cider', 'cos', 'arket', 'weekday', 'monki', 'revolve', 'hm', 'm&s', 'stockx'}
BRAND_LABELS = {k: k.title() for k in BRAND_TO_COUNTRY.keys()}
BRAND_LABELS.update({
    'h&m': 'H&M', 'hm group': 'H&M Group', 'm&s': 'Marks & Spencer', 'macys': "Macy's", "macy's": "Macy's",
    'hugo boss': 'Hugo Boss', 'pepe jeans': 'Pepe Jeans', 'jd sports': 'JD Sports', 'new look': 'New Look',
    'foot locker': 'Foot Locker', 'dr martens': 'Dr. Martens', 'banana republic': 'Banana Republic',
})

TECH_BRAND_KEYS = {'apple', 'samsung'}
STRICT_INCIDENT_BRAND_KEYS = {'walmart', 'carrefour', 'ikea', 'fnac', 'mediamarkt', 'target', 'best buy', 'costco'}


def _norm(text: str | None) -> str:
    return normalize_spaces(text or '')


def core_blob(article: dict[str, Any]) -> str:
    return ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
        article.get('content') or '',
    ])


def title_summary_blob(article: dict[str, Any]) -> str:
    return ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
    ])


def source_blob(article: dict[str, Any]) -> str:
    return ' '.join([
        article.get('feed_name') or '',
        article.get('feed_url') or '',
        article.get('article_url') or '',
        article.get('rationale') or '',
    ])


def article_blob(article: dict[str, Any]) -> str:
    return ' '.join([core_blob(article), source_blob(article)])


def _has_phrase(text: str, term: str) -> bool:
    return re.search(rf'(?<!\w){re.escape(term)}(?!\w)', text) is not None


def _term_hits(text: str, terms: set[str]) -> list[str]:
    return [term for term in sorted(terms, key=len, reverse=True) if _has_phrase(text, term)]


def _has_retail_context(text: str) -> bool:
    return any(_has_phrase(text, term) for term in RETAIL_CONTEXT_TERMS)


def has_direct_cyber_signal(article: dict[str, Any], *, include_source: bool = False) -> bool:
    blob = _norm(core_blob(article))
    if include_source:
        blob = f"{blob} {_norm(source_blob(article))}".strip()
    return bool(_term_hits(blob, DIRECT_INCIDENT_TERMS))


def detect_known_brand_key(article: dict[str, Any]) -> str | None:
    primary_blob = _norm(core_blob(article))
    title_blob = _norm(title_summary_blob(article))
    for brand in sorted(BRAND_TO_COUNTRY.keys(), key=len, reverse=True):
        if not _has_phrase(primary_blob, brand):
            continue
        if brand in AMBIGUOUS_BRANDS:
            context_blob = f"{primary_blob} {title_blob}"
            if not _has_retail_context(context_blob) and not any(_has_phrase(context_blob, hint) for hint in ('plc', 'inc', 'group', 'retailer', 'brand', 'fashion', 'apparel', 'clothing', 'marketplace', 'sneaker')):
                continue
        return brand
    return None


def detect_known_brand(article: dict[str, Any]) -> str | None:
    brand_key = detect_known_brand_key(article)
    if not brand_key:
        return None
    return BRAND_LABELS.get(brand_key, brand_key.title())


def has_strong_incident_core(article: dict[str, Any]) -> bool:
    text = _norm(core_blob(article))
    return bool(_term_hits(text, STRONG_INCIDENT_CORE))


def has_explicit_incident_outcome(article: dict[str, Any]) -> bool:
    text = _norm(title_summary_blob(article))
    return bool(_term_hits(text, EXPLICIT_INCIDENT_OUTCOME_TERMS))


def has_title_incident_signal(article: dict[str, Any]) -> bool:
    text = _norm(title_summary_blob(article))
    return bool(_term_hits(text, STRONG_INCIDENT_CORE | {'phishing'}))

def has_title_cyber_context(article: dict[str, Any]) -> bool:
    text = _norm(title_summary_blob(article))
    return bool(_term_hits(text, TITLE_CYBER_CONTEXT_TERMS))


def has_country_or_brand_anchor(article: dict[str, Any]) -> bool:
    country, _source = infer_country_general(article)
    if country:
        return True
    return detect_known_brand(article) is not None


def has_curated_general_context(article: dict[str, Any]) -> bool:
    source = _norm(source_blob(article))
    return any(term in source for term in (
        'google news -', 'bleepingcomputer', 'dark reading', 'crowdstrike', 'cisa',
        'cis advisories', 'recorded future', 'therecord', 'securityweek', 'hackread',
        'cybersecuritynews', 'the hacker news'
    ))


def has_strong_general_story(article: dict[str, Any]) -> bool:
    title_hit = has_title_incident_signal(article)
    title_cyber = has_title_cyber_context(article)
    direct_hit = has_direct_cyber_signal(article, include_source=True)
    anchored = has_country_or_brand_anchor(article)
    curated = has_curated_general_context(article)
    return (title_hit and anchored) or (direct_hit and anchored) or (title_hit and curated) or (title_cyber and curated and anchored)


def has_entertainment_noise(article: dict[str, Any]) -> bool:
    text = _norm(core_blob(article))
    return any(term in text for term in ENTERTAINMENT_NOISE_TERMS)


def validated_general_article(article: dict[str, Any]) -> bool:
    if validated_marcas_article(article):
        return False
    text = _norm(core_blob(article))
    if has_entertainment_noise(article):
        return False
    direct_hit = has_direct_cyber_signal(article, include_source=True)
    strong_story = has_strong_general_story(article)
    anchored = has_country_or_brand_anchor(article)
    title_cyber = has_title_cyber_context(article)
    curated = has_curated_general_context(article)
    if not direct_hit and not strong_story and not (anchored and curated and title_cyber):
        return False
    if any(term in text for term in ADVISORY_NOISE_TERMS) and not (has_explicit_incident_outcome(article) or (curated and anchored and title_cyber)):
        return False
    return True


def relaxed_general_article(article: dict[str, Any]) -> bool:
    # Versión algo más permisiva para no vaciar la vista General ni el mapa
    # cuando entran titulares reales pero el texto RSS es corto o incompleto.
    if validated_marcas_article(article):
        return False
    if has_entertainment_noise(article):
        return False
    text = _norm(core_blob(article))
    anchored = has_country_or_brand_anchor(article)
    curated = has_curated_general_context(article)
    direct_hit = has_direct_cyber_signal(article, include_source=True)
    strong_core = has_strong_incident_core(article)
    title_hit = has_title_incident_signal(article)
    title_cyber = has_title_cyber_context(article)
    score = float(article.get('relevance_score') or 0)
    semantic = float(article.get('semantic_score') or 0)
    hybrid_signal = max(score, semantic)

    if not anchored:
        return False

    advisory_noise = any(term in text for term in ADVISORY_NOISE_TERMS)
    if advisory_noise and not (has_explicit_incident_outcome(article) or hybrid_signal >= 0.62):
        return False

    if validated_general_article(article):
        return True
    if direct_hit and (title_hit or curated or hybrid_signal >= 0.18):
        return True
    if title_hit:
        return True
    if title_cyber and curated:
        return True
    if strong_core and (curated or hybrid_signal >= 0.22):
        return True
    if hybrid_signal >= 0.52 and (direct_hit or title_cyber):
        return True
    return False




COMMON_HOST_COUNTRY_HINTS: tuple[tuple[str, str], ...] = (
    ('.co.uk', 'United Kingdom'),
    ('.uk', 'United Kingdom'),
    ('.fr', 'France'),
    ('.de', 'Germany'),
    ('.it', 'Italy'),
    ('.es', 'Spain'),
    ('.pt', 'Portugal'),
    ('.ie', 'Ireland'),
    ('.nl', 'Netherlands'),
    ('.be', 'Belgium'),
    ('.jp', 'Japan'),
    ('.au', 'Australia'),
    ('.nz', 'New Zealand'),
    ('.ca', 'Canada'),
    ('.mx', 'Mexico'),
    ('.br', 'Brazil'),
    ('.ar', 'Argentina'),
    ('.cl', 'Chile'),
    ('.co', 'Colombia'),
    ('.in', 'India'),
    ('.sg', 'Singapore'),
    ('.sa', 'Saudi Arabia'),
    ('.ae', 'United Arab Emirates'),
    ('.za', 'South Africa'),
)


def _infer_country_from_host(value: str | None) -> tuple[str | None, str]:
    raw = (value or '').strip()
    if not raw:
        return None, 'unknown'
    try:
        host = (urlparse(raw).netloc or raw).lower()
    except Exception:
        host = raw.lower()
    host = host.split(':', 1)[0]
    if host.startswith('www.'):
        host = host[4:]
    for suffix, country in COMMON_HOST_COUNTRY_HINTS:
        if host.endswith(suffix):
            return normalize_country_name(country), 'host-tld'
    return None, 'unknown'


def general_display_article(article: dict[str, Any]) -> bool:
    if validated_marcas_article(article):
        return False
    if has_entertainment_noise(article):
        return False
    text = _norm(core_blob(article))
    direct_hit = has_direct_cyber_signal(article, include_source=True)
    strong_core = has_strong_incident_core(article)
    title_hit = has_title_incident_signal(article)
    title_cyber = has_title_cyber_context(article)
    curated = has_curated_general_context(article)
    score = float(article.get('relevance_score') or 0)
    semantic = float(article.get('semantic_score') or 0)
    hybrid_signal = max(score, semantic)

    advisory_noise = any(term in text for term in ADVISORY_NOISE_TERMS)
    if advisory_noise and not (has_explicit_incident_outcome(article) or title_hit or hybrid_signal >= 0.68):
        return False

    if validated_general_article(article) or relaxed_general_article(article):
        return True
    if direct_hit and (title_hit or title_cyber or curated or hybrid_signal >= 0.15):
        return True
    if title_hit:
        return True
    if title_cyber and (curated or hybrid_signal >= 0.48):
        return True
    if strong_core and (curated or hybrid_signal >= 0.26):
        return True
    if hybrid_signal >= 0.58 and (direct_hit or title_cyber or strong_core):
        return True
    return False


def general_map_article(article: dict[str, Any]) -> bool:
    if validated_marcas_article(article):
        return False
    if has_entertainment_noise(article):
        return False
    if validated_general_article(article) or relaxed_general_article(article):
        return True

    country, _source = infer_country_general(article)
    if not country:
        return False

    text = _norm(core_blob(article))
    direct_hit = has_direct_cyber_signal(article, include_source=True)
    strong_core = has_strong_incident_core(article)
    title_hit = has_title_incident_signal(article)
    title_cyber = has_title_cyber_context(article)
    curated = has_curated_general_context(article)
    score = float(article.get('relevance_score') or 0)
    semantic = float(article.get('semantic_score') or 0)
    hybrid_signal = max(score, semantic)

    advisory_noise = any(term in text for term in ADVISORY_NOISE_TERMS)
    if advisory_noise and not (has_explicit_incident_outcome(article) or title_hit or hybrid_signal >= 0.70):
        return False

    return bool(
        title_hit
        or (direct_hit and (curated or hybrid_signal >= 0.16))
        or (title_cyber and curated)
        or (strong_core and hybrid_signal >= 0.24)
        or hybrid_signal >= 0.60
    )


def validated_marcas_article(article: dict[str, Any]) -> bool:
    brand = detect_known_brand(article)
    if not brand:
        return False
    text = _norm(core_blob(article))
    title_summary = _norm(title_summary_blob(article))
    if not has_direct_cyber_signal(article, include_source=False):
        return False
    if has_entertainment_noise(article):
        return False
    if any(term in text for term in ADVISORY_NOISE_TERMS) and not has_strong_incident_core(article):
        return False
    brand_norm = _norm(brand)
    brand_in_core = _has_phrase(text, brand_norm)
    brand_in_title_summary = _has_phrase(title_summary, brand_norm)
    attack_in_title_summary = bool(_term_hits(title_summary, STRONG_INCIDENT_CORE | {'phishing'}))
    if not brand_in_core:
        return False
    # Para Marcas la víctima debe aparecer claramente en título/resumen o, al menos,
    # el titular debe hablar de un incidente real mientras la marca se menciona en el cuerpo.
    if not brand_in_title_summary and not attack_in_title_summary:
        return False
    # Evita artículos donde la marca sale perdida en un cuerpo largo pero el foco real es otro.
    if not brand_in_title_summary and len(text) > 900:
        return False
    return True


def display_sector(article: dict[str, Any], purpose: str = 'display') -> str:
    if validated_marcas_article(article):
        return 'marcas_retail'
    if purpose == 'map':
        if general_map_article(article):
            return 'general'
    else:
        if general_display_article(article):
            return 'general'
    return 'discarded'


def filter_articles_for_sector_display(articles: list[dict[str, Any]], sector: str = 'general', purpose: str = 'display') -> list[dict[str, Any]]:
    sector_norm = (sector or 'general').strip().lower()
    mode = 'map' if purpose == 'map' else 'display'
    output: list[dict[str, Any]] = []
    for article in articles:
        visible_sector = display_sector(article, purpose=mode)
        if visible_sector == 'discarded':
            continue
        if sector_norm == 'marcas_retail' and visible_sector != 'marcas_retail':
            continue
        if sector_norm == 'general' and visible_sector not in {'general', 'marcas_retail'}:
            continue
        item = dict(article)
        item['display_sector'] = visible_sector
        output.append(item)
    return output


def infer_country_general(article: dict[str, Any]) -> tuple[str | None, str]:
    entities = article.get('entities') or {}
    for field in ('locations', 'countries'):
        for value in entities.get(field, []) or []:
            canonical = normalize_country_name(value)
            if canonical:
                return canonical, 'entity-country'

    text = _norm(article_blob(article))
    for country, aliases in COUNTRY_ALIASES.items():
        for alias in aliases:
            if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', text):
                return normalize_country_name(country), 'country'

    for alias, canonical in GLOBAL_COUNTRY_TERMS:
        if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', text):
            return normalize_country_name(canonical), 'country-global'

    for field in ('feed_url', 'article_url'):
        canonical, source = _infer_country_from_host(article.get(field) or '')
        if canonical:
            return canonical, source

    brand = detect_known_brand(article)
    if brand:
        for key, label in BRAND_LABELS.items():
            if label == brand and key in BRAND_TO_COUNTRY:
                return normalize_country_name(BRAND_TO_COUNTRY[key]), 'brand-country'

    return None, 'unknown'


def infer_target_label(article: dict[str, Any], sector: str) -> str:
    brand = detect_known_brand(article)
    if sector == 'marcas_retail':
        return brand or 'Marca validada'
    entities = article.get('entities') or {}
    vendors = entities.get('vendors') or []
    if vendors:
        return str(vendors[0])
    return article.get('feed_name') or 'Incidente general'



def _year_selection(rows: list[dict[str, Any]], selected_year: int | str | None):
    current_year = datetime.now().year
    active_year = current_year
    active_rows = [row for row in rows if int(row.get('year') or year_for_article(row)) == current_year]
    year_counts = {str(current_year): len(active_rows)}
    years_payload = [str(current_year)]
    return active_rows, years_payload, year_counts, str(active_year), 'current', str(current_year), str(current_year)


def _point_payload(country: str, grouped_items: list[dict[str, Any]], count: int) -> dict[str, Any]:
    x, y = world_xy(country)
    latest = grouped_items[0] if grouped_items else {}
    x_pct = round((x / MAP_IMAGE_WIDTH) * 100.0, 3)
    y_pct = round((y / MAP_IMAGE_HEIGHT) * 100.0, 3)
    labels = []
    for item in grouped_items:
        label = item.get('label')
        if label and label not in labels:
            labels.append(label)
    attack_types = []
    for item in grouped_items:
        attack = item.get('attack_type')
        if attack and attack not in attack_types:
            attack_types.append(attack)
    return {
        'country': country,
        'country_key': country_key(country),
        'count': count,
        'x': round(x, 2),
        'y': round(y, 2),
        'x_pct': x_pct,
        'y_pct': y_pct,
        'labels': labels[:6],
        'attack_types': attack_types[:6],
        'article_ids': [item['id'] for item in grouped_items if item.get('id')],
        'latest_date': latest.get('published_at'),
        'latest_label': latest.get('label') or '',
        'latest_attack_type': latest.get('attack_type') or 'Incidente ciber',
        'latest_source': latest.get('feed_name') or latest.get('source') or 'Fuente no inferida',
    }


def build_incident_map_data(articles: list[dict[str, Any]], sector: str = 'general', status: str = 'all', selected_year: int | str | None = None) -> dict[str, Any]:
    sector_norm = (sector or 'general').strip().lower()
    filtered = filter_articles_for_sector_display(articles, sector_norm if sector_norm in {'general', 'marcas_retail'} else 'general', purpose='map')
    diagnostics = {
        'input_articles': len(articles),
        'sector_visible': len(filtered),
        'status_visible': 0,
        'year_eligible': 0,
        'mapped_candidates': 0,
        'unmapped_candidates': 0,
        'latest_raw_year': None,
        'latest_usable_year': None,
    }
    if status != 'all':
        filtered = [row for row in filtered if row.get('status') == status]
    diagnostics['status_visible'] = len(filtered)
    filtered = [row for row in filtered if year_for_article(row) >= MIN_BRANDS_MAP_YEAR]
    diagnostics['year_eligible'] = len(filtered)

    preprocessed: list[dict[str, Any]] = []
    for article in filtered:
        article_year = year_for_article(article)
        if sector_norm == 'marcas_retail':
            country, brand, source = infer_country_and_brand(article)
            label = brand or detect_known_brand(article) or 'Marca validada'
        else:
            country, source = infer_country_general(article)
            label = infer_target_label(article, 'general')
        country = normalize_country_name(country) if country else None
        attack = infer_attack_label(article)
        px, py = project_country_to_map(country)
        mapped = bool(country and px is not None and py is not None)
        if mapped:
            diagnostics['mapped_candidates'] += 1
        else:
            diagnostics['unmapped_candidates'] += 1
        preprocessed.append({
            'article': article,
            'year': article_year,
            'country': country,
            'source': source,
            'label': label,
            'attack_type': attack,
            'mapped': mapped,
        })

    active_rows, years_payload, year_counts, active_year, selected_mode, latest_usable_year, latest_raw_year = _year_selection(preprocessed, selected_year)
    diagnostics['latest_raw_year'] = latest_raw_year
    diagnostics['latest_usable_year'] = latest_usable_year

    incidents: list[dict[str, Any]] = []
    country_counts: dict[str, int] = defaultdict(int)
    grouped_by_country: dict[str, list[dict[str, Any]]] = defaultdict(list)
    attack_counts: dict[str, int] = defaultdict(int)
    unresolved = 0
    status_counts = {
        'included': sum(1 for row in active_rows if row['article'].get('status') == 'included'),
        'pending': sum(1 for row in active_rows if row['article'].get('status') == 'pending'),
        'excluded': sum(1 for row in active_rows if row['article'].get('status') == 'excluded'),
    }

    for row in active_rows:
        article = row['article']
        country = row['country']
        attack = row['attack_type']
        incident = {
            'id': article.get('id'),
            'title': article.get('title') or 'Sin título',
            'country': country or 'No inferido',
            'country_key': country_key(country or 'No inferido'),
            'label': row['label'],
            'attack_type': attack,
            'published_at': article.get('published_at') or article.get('created_at'),
            'article_url': article.get('article_url') or '',
            'feed_name': article.get('feed_name') or '',
            'source': row['source'],
            'score': round(float(article.get('relevance_score') or 0), 3),
            'status': article.get('status') or 'pending',
        }
        incidents.append(incident)
        attack_counts[attack] += 1
        if row['mapped'] and country:
            country_counts[country] += 1
            grouped_by_country[country].append(incident)
        else:
            unresolved += 1

    incidents.sort(key=lambda item: item.get('published_at') or '', reverse=True)
    points = []
    for country, count in sorted(country_counts.items(), key=lambda kv: (-kv[1], kv[0])):
        grouped = sorted(grouped_by_country[country], key=lambda item: item.get('published_at') or '', reverse=True)
        points.append(_point_payload(country, grouped, count))

    top_countries = [
        {
            'country': point['country'],
            'count': point['count'],
            'labels': point['labels'][:4],
        }
        for point in points[:10]
    ]
    top_attacks = [
        {'label': label, 'count': count}
        for label, count in sorted(attack_counts.items(), key=lambda kv: (-kv[1], kv[0]))[:8]
    ]

    totals = {
        'all_articles': len(active_rows),
        'visible_articles': len(incidents),
        'mapped_articles': len([item for item in incidents if item['country'] != 'No inferido']),
        'incidents': len(active_rows),
        'countries': len(country_counts),
        'targets': len({item['label'] for item in incidents if item['label']}),
        'unresolved': unresolved,
        'included': status_counts['included'],
        'pending': status_counts['pending'],
        'excluded': status_counts['excluded'],
    }

    if sector_norm == 'marcas_retail':
        title = 'Mapa anual · Marcas'
        description = 'Solo víctimas válidas del sector textil / retail / moda / ecommerce detectadas por el filtro de Marcas.'
    else:
        title = 'Mapa anual · General'
        description = 'Noticias generales de ciberseguridad con país detectado por contexto o localización explícita.'

    return {
        'map_type': sector_norm,
        'title': title,
        'description': description,
        'year': str(active_year),
        'selected_mode': selected_mode,
        'available_years': years_payload,
        'latest_populated_year': str(latest_usable_year),
        'latest_raw_year': str(latest_raw_year),
        'year_counts': year_counts,
        'totals': totals,
        'points': points,
        'top_countries': top_countries,
        'top_attacks': top_attacks,
        'incidents': incidents[:40],
        'map_base_image': MAP_IMAGE_PATH,
        'methodology': 'El mapa usa anclas visuales por país. En Marcas se prioriza la marca víctima validada; en General se intenta inferir el país por contexto explícito, alias, dominio o marca conocida.',
        'diagnostics': diagnostics,
    }


# HOTFIX18_CLASSIFICATION_OVERRIDE
GENERAL_CYBER_TERMS = {
    'cyber', 'cybersecurity', 'security incident', 'security', 'cyber attack', 'cyberattack', 'breach', 'data breach',
    'data leak', 'ransomware', 'malware', 'phishing', 'infostealer', 'ddos', 'compromise', 'compromised',
    'credential theft', 'credential stuffing', 'account takeover', 'identity theft', 'zero trust', 'mfa', 'sso',
    'iam', 'identity access', 'identity and access', 'access control', 'threat detection', 'threat intel',
    'threat intelligence', 'soc', 'siem', 'xdr', 'edr', 'observability', 'monitoring', 'security operations',
    'incident response', 'data protection', 'privacy', 'compliance', 'fraud prevention', 'anti-fraud', 'abuse prevention',
    'vulnerability', 'vulnerabilities', 'exploit', 'exploited', 'cve', 'security advisory', 'security bulletin', 'patching', 'security flaw',
}
DIGITAL_INFRA_TERMS = {
    'cloud', 'cloud security', 'infrastructure', 'infrastructure security', 'hardening', 'resilience', 'resiliency',
    'backup', 'disaster recovery', 'network security', 'secure network', 'firewall', 'identity', 'access management',
    'iam', 'mfa', 'sso', 'endpoint security', 'server security', 'platform security', 'security posture',
    'security upgrade', 'security improvements', 'digital infrastructure', 'infraestructura tecnológica', 'infraestructura tecnologica',
    'observability', 'monitoring', 'logging', 'audit trail', 'vulnerability management', 'patching', 'zero trust',
    'cloud migration', 'datacenter', 'data center', 'resilience program', 'business continuity', 'disaster recovery',
}
AI_PROTECTION_TERMS = {
    'artificial intelligence', 'ai', 'machine learning', 'ml', 'llm', 'genai', 'fraud detection', 'abuse detection',
    'threat detection', 'defensive ai', 'security ai', 'identity verification', 'trust and safety', 'risk scoring',
    'brand protection', 'counterfeit detection', 'bot detection', 'threat hunting',
}
FRAUD_RISK_TERMS = {
    'fraud', 'digital fraud', 'online fraud', 'payment fraud', 'chargeback', 'scam', 'abuse', 'abusive', 'counterfeit',
    'counterfeiting', 'impersonation', 'takeover', 'account takeover', 'identity theft', 'risk', 'brand abuse',
    'payment security', 'checkout security', 'card fraud', 'e-skimming', 'magecart',
}
BRAND_RETAIL_CONTEXT_TERMS = RETAIL_CONTEXT_TERMS | {
    'fashion retail', 'retail tech', 'retail technology', 'point of sale', 'pos', 'supply chain', 'logistics',
    'warehouse', 'store operations', 'shop app', 'mobile app', 'omnichannel', 'payments', 'checkout',
    'customer account', 'customer identity', 'ecommerce security', 'e-commerce security', 'retail cybersecurity',
    'retail security', 'brand protection', 'marketplace integrity', 'supply chain security'
}
IRRELEVANT_GENERAL_TERMS = {
    'gunman', 'shooting', 'immigrants', 'amnesty', 'election', 'president', 'parliament', 'war', 'celebration',
    'festival', 'sports', 'football', 'soccer', 'basketball', 'celebrity', 'music', 'movie', 'weather', 'earthquake',
    'wildfire', 'homicide', 'murder', 'killed', 'injured', 'harvest', 'diplomatic talks', 'hezbollah',
    'missiles', 'bombard', 'bombardment', 'troops', 'battlefield', 'airstrike', 'drone strike',
    'attacked by dogs', 'dog attack', 'storytelling', 'brand campaign', 'marketing campaign', 'creative campaign',
    'life hack', 'fitness hack', 'health hack', 'beauty hack', 'productivity hack', 'travel hack', 'food hack',
}

STRICT_BRAND_CONTEXT_TERMS = {
    'retail', 'retailer', 'fashion', 'apparel', 'clothing', 'textile', 'luxury', 'footwear', 'ecommerce',
    'e-commerce', 'marketplace', 'store', 'shop', 'checkout', 'point of sale', 'pos', 'omnichannel',
    'brand protection', 'retail tech', 'retail technology', 'customer account', 'customer identity',
    'supply chain', 'warehouse', 'inventory', 'merchant', 'shopping app', 'shopping platform',
    'consumer electronics', 'electronics retail', 'smartphone brand', 'device maker', 'electronics retailer', 'electronics store',
}

BRAND_HARD_EXCLUSION_TERMS = {
    'gunman', 'shooting', 'court told', 'immigrants', 'amnesty', 'hezbollah', 'diplomatic talks',
    'harvest', 'festival', 'celebration', 'wildfire', 'earthquake', 'murder', 'homicide',
}


def _tag_set(article: dict[str, Any]) -> set[str]:
    return {normalize_spaces(str(item or '')).lower() for item in (article.get('match_tags') or []) if str(item or '').strip()}


def _sector_set(article: dict[str, Any]) -> set[str]:
    return {normalize_spaces(str(item or '')).lower() for item in (article.get('sector_categories') or []) if str(item or '').strip()}


def _text_hits(text: str, terms: set[str]) -> list[str]:
    return [term for term in sorted(terms, key=len, reverse=True) if _has_phrase(text, term)]


def _article_core_text(article: dict[str, Any]) -> str:
    return _norm(' '.join([
        article.get('title') or '',
        article.get('summary') or '',
        article.get('content') or '',
    ]))


def _article_title_text(article: dict[str, Any]) -> str:
    return _norm(' '.join([
        article.get('title') or '',
        article.get('summary') or '',
    ]))


def _brand_context_hits(article: dict[str, Any], text: str) -> list[str]:
    hits = _text_hits(text, BRAND_RETAIL_CONTEXT_TERMS)
    brand = detect_known_brand(article)
    if brand:
        hits.append(brand)
    return list(dict.fromkeys(hits))


def article_relevance_profile(article: dict[str, Any]) -> dict[str, Any]:
    text = _article_core_text(article)
    title = _article_title_text(article)
    tags = _tag_set(article)
    sector_tags = _sector_set(article)
    source_text = _norm(source_blob(article))
    source_meta = source_profile(article.get('feed_name') or '', article.get('feed_url') or '', article.get('article_url') or '')
    hybrid_score = max(float(article.get('relevance_score') or 0), float(article.get('semantic_score') or 0))

    incident_hits = _text_hits(text, DIRECT_INCIDENT_TERMS | STRONG_INCIDENT_CORE | EXPLICIT_INCIDENT_OUTCOME_TERMS)
    strong_incident_hits = [hit for hit in incident_hits if hit not in {'attack', 'attacked', 'hack', 'hacked', 'security', 'identity', 'risk', 'digital'}]
    cyber_hits = _text_hits(text, GENERAL_CYBER_TERMS)
    strong_cyber_hits = [hit for hit in cyber_hits if hit not in {'security', 'identity', 'privacy', 'compliance'}]
    infra_hits = _text_hits(text, DIGITAL_INFRA_TERMS)
    ai_hits = _text_hits(text, AI_PROTECTION_TERMS)
    fraud_hits = _text_hits(text, FRAUD_RISK_TERMS)
    brand_hits = _brand_context_hits(article, text)
    retail_hits = _text_hits(text, STRICT_BRAND_CONTEXT_TERMS)
    title_incident_hits = _text_hits(title, DIRECT_INCIDENT_TERMS | STRONG_INCIDENT_CORE | EXPLICIT_INCIDENT_OUTCOME_TERMS)
    title_security_hits = _text_hits(title, GENERAL_CYBER_TERMS | DIGITAL_INFRA_TERMS | AI_PROTECTION_TERMS | FRAUD_RISK_TERMS)
    title_retail_hits = _text_hits(title, STRICT_BRAND_CONTEXT_TERMS)
    irrelevant_hits = _text_hits(text, IRRELEVANT_GENERAL_TERMS)
    brand_exclusion_hits = _text_hits(text, BRAND_HARD_EXCLUSION_TERMS)

    tag_incident = bool(tags & {'incident', 'malware', 'ransomware', 'phishing', 'threatintel', 'vulnerability'})
    tag_digital = bool(tags & {'identity', 'cloud', 'observability', 'fraud', 'privacy', 'compliance', 'monitoring'})
    tag_brand = bool(sector_tags & {'marcas_retail'})
    known_brand_key = detect_known_brand_key(article)
    known_brand = BRAND_LABELS.get(known_brand_key, known_brand_key.title()) if known_brand_key else None

    strict_ok, strict_reasons = satisfies_strict_cyber_requirement(
        article.get('title') or '', article.get('summary') or '', article.get('content') or '',
        article.get('feed_name') or '', article.get('feed_url') or '', article.get('article_url') or ''
    )

    infra_security_combo = bool(infra_hits) and any(term in text for term in ('security', 'protection', 'hardening', 'iam', 'mfa', 'sso', 'identity', 'observability', 'monitoring', 'vulnerability', 'patching', 'fraud'))
    ai_security_combo = bool(ai_hits) and any(term in text for term in ('security', 'protection', 'defense', 'defence', 'fraud', 'abuse', 'identity verification', 'threat'))
    fraud_security_combo = bool(fraud_hits) and any(term in text for term in ('security', 'digital', 'online', 'ecommerce', 'checkout', 'payment', 'account'))

    has_incident = bool(strong_incident_hits or title_incident_hits or tag_incident)
    has_digital_security = bool(strong_cyber_hits or infra_security_combo or fraud_security_combo or title_security_hits or tag_digital)
    has_ai_security = bool(ai_security_combo)
    has_brand_anchor = bool(known_brand)
    has_retail_text_context = bool(retail_hits or title_retail_hits)
    has_brand_context = bool(brand_hits) or has_retail_text_context

    clearly_irrelevant = bool(irrelevant_hits or brand_exclusion_hits)
    if not strict_ok and not (infra_security_combo or ai_security_combo or fraud_security_combo):
        clearly_irrelevant = True

    explicit_general_signal = bool(has_incident or strong_cyber_hits or infra_security_combo or ai_security_combo or fraud_security_combo)
    source_support = source_meta.get('specialist_signal') or source_meta.get('is_feedly')
    primary_security_signal = bool(title_incident_hits or title_security_hits or has_incident or strong_cyber_hits)

    categories: list[str] = []
    if has_incident:
        categories.append('Incidente ciber')
    if fraud_hits:
        categories.append('Fraude / riesgo / abuso digital')
    if has_ai_security:
        categories.append('IA aplicada a seguridad o protección')
    if infra_security_combo and 'Infraestructura / tecnología / resiliencia' not in categories:
        categories.append('Infraestructura / tecnología / resiliencia')
    if has_brand_context:
        categories.append('Marca / retail / moda / ecommerce')
    if explicit_general_signal and 'General ciber / digital' not in categories:
        categories.append('General ciber / digital')

    general_relevant = (
        not clearly_irrelevant
        and explicit_general_signal
        and (strict_ok or infra_security_combo or ai_security_combo or fraud_security_combo)
        and (primary_security_signal or source_support or hybrid_score >= 0.56)
    )
    if source_meta.get('is_google_aggregator') and not primary_security_signal and hybrid_score < 0.72:
        general_relevant = False

    brand_anchor_score = sum([
        2 if has_brand_anchor else 0,
        1 if title_retail_hits else 0,
        1 if retail_hits else 0,
        1 if tag_brand else 0,
    ])

    marcas_relevant = (
        general_relevant
        and not clearly_irrelevant
        and (has_incident or infra_security_combo or ai_security_combo or fraud_security_combo)
        and brand_anchor_score >= 2
    )
    if known_brand_key in STRICT_INCIDENT_BRAND_KEYS and not has_incident:
        marcas_relevant = False
    if source_meta.get('is_google_aggregator') and brand_anchor_score < 3 and not has_incident and known_brand_key not in TECH_BRAND_KEYS:
        marcas_relevant = False

    dominant_label = 'General ciber / digital'
    if has_incident:
        dominant_label = infer_attack_label(article)
    elif fraud_hits:
        dominant_label = 'Fraude / riesgo digital'
    elif has_ai_security:
        dominant_label = 'IA aplicada a seguridad'
    elif infra_security_combo:
        dominant_label = 'Infraestructura / resiliencia'

    return {
        'general_relevant': general_relevant,
        'marcas_relevant': marcas_relevant,
        'dominant_label': dominant_label,
        'categories': categories,
        'brand_hits': brand_hits,
        'incident_hits': incident_hits,
        'cyber_hits': cyber_hits,
        'infra_hits': infra_hits,
        'ai_hits': ai_hits,
        'fraud_hits': fraud_hits,
        'clearly_irrelevant': clearly_irrelevant,
        'source_family': source_meta.get('source_family'),
        'strict_reasons': strict_reasons,
    }


def validated_marcas_article(article: dict[str, Any]) -> bool:
    profile = article_relevance_profile(article)
    return bool(profile['marcas_relevant'])


def validated_general_article(article: dict[str, Any]) -> bool:
    profile = article_relevance_profile(article)
    return bool(profile['general_relevant'])


def relaxed_general_article(article: dict[str, Any]) -> bool:
    return validated_general_article(article)


def general_display_article(article: dict[str, Any]) -> bool:
    return validated_general_article(article)


def general_map_article(article: dict[str, Any]) -> bool:
    return validated_general_article(article)


def preferred_display_sector(article: dict[str, Any]) -> str:
    profile = article_relevance_profile(article)
    if profile['marcas_relevant']:
        return 'marcas_retail'
    if profile['general_relevant']:
        return 'general'
    return 'discarded'


def display_sector(article: dict[str, Any], purpose: str = 'display') -> str:
    return preferred_display_sector(article)


def filter_articles_for_sector_display(articles: list[dict[str, Any]], sector: str = 'general', purpose: str = 'display') -> list[dict[str, Any]]:
    sector_norm = (sector or 'general').strip().lower()
    output: list[dict[str, Any]] = []
    for article in articles:
        profile = article_relevance_profile(article)
        include = profile['marcas_relevant'] if sector_norm == 'marcas_retail' else (profile['general_relevant'] and not profile['marcas_relevant'])
        if not include:
            continue
        item = dict(article)
        item['display_sector'] = preferred_display_sector(article)
        item['content_categories'] = profile['categories']
        item['content_label'] = profile['dominant_label']
        output.append(item)
    return output


def infer_country_general(article: dict[str, Any]) -> tuple[str | None, str]:
    entities = article.get('entities') or {}
    for field in ('locations', 'countries'):
        for value in entities.get(field, []) or []:
            canonical = normalize_country_name(value)
            if canonical:
                return canonical, 'entity-country'

    text = _article_core_text(article)
    for country, aliases in COUNTRY_ALIASES.items():
        for alias in aliases:
            if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', text):
                return normalize_country_name(country), 'country-alias'

    for alias, canonical in GLOBAL_COUNTRY_TERMS:
        if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', text):
            return normalize_country_name(canonical), 'country-global'

    brand = detect_known_brand(article)
    if brand:
        for key, label in BRAND_LABELS.items():
            if label == brand and key in BRAND_TO_COUNTRY:
                return normalize_country_name(BRAND_TO_COUNTRY[key]), 'brand-country'

    canonical, source = _infer_country_from_host(article.get('article_url') or '')
    if canonical:
        return canonical, source
    canonical, source = _infer_country_from_host(article.get('feed_url') or '')
    if canonical:
        return canonical, source
    return None, 'unknown'


def infer_target_label(article: dict[str, Any], sector: str) -> str:
    brand = detect_known_brand(article)
    entities = article.get('entities') or {}
    vendors = entities.get('vendors') or []
    if sector == 'marcas_retail':
        return brand or (str(vendors[0]) if vendors else 'Marca / retail validado')
    if brand:
        return brand
    if vendors:
        return str(vendors[0])
    return article.get('feed_name') or 'Incidente general'


def _point_payload(country: str, grouped_items: list[dict[str, Any]], count: int) -> dict[str, Any]:
    x, y = world_xy(country)
    latest = grouped_items[0] if grouped_items else {}
    x_pct = round((x / MAP_IMAGE_WIDTH) * 100.0, 3)
    y_pct = round((y / MAP_IMAGE_HEIGHT) * 100.0, 3)
    labels = []
    for item in grouped_items:
        label = item.get('label')
        if label and label not in labels:
            labels.append(label)
    attack_types = []
    for item in grouped_items:
        attack = item.get('attack_type')
        if attack and attack not in attack_types:
            attack_types.append(attack)
    categories = []
    for item in grouped_items:
        for category in item.get('content_categories') or []:
            if category and category not in categories:
                categories.append(category)
    return {
        'country': country,
        'country_key': country_key(country),
        'count': count,
        'x': round(x, 2),
        'y': round(y, 2),
        'x_pct': x_pct,
        'y_pct': y_pct,
        'labels': labels[:6],
        'attack_types': attack_types[:6],
        'content_categories': categories[:6],
        'article_ids': [item['id'] for item in grouped_items if item.get('id')],
        'latest_date': latest.get('published_at'),
        'latest_label': latest.get('label') or '',
        'latest_attack_type': latest.get('attack_type') or 'General ciber / digital',
        'latest_source': latest.get('feed_name') or latest.get('source') or 'Fuente no inferida',
    }


def build_incident_map_data(articles: list[dict[str, Any]], sector: str = 'general', status: str = 'all', selected_year: int | str | None = None) -> dict[str, Any]:
    sector_norm = (sector or 'general').strip().lower()
    filtered = filter_articles_for_sector_display(articles, sector_norm if sector_norm in {'general', 'marcas_retail'} else 'general', purpose='map')
    diagnostics = {
        'input_articles': len(articles),
        'sector_visible': len(filtered),
        'status_visible': 0,
        'year_eligible': 0,
        'mapped_candidates': 0,
        'unmapped_candidates': 0,
        'latest_raw_year': None,
        'latest_usable_year': None,
    }
    if status != 'all':
        filtered = [row for row in filtered if row.get('status') == status]
    diagnostics['status_visible'] = len(filtered)
    filtered = [row for row in filtered if year_for_article(row) >= MIN_BRANDS_MAP_YEAR]
    diagnostics['year_eligible'] = len(filtered)

    preprocessed: list[dict[str, Any]] = []
    for article in filtered:
        article_year = year_for_article(article)
        profile = article_relevance_profile(article)
        if sector_norm == 'marcas_retail':
            country, brand, source = infer_country_and_brand(article)
            label = brand or detect_known_brand(article) or infer_target_label(article, 'marcas_retail')
        else:
            country, source = infer_country_general(article)
            label = infer_target_label(article, 'general')
        country = normalize_country_name(country) if country else None
        attack = profile['dominant_label']
        px, py = project_country_to_map(country)
        mapped = bool(country and px is not None and py is not None)
        if mapped:
            diagnostics['mapped_candidates'] += 1
        else:
            diagnostics['unmapped_candidates'] += 1
        preprocessed.append({
            'article': article,
            'year': article_year,
            'country': country,
            'source': source,
            'label': label,
            'attack_type': attack,
            'mapped': mapped,
            'content_categories': profile['categories'],
        })

    active_rows, years_payload, year_counts, active_year, selected_mode, latest_usable_year, latest_raw_year = _year_selection(preprocessed, selected_year)
    diagnostics['latest_raw_year'] = latest_raw_year
    diagnostics['latest_usable_year'] = latest_usable_year

    incidents: list[dict[str, Any]] = []
    country_counts: dict[str, int] = defaultdict(int)
    grouped_by_country: dict[str, list[dict[str, Any]]] = defaultdict(list)
    attack_counts: dict[str, int] = defaultdict(int)
    unresolved = 0
    status_counts = {
        'included': sum(1 for row in active_rows if row['article'].get('status') == 'included'),
        'pending': sum(1 for row in active_rows if row['article'].get('status') == 'pending'),
        'excluded': sum(1 for row in active_rows if row['article'].get('status') == 'excluded'),
    }

    for row in active_rows:
        article = row['article']
        country = row['country']
        attack = row['attack_type']
        incident = {
            'id': article.get('id'),
            'title': article.get('title') or 'Sin título',
            'country': country or 'No inferido',
            'country_key': country_key(country or 'No inferido'),
            'label': row['label'],
            'attack_type': attack,
            'content_categories': row.get('content_categories') or [],
            'published_at': article.get('published_at') or article.get('created_at'),
            'article_url': article.get('article_url') or '',
            'feed_name': article.get('feed_name') or '',
            'source': row['source'],
            'score': round(float(article.get('relevance_score') or 0), 3),
            'status': article.get('status') or 'pending',
            'display_sector': article.get('display_sector') or preferred_display_sector(article),
        }
        incidents.append(incident)
        attack_counts[attack] += 1
        if row['mapped'] and country:
            country_counts[country] += 1
            grouped_by_country[country].append(incident)
        else:
            unresolved += 1

    incidents.sort(key=lambda item: item.get('published_at') or '', reverse=True)
    points = []
    for country, count in sorted(country_counts.items(), key=lambda kv: (-kv[1], kv[0])):
        grouped = sorted(grouped_by_country[country], key=lambda item: item.get('published_at') or '', reverse=True)
        points.append(_point_payload(country, grouped, count))

    top_countries = [
        {
            'country': point['country'],
            'count': point['count'],
            'labels': point['labels'][:4],
            'content_categories': point.get('content_categories', [])[:4],
        }
        for point in points[:10]
    ]
    top_attacks = [
        {'label': label, 'count': count}
        for label, count in sorted(attack_counts.items(), key=lambda kv: (-kv[1], kv[0]))[:8]
    ]

    totals = {
        'all_articles': len(active_rows),
        'visible_articles': len(incidents),
        'mapped_articles': len([item for item in incidents if item['country'] != 'No inferido']),
        'incidents': len(active_rows),
        'countries': len(country_counts),
        'targets': len({item['label'] for item in incidents if item['label']}),
        'unresolved': unresolved,
        'included': status_counts['included'],
        'pending': status_counts['pending'],
        'excluded': status_counts['excluded'],
    }

    if sector_norm == 'marcas_retail':
        title = 'Mapa anual · Marcas'
        description = 'Noticias de marcas / retail / moda / ecommerce con contexto ciber, digital, antifraude, infraestructura o resiliencia tecnológica.'
    else:
        title = 'Mapa anual · General'
        description = 'Noticias generales filtradas por relevancia real en ciberseguridad, seguridad digital, IA defensiva, fraude o infraestructura tecnológica.'

    return {
        'map_type': sector_norm,
        'title': title,
        'description': description,
        'year': str(active_year),
        'selected_mode': selected_mode,
        'available_years': years_payload,
        'latest_populated_year': str(latest_usable_year),
        'latest_raw_year': str(latest_raw_year),
        'year_counts': year_counts,
        'totals': totals,
        'points': points,
        'top_countries': top_countries,
        'top_attacks': top_attacks,
        'incidents': incidents,
        'incidents_preview': incidents[:40],
        'map_base_image': MAP_IMAGE_PATH,
        'methodology': 'Países proyectados con coordenadas geográficas reales sobre el SVG. Los contadores y el listado usan la misma fuente de datos. General exige relevancia ciber/digital real; Marcas exige además contexto retail / moda / ecommerce o marca afectada.',
        'diagnostics': diagnostics,
    }


# EXPORT MAP PDF - used by the map download button.
def _pdf_safe(value: Any) -> str:
    return str(value or '').encode('latin-1', 'replace').decode('latin-1')


def _pdf_lines(text: Any, font: str, size: float, width: float, max_lines: int | None = None) -> list[str]:
    lines = simpleSplit(_pdf_safe(text), font, size, width)
    return lines[:max_lines] if max_lines else lines


def _pdf_new_page(pdf: canvas.Canvas, page_w: float, page_h: float, title: str) -> float:
    pdf.showPage()
    pdf.setFillColor(colors.HexColor('#020617'))
    pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 16)
    pdf.drawString(36, page_h - 36, _pdf_safe(title))
    return page_h - 62


def _pdf_draw_map_background(pdf: canvas.Canvas, x: float, y: float, w: float, h: float) -> None:
    pdf.setFillColor(colors.HexColor('#06111b'))
    pdf.roundRect(x, y, w, h, 16, fill=1, stroke=0)
    pdf.setStrokeColor(colors.HexColor('#1f5d3a'))
    pdf.setLineWidth(0.8)
    for frac in (0.2, 0.4, 0.6, 0.8):
        pdf.line(x + 18, y + h * frac, x + w - 18, y + h * frac)
    for frac in (0.14, 0.28, 0.42, 0.56, 0.70, 0.84):
        pdf.line(x + w * frac, y + 18, x + w * frac, y + h - 18)
    image_file = Path(__file__).resolve().parent / 'static' / 'world-outline.png'
    if image_file.exists():
        pdf.drawImage(str(image_file), x + 10, y + 12, width=w - 20, height=h - 24, preserveAspectRatio=True, mask='auto')


def export_incident_map_pdf(path: str, map_data: dict[str, Any]) -> str:
    """Export the active CyberRad map to PDF, including grouped news links per country."""
    page_w, page_h = landscape(A4)
    pdf = canvas.Canvas(path, pagesize=(page_w, page_h))
    sector_key = str(map_data.get('map_type') or 'general')
    sector_label = 'Marcas' if sector_key == 'marcas_retail' else 'General'
    year_label = 'Todos los años' if str(map_data.get('year') or '') == 'all' else str(map_data.get('year') or '')
    pdf.setTitle(_pdf_safe(f'CyberRad {sector_label} Map {year_label}'))

    pdf.setFillColor(colors.HexColor('#020617'))
    pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 20)
    pdf.drawString(36, page_h - 34, _pdf_safe(f'CyberRad - Mapa anual - {sector_label} - {year_label}'))
    pdf.setFont('Helvetica', 10)
    pdf.setFillColor(colors.HexColor('#9ad9b0'))
    for idx, line in enumerate(_pdf_lines(map_data.get('description', ''), 'Helvetica', 10, page_w - 72, max_lines=2)):
        pdf.drawString(36, page_h - 52 - idx * 12, line)

    totals = map_data.get('totals') or {}
    stat_y = page_h - 92
    card_w = 112
    stats = [
        ('Noticias', str(totals.get('all_articles', 0))),
        ('Paises', str(totals.get('countries', 0))),
        ('En mapa', str(totals.get('mapped_articles', 0))),
        ('Sin pais', str(totals.get('unresolved', 0))),
    ]
    for index, (label, value) in enumerate(stats):
        x = 36 + index * (card_w + 12)
        pdf.setFillColor(colors.HexColor('#0b1622'))
        pdf.roundRect(x, stat_y - 42, card_w, 38, 10, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#8ab99c'))
        pdf.setFont('Helvetica', 8)
        pdf.drawString(x + 10, stat_y - 14, _pdf_safe(label))
        pdf.setFillColor(colors.HexColor('#d7ffe3'))
        pdf.setFont('Helvetica-Bold', 16)
        pdf.drawString(x + 10, stat_y - 32, _pdf_safe(value))

    map_x, map_y, map_w, map_h = 36, 126, 540, 330
    _pdf_draw_map_background(pdf, map_x, map_y, map_w, map_h)
    pdf.setFillColor(colors.HexColor('#4ade80'))
    pdf.setFont('Helvetica-Bold', 11)
    pdf.drawString(map_x + 16, map_y + map_h - 22, _pdf_safe(f'Mapa mundi cibernetico - {sector_label}'))

    points = list(map_data.get('points') or [])
    max_count = max((int(point.get('count') or 0) for point in points), default=1) or 1
    for point in points:
        count = int(point.get('count') or 0)
        try:
            px = map_x + (float(point.get('x') or 0) / MAP_IMAGE_WIDTH) * map_w
            py = map_y + map_h - ((float(point.get('y') or 0) / MAP_IMAGE_HEIGHT) * map_h)
        except Exception:
            continue
        radius = 5.0 + (10.0 * ((count / max_count) ** 0.5))
        pdf.setFillColor(colors.Color(0.13, 0.77, 0.37, alpha=0.28))
        pdf.circle(px, py, radius * 1.65, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#22c55e'))
        pdf.circle(px, py, radius, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#d9ffe8'))
        pdf.setFont('Helvetica-Bold', 8)
        pdf.drawString(px + radius + 2, py + radius + 1, _pdf_safe(f"{point.get('country', '')} ({count})"))

    panel_x = 596
    pdf.setFillColor(colors.HexColor('#0b1622'))
    pdf.roundRect(panel_x, 126, 228, 330, 16, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 12)
    pdf.drawString(panel_x + 16, 430, 'Top paises')
    pdf.setFont('Helvetica', 9)
    y = 412
    for idx, item in enumerate((map_data.get('top_countries') or [])[:7], start=1):
        pdf.setFillColor(colors.HexColor('#94d8ad'))
        pdf.drawString(panel_x + 16, y, _pdf_safe(f"{idx}. {item.get('country', '')} - {item.get('count', 0)} noticias"))
        y -= 11
        labels = ', '.join(item.get('content_categories') or item.get('labels') or []) or 'Sin categorias inferidas'
        pdf.setFillColor(colors.HexColor('#7fa790'))
        for line in _pdf_lines(labels[:100], 'Helvetica', 8, 190, max_lines=2):
            pdf.drawString(panel_x + 28, y, line)
            y -= 9
        y -= 7

    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 12)
    pdf.drawString(panel_x + 16, max(168, y), 'Tipos de incidente')
    y2 = max(150, y - 16)
    pdf.setFont('Helvetica', 9)
    for item in (map_data.get('top_attacks') or [])[:5]:
        pdf.setFillColor(colors.HexColor('#94d8ad'))
        pdf.drawString(panel_x + 16, y2, _pdf_safe(f"- {item.get('label', '')}: {item.get('count', 0)}"))
        y2 -= 14

    pdf.setFillColor(colors.HexColor('#94d8ad'))
    pdf.setFont('Helvetica', 8)
    for index, line in enumerate(_pdf_lines(map_data.get('methodology', ''), 'Helvetica', 8, page_w - 72, max_lines=4)):
        pdf.drawString(36, 96 - (index * 10), line)

    incidents = list(map_data.get('incidents') or [])
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in incidents:
        grouped[str(item.get('country') or 'No inferido')].append(item)
    country_order = sorted(grouped, key=lambda c: (-len(grouped[c]), c))

    y = _pdf_new_page(pdf, page_w, page_h, _pdf_safe(f'Noticias y links por pais - {sector_label} - {year_label}'))
    for country in country_order:
        rows = sorted(grouped[country], key=lambda item: str(item.get('published_at') or ''), reverse=True)
        if y < 95:
            y = _pdf_new_page(pdf, page_w, page_h, _pdf_safe(f'Noticias y links por pais - Continuacion - {year_label}'))
        pdf.setFillColor(colors.HexColor('#4ade80'))
        pdf.setFont('Helvetica-Bold', 13)
        pdf.drawString(36, y, _pdf_safe(f'{country} - {len(rows)} noticias'))
        y -= 18
        for item in rows:
            if y < 88:
                y = _pdf_new_page(pdf, page_w, page_h, _pdf_safe(f'{country} - Continuacion - {year_label}'))
            pdf.setFillColor(colors.HexColor('#d7ffe3'))
            pdf.setFont('Helvetica-Bold', 9.5)
            for line in _pdf_lines(item.get('title', 'Sin titulo'), 'Helvetica-Bold', 9.5, page_w - 72, max_lines=2):
                pdf.drawString(48, y, line)
                y -= 11
            meta_bits = [
                str(item.get('published_at') or ''),
                str(item.get('attack_type') or 'General ciber / digital'),
                str(item.get('label') or 'Sin objetivo'),
                str(item.get('feed_name') or item.get('source') or 'Fuente no inferida'),
                f"score {float(item.get('score') or 0):.2f}",
            ]
            meta = ' - '.join(bit for bit in meta_bits if bit)
            pdf.setFillColor(colors.HexColor('#94d8ad'))
            pdf.setFont('Helvetica', 8)
            for line in _pdf_lines(meta, 'Helvetica', 8, page_w - 72, max_lines=2):
                pdf.drawString(48, y, line)
                y -= 9
            article_url = str(item.get('article_url') or '').strip()
            if article_url:
                pdf.setFillColor(colors.HexColor('#7dd3fc'))
                pdf.setFont('Helvetica', 7.5)
                for line in _pdf_lines(f'Link: {article_url}', 'Helvetica', 7.5, page_w - 72, max_lines=3):
                    pdf.drawString(48, y, line)
                    line_w = min(page_w - 96, pdf.stringWidth(line, 'Helvetica', 7.5))
                    pdf.linkURL(article_url, (48, y - 1, 48 + line_w, y + 9), relative=0)
                    y -= 9
            y -= 8
        y -= 8

    pdf.save()
    return path

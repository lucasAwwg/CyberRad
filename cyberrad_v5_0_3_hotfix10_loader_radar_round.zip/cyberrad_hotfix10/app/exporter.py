from __future__ import annotations

from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any

import requests
from docx import Document
from docx.shared import Inches

OUTPUT_DIR = Path(__file__).resolve().parent.parent / 'data' / 'exports'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {
    'User-Agent': 'CyberRadV4.5/1.0 (+https://localhost:3000)'
}


def add_image(document: Document, image_url: str) -> None:
    if not image_url:
        return
    try:
        response = requests.get(image_url, timeout=10, headers=HEADERS)
        response.raise_for_status()
        stream = BytesIO(response.content)
        document.add_picture(stream, width=Inches(5.8))
    except Exception:
        document.add_paragraph(f'Imagen no disponible para incrustar: {image_url}')


def export_articles_to_docx(articles: list[dict[str, Any]]) -> Path:
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    path = OUTPUT_DIR / f'cyberrad_v4_export_{timestamp}.docx'

    document = Document()
    document.add_heading('CyberRad V4.5 - Exportación de noticias', level=0)
    document.add_paragraph(f'Fecha de generación: {datetime.now().isoformat(timespec="seconds")}')

    for article in articles:
        document.add_heading(article.get('title') or 'Noticia', level=1)
        document.add_paragraph(f"Fuente: {article.get('feed_name') or 'N/D'}")
        document.add_paragraph(f"Fecha: {article.get('published_at') or article.get('created_at') or 'N/D'}")
        document.add_paragraph(f"Estado: {article.get('status') or 'pending'} | Score híbrido: {article.get('relevance_score', 0)} | Semántico: {article.get('semantic_score', 0)} | Feedback: {article.get('feedback_score', 0)}")
        if article.get('campaign_cluster'):
            document.add_paragraph(f"Cluster temático: {article.get('campaign_cluster')}")
        if article.get('duplicate_group'):
            document.add_paragraph(f"Grupo duplicado: {article.get('duplicate_group')}")
        document.add_paragraph(f"Artículo: {article.get('article_url') or ''}")
        if article.get('summary'):
            document.add_paragraph(article['summary'])
        if article.get('content'):
            document.add_paragraph(article['content'][:3000])
        if article.get('image_url'):
            add_image(document, article['image_url'])
        if article.get('video_url'):
            document.add_paragraph(f"Vídeo relacionado: {article['video_url']}")
        document.add_paragraph('-' * 60)

    document.save(path)
    return path

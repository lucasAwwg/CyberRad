from __future__ import annotations

import asyncio
import contextlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, HttpUrl
from starlette.requests import Request

from .db import add_feed, delete_feed, feedback_summary, get_article, get_settings, init_db, is_brands_priority_feed, list_articles, list_articles_unbounded, list_feeds, list_sector_articles, rescore_articles, seed_default_feeds, stats, toggle_feed, update_article_status, update_settings, upsert_articles
from .exporter import export_articles_to_docx
from .rss import parse_feed
from .brands_map import build_brands_map_data, export_brands_map_pdf
from .incident_map import build_incident_map_data, filter_articles_for_sector_display

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = Jinja2Templates(directory=str(BASE_DIR / 'templates'))


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class FeedCreate(BaseModel):
    name: str | None = Field(default=None, min_length=0, max_length=120)
    url: HttpUrl


class FeedToggle(BaseModel):
    is_enabled: bool


class SettingsUpdate(BaseModel):
    prompt: str | None = None
    poll_interval_seconds: int | None = Field(default=None, ge=30, le=86400)
    max_articles_per_feed: int | None = Field(default=None, ge=0, le=1000)
    auto_refresh_enabled: bool | None = None
    date_window: Literal['all', 'today', 'yesterday', '3', '7', '15', '30', '90', '120'] | None = None
    relevance_mode: Literal['flexible', 'balanced', 'strict'] | None = None
    hide_duplicates: bool | None = None
    semantic_reranking: bool | None = None
    feedback_learning: bool | None = None


class ArticleStatusUpdate(BaseModel):
    status: Literal['included', 'pending', 'excluded']


async def _fetch_single_feed(feed: dict[str, object], settings: dict[str, object], *, max_articles: int, retries: int = 2) -> tuple[int, int, dict[str, object] | None]:
    last_error: Exception | None = None
    for attempt in range(retries + 1):
        try:
            articles = await asyncio.to_thread(
                parse_feed,
                feed,
                settings['prompt'],
                max_articles,
                settings['date_window'],
                settings['relevance_mode'],
            )
            inserted = await asyncio.to_thread(upsert_articles, articles)
            return len(articles), inserted, None
        except Exception as exc:
            last_error = exc
            await asyncio.sleep(min(1.2 * (attempt + 1), 3.0))
    return 0, 0, {'id': feed.get('id'), 'name': feed.get('name'), 'error': str(last_error) if last_error else 'unknown'}


async def _refresh_feed_group(feeds: list[dict[str, object]], settings: dict[str, object], *, max_articles: int, concurrency: int = 12) -> dict[str, object]:
    semaphore = asyncio.Semaphore(max(1, concurrency))

    async def _wrapped(feed: dict[str, object]):
        async with semaphore:
            return await _fetch_single_feed(feed, settings, max_articles=max_articles)

    scanned = 0
    inserted = 0
    failed_feeds: list[dict[str, object]] = []
    results = await asyncio.gather(*[_wrapped(feed) for feed in feeds]) if feeds else []
    for feed_scanned, feed_inserted, failure in results:
        scanned += feed_scanned
        inserted += feed_inserted
        if failure:
            failed_feeds.append(failure)
    return {'feeds': len(feeds), 'scanned': scanned, 'inserted': inserted, 'failed_feeds': failed_feeds}


async def refresh_all_feeds(*, brands_first: bool = True, bootstrap_only: bool = False) -> dict[str, object]:
    settings = get_settings()
    feeds = [feed for feed in list_feeds() if feed['is_enabled']]
    priority = [feed for feed in feeds if is_brands_priority_feed(feed)]
    secondary = [feed for feed in feeds if not is_brands_priority_feed(feed)]

    # 0 = sin límite artificial por feed: se consume todo lo que el feed exponga.
    max_default = 0
    max_priority = 0

    aggregate = {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []}

    async def _merge(payload: dict[str, object]):
        aggregate['feeds'] += int(payload.get('feeds', 0))
        aggregate['scanned'] += int(payload.get('scanned', 0))
        aggregate['inserted'] += int(payload.get('inserted', 0))
        aggregate['failed_feeds'].extend(payload.get('failed_feeds', []))

    if brands_first and priority:
        print(f"[CyberRad] bootstrap brands feeds={len(priority)} max_articles={max_priority}")
        await _merge(await _refresh_feed_group(priority, settings, max_articles=max_priority, concurrency=14))
        await asyncio.to_thread(rescore_articles, settings['prompt'], settings['date_window'], settings['relevance_mode'])
        if bootstrap_only:
            return aggregate

    if secondary:
        print(f"[CyberRad] refresh secondary feeds={len(secondary)} max_articles={max_default}")
        await _merge(await _refresh_feed_group(secondary, settings, max_articles=max_default, concurrency=12))

    await asyncio.to_thread(rescore_articles, settings['prompt'], settings['date_window'], settings['relevance_mode'])
    return aggregate


async def refresh_loop(stop_event: asyncio.Event) -> None:
    while not stop_event.is_set():
        settings = get_settings()
        wait_seconds = max(30, int(settings['poll_interval_seconds']))
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=wait_seconds)
            break
        except asyncio.TimeoutError:
            pass
        if stop_event.is_set():
            break
        try:
            settings = get_settings()
            if settings['auto_refresh_enabled']:
                await refresh_all_feeds()
        except Exception as exc:
            print(f'[CyberRad V4.5] refresh error: {exc}')


async def _startup_refresh_task(app: FastAPI) -> None:
    app.state.startup_refresh_started_at = utc_now_iso()
    app.state.startup_refresh_finished_at = None
    app.state.startup_refresh_error = None
    app.state.startup_refresh_in_progress = True
    app.state.startup_refresh_result = {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []}
    try:
        existing_total = stats().get('total_articles', 0)
        if existing_total:
            print(f'[CyberRad] startup warm cache detected: {existing_total} articles already in DB')
        result = await refresh_all_feeds(brands_first=True, bootstrap_only=False)
        app.state.startup_refresh_result = result
    except Exception as exc:
        app.state.startup_refresh_error = str(exc)
        print(f'[CyberRad] startup refresh error: {exc}')
    finally:
        app.state.startup_refresh_in_progress = False
        app.state.startup_refresh_finished_at = utc_now_iso()


def get_job_state(app: FastAPI) -> dict[str, object]:
    return {
        'rescore_in_progress': bool(getattr(app.state, 'rescore_in_progress', False)),
        'rescore_pending': bool(getattr(app.state, 'rescore_pending', False)),
        'rescore_last_started_at': getattr(app.state, 'rescore_last_started_at', None),
        'rescore_last_finished_at': getattr(app.state, 'rescore_last_finished_at', None),
        'rescore_last_error': getattr(app.state, 'rescore_last_error', None),
    }


async def _rescore_worker(app: FastAPI) -> None:
    while True:
        prompt, date_window, relevance_mode = getattr(app.state, 'rescore_params', ('', 'all', 'balanced'))
        app.state.rescore_in_progress = True
        app.state.rescore_last_started_at = utc_now_iso()
        app.state.rescore_last_error = None
        app.state.rescore_pending = False
        try:
            await asyncio.to_thread(rescore_articles, prompt, date_window, relevance_mode)
        except Exception as exc:
            app.state.rescore_last_error = str(exc)
            print(f'[CyberRad V4.5] rescore error: {exc}')
        finally:
            app.state.rescore_in_progress = False
            app.state.rescore_last_finished_at = utc_now_iso()
        if not getattr(app.state, 'rescore_pending', False):
            break
    app.state.rescore_task = None


def schedule_rescore(app: FastAPI, prompt: str, date_window: str = 'all', relevance_mode: str = 'balanced') -> dict[str, object]:
    app.state.rescore_params = (prompt, date_window, relevance_mode)
    running_task = getattr(app.state, 'rescore_task', None)
    if running_task and not running_task.done():
        app.state.rescore_pending = True
        return get_job_state(app)
    app.state.rescore_task = asyncio.create_task(_rescore_worker(app))
    return get_job_state(app)


@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    seed_default_feeds()
    stop_event = asyncio.Event()
    app.state.stop_event = stop_event
    app.state.rescore_task = None
    app.state.startup_refresh_started_at = None
    app.state.startup_refresh_finished_at = None
    app.state.startup_refresh_error = None
    app.state.startup_refresh_in_progress = False
    app.state.startup_refresh_result = {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []}
    app.state.startup_refresh_task = asyncio.create_task(_startup_refresh_task(app))
    app.state.refresh_task = asyncio.create_task(refresh_loop(stop_event))
    try:
        yield
    finally:
        stop_event.set()
        for task_name in ('startup_refresh_task', 'refresh_task', 'rescore_task'):
            task = getattr(app.state, task_name, None)
            if task:
                task.cancel()
                with contextlib.suppress(BaseException):
                    await task


app = FastAPI(title='CyberRad V4.5.8.1 Marcas Startup Fixed', lifespan=lifespan)
app.mount('/static', StaticFiles(directory=str(BASE_DIR / 'static')), name='static')


@app.get('/favicon.ico', include_in_schema=False)
async def favicon():
    return FileResponse(BASE_DIR / 'static' / 'cyberrad-logo.png')


@app.get('/', response_class=HTMLResponse)
async def index(request: Request):
    return TEMPLATES.TemplateResponse(request=request, name='index.html', context={'request': request, 'settings': get_settings(), 'stats': stats(), 'feedback': feedback_summary()})


@app.get('/api/state')
async def api_state(request: Request):
    return {'settings': get_settings(), 'stats': stats(), 'feedback': feedback_summary(), 'feeds': list_feeds(), 'jobs': get_job_state(request.app), 'startup': {'started_at': getattr(request.app.state, 'startup_refresh_started_at', None), 'finished_at': getattr(request.app.state, 'startup_refresh_finished_at', None), 'error': getattr(request.app.state, 'startup_refresh_error', None), 'in_progress': bool(getattr(request.app.state, 'startup_refresh_in_progress', False)), 'result': getattr(request.app.state, 'startup_refresh_result', {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []})}}


@app.get('/api/articles')
async def api_articles(limit: int = 50, status: str = 'all', sector: str = 'general'):
    raw_articles = await asyncio.to_thread(list_articles_unbounded, status, 'all')
    filtered = filter_articles_for_sector_display(raw_articles, sector) if sector in {'general', 'marcas_retail'} else [dict(item, display_sector='general') for item in raw_articles]
    return {'articles': filtered[:min(limit, 200)]}


@app.get('/api/articles/{article_id}')
async def api_article(article_id: int):
    article = get_article(article_id)
    if not article:
        raise HTTPException(status_code=404, detail='Noticia no encontrada')
    return article


@app.post('/api/feeds')
async def api_create_feed(payload: FeedCreate):
    feed = add_feed(payload.name, str(payload.url))
    await refresh_all_feeds()
    return feed


@app.patch('/api/feeds/{feed_id}')
async def api_toggle_feed(feed_id: int, payload: FeedToggle):
    feed = toggle_feed(feed_id, payload.is_enabled)
    if not feed:
        raise HTTPException(status_code=404, detail='Feed no encontrado')
    return feed


@app.delete('/api/feeds/{feed_id}')
async def api_delete_feed(feed_id: int):
    delete_feed(feed_id)
    return {'ok': True}


@app.patch('/api/settings')
async def api_update_settings(payload: SettingsUpdate, request: Request):
    changes = payload.model_dump(exclude_none=True)
    updated = update_settings(changes)
    jobs = get_job_state(request.app)
    heavy_keys = {'prompt', 'date_window', 'relevance_mode', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'}
    if heavy_keys & changes.keys():
        jobs = schedule_rescore(request.app, updated['prompt'], updated['date_window'], updated['relevance_mode'])
    return {'settings': updated, 'jobs': jobs}


@app.post('/api/refresh')
async def api_refresh():
    return await refresh_all_feeds()


@app.patch('/api/articles/{article_id}/status')
async def api_article_status(article_id: int, payload: ArticleStatusUpdate, request: Request):
    article = update_article_status(article_id, payload.status)
    if not article:
        raise HTTPException(status_code=404, detail='Noticia no encontrada')
    settings = get_settings()
    jobs = schedule_rescore(request.app, settings['prompt'], settings['date_window'], settings['relevance_mode'])
    return {'article': get_article(article_id), 'jobs': jobs}


@app.get('/export/docx')
async def export_docx(status: str = 'included'):
    articles = list_articles(limit=500, status=status)
    if not articles:
        raise HTTPException(status_code=400, detail='No hay noticias para exportar con ese estado.')
    path = await asyncio.to_thread(export_articles_to_docx, articles)
    return FileResponse(path, filename=path.name, media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')




@app.get('/api/incidents-map')
async def api_incidents_map(sector: str = 'general', status: str = 'all', year: str | None = None):
    articles = await asyncio.to_thread(list_articles_unbounded, 'all', 'all')
    return build_incident_map_data(articles, sector=sector, status=status, selected_year=year)
@app.get('/api/marcas-map')
async def api_marcas_map(year: str | None = None):
    articles = await asyncio.to_thread(list_sector_articles, 'marcas_retail', True)
    return build_brands_map_data(articles, selected_year=year)


@app.get('/export/marcas-map.pdf')
async def export_marcas_map_pdf(year: str | None = None):
    articles = await asyncio.to_thread(list_sector_articles, 'marcas_retail', True)
    map_data = build_brands_map_data(articles, selected_year=year)
    if not map_data['totals']['incidents']:
        raise HTTPException(status_code=400, detail='No hay noticias de Marcas para generar el mapa PDF en ese año.')
    output = BASE_DIR.parent / 'data' / f"cyberrad_marcas_map_{map_data['year']}.pdf"
    path = await asyncio.to_thread(export_brands_map_pdf, str(output), map_data)
    return FileResponse(path, filename=Path(path).name, media_type='application/pdf')

from __future__ import annotations

import re
from typing import Any

CVE_RE = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)

VENDOR_PATTERNS = {
    'Microsoft': ['microsoft', 'windows', 'entra', 'active directory', 'azure ad'],
    'Google': ['google', 'chrome', 'android', 'gcp', 'google cloud'],
    'Cisco': ['cisco', 'asa', 'firepower', 'secure firewall'],
    'Fortinet': ['fortinet', 'fortios', 'fortimanager', 'fortiguard'],
    'Ivanti': ['ivanti', 'pulse secure'],
    'VMware': ['vmware', 'esxi', 'vcenter'],
    'Palo Alto': ['palo alto', 'pan-os', 'cortex'],
    'Synology': ['synology'],
    'Grafana': ['grafana'],
    'Ubuntu': ['ubuntu'],
    'Linux': ['linux', 'kernel', 'rhel', 'debian'],
}

PRODUCT_PATTERNS = {
    'Active Directory': ['active directory', 'domain controller', 'ldap', 'kerberos', 'ntlm', 'group policy', 'gpo'],
    'Entra ID': ['entra id', 'azure ad', 'aad'],
    'Windows': ['windows server', 'microsoft windows', 'powershell'],
    'Chrome': ['chrome'],
    'FortiOS': ['fortios'],
    'FortiManager': ['fortimanager'],
    'ESXi': ['esxi'],
    'vCenter': ['vcenter'],
    'Grafana': ['grafana'],
    'Ubuntu': ['ubuntu'],
    'Kubernetes': ['kubernetes', 'k8s'],
    'Docker': ['docker'],
}

MALWARE_PATTERNS = {
    'Ransomware': ['ransomware', 'double extortion'],
    'Infostealer': ['infostealer', 'stealer'],
    'Trojan': ['trojan'],
    'Botnet': ['botnet'],
    'Backdoor': ['backdoor'],
    'Wiper': ['wiper'],
    'Loader': ['loader'],
    'RAT': ['remote access trojan', 'rat'],
}

ACTOR_PATTERNS = {
    'APT': ['apt', 'advanced persistent threat'],
    'Lazarus': ['lazarus'],
    'Volt Typhoon': ['volt typhoon'],
    'LockBit': ['lockbit'],
    'Black Basta': ['black basta'],
    'Akira': ['akira'],
}

TACTIC_PATTERNS = {
    'RCE': ['remote code execution', 'rce'],
    'Privilege Escalation': ['privilege escalation'],
    'Auth Bypass': ['auth bypass', 'authentication bypass'],
    'Credential Theft': ['credential theft'],
    'Phishing': ['phishing', 'smishing', 'vishing'],
    'Exploit': ['exploit', 'actively exploited'],
}

TAG_PATTERNS = {
    'Identity': ['active directory', 'entra id', 'azure ad', 'iam', 'identity', 'sso', 'mfa', 'kerberos', 'ldap'],
    'Vulnerability': ['cve', 'vulnerability', 'advisory', 'patch', 'flaw', 'zero-day', '0day'],
    'Malware': ['malware', 'ransomware', 'trojan', 'stealer', 'backdoor', 'botnet', 'wiper'],
    'Incident': ['incident', 'breach', 'outage', 'compromise', 'intrusion'],
    'ThreatIntel': ['threat intelligence', 'ioc', 'ttps', 'campaign', 'actor'],
    'Cloud': ['cloud', 'aws', 'azure', 'gcp', 'kubernetes', 'container'],
    'Endpoint': ['edr', 'xdr', 'endpoint detection and response'],
    'Linux': ['linux', 'ubuntu', 'kernel'],
    'Windows': ['windows', 'powershell'],
}


def normalize_spaces(text: str | None) -> str:
    return re.sub(r'\s+', ' ', (text or '').strip().lower())


def phrase_in_text(text: str, phrase: str) -> bool:
    blob = normalize_spaces(text)
    pattern = r'(?<!\w)' + r'\s+'.join(re.escape(p) for p in normalize_spaces(phrase).split() if p) + r'(?!\w)'
    if not pattern:
        return False
    return re.search(pattern, blob, flags=re.IGNORECASE) is not None


def _extract_named_entities(text: str, mapping: dict[str, list[str]]) -> list[str]:
    out: list[str] = []
    for label, variants in mapping.items():
        if any(phrase_in_text(text, variant) for variant in variants):
            out.append(label)
    return out


def unique(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        key = normalize_spaces(item)
        if key and key not in seen:
            seen.add(key)
            out.append(item)
    return out


def build_entity_text(entities: dict[str, Any]) -> str:
    parts: list[str] = []
    for key in ('cves', 'vendors', 'products', 'malware_families', 'actors', 'tactics', 'tags'):
        parts.extend(entities.get(key, []))
    return ' '.join(parts)


def extract_entities(title: str = '', summary: str = '', content: str = '') -> dict[str, Any]:
    blob = ' '.join([title or '', summary or '', content or ''])
    entities = {
        'cves': unique([c.upper() for c in CVE_RE.findall(blob)]),
        'vendors': unique(_extract_named_entities(blob, VENDOR_PATTERNS)),
        'products': unique(_extract_named_entities(blob, PRODUCT_PATTERNS)),
        'malware_families': unique(_extract_named_entities(blob, MALWARE_PATTERNS)),
        'actors': unique(_extract_named_entities(blob, ACTOR_PATTERNS)),
        'tactics': unique(_extract_named_entities(blob, TACTIC_PATTERNS)),
        'tags': unique(_extract_named_entities(blob, TAG_PATTERNS)),
    }
    return entities

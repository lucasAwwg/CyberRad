from __future__ import annotations

import math
import re
from collections import Counter
from typing import Any
from urllib.parse import urlparse

from .entities import normalize_spaces

STOPWORDS = {
    'the', 'and', 'for', 'that', 'this', 'with', 'from', 'your', 'into', 'have', 'http', 'https',
    'news', 'security', 'cyber', 'report', 'analysis', 'update', 'latest', 'sobre', 'para', 'como',
    'desde', 'hasta', 'entre', 'pero', 'porque', 'una', 'unos', 'unas', 'los', 'las', 'del', 'con',
    'sin', 'que', 'or', 'o', 'de', 'el', 'la', 'un'
}


def tokenize(text: str) -> list[str]:
    return [token for token in re.findall(r"[a-zA-Z0-9\-]{3,}", normalize_spaces(text)) if token not in STOPWORDS]


def _domain(url: str | None) -> str:
    return (urlparse(url or '').netloc or '').replace('www.', '').lower()


def build_feedback_profile(rows: list[dict[str, Any]]) -> dict[str, Any]:
    positive_rows = [row for row in rows if row.get('status') == 'included']
    negative_rows = [row for row in rows if row.get('status') == 'excluded']
    token_pos, token_neg = Counter(), Counter()
    tag_pos, tag_neg = Counter(), Counter()
    domain_pos, domain_neg = Counter(), Counter()
    for row in positive_rows:
        token_pos.update(tokenize(' '.join([row.get('title') or '', row.get('summary') or '', row.get('content') or ''])))
        tag_pos.update(row.get('match_tags') or [])
        domain_pos.update([_domain(row.get('feed_url'))])
    for row in negative_rows:
        token_neg.update(tokenize(' '.join([row.get('title') or '', row.get('summary') or '', row.get('content') or ''])))
        tag_neg.update(row.get('match_tags') or [])
        domain_neg.update([_domain(row.get('feed_url'))])
    return {
        'token_pos': token_pos,
        'token_neg': token_neg,
        'tag_pos': tag_pos,
        'tag_neg': tag_neg,
        'domain_pos': domain_pos,
        'domain_neg': domain_neg,
        'samples': len(rows),
        'positive_samples': len(positive_rows),
        'negative_samples': len(negative_rows),
    }


def _log_odds(pos: int, neg: int) -> float:
    return math.log((pos + 1) / (neg + 1))


def score_feedback(profile: dict[str, Any], article: dict[str, Any]) -> tuple[float, list[str]]:
    if profile.get('samples', 0) < 4 or profile.get('positive_samples', 0) == 0:
        return 0.0, []
    score = 0.0
    reasons: list[str] = []
    tokens = set(tokenize(' '.join([article.get('title') or '', article.get('summary') or '', article.get('content') or ''])))
    tags = set(article.get('match_tags') or [])
    domain = _domain(article.get('feed_url'))
    token_contribs = sorted(((_log_odds(profile['token_pos'][token], profile['token_neg'][token]), token) for token in tokens if profile['token_pos'][token] or profile['token_neg'][token]), reverse=True)
    if token_contribs:
        top = token_contribs[:5]
        score += sum(max(-0.25, min(0.25, contrib * 0.08)) for contrib, _ in top)
        positives = [token for contrib, token in top if contrib > 0][:3]
        negatives = [token for contrib, token in top if contrib < 0][:2]
        if positives:
            reasons.append('Feedback positivo en términos: ' + ', '.join(positives))
        if negatives:
            reasons.append('Feedback negativo en términos: ' + ', '.join(negatives))
    for tag in tags:
        score += max(-0.08, min(0.08, _log_odds(profile['tag_pos'][tag], profile['tag_neg'][tag]) * 0.04))
    if domain:
        domain_bias = max(-0.12, min(0.12, _log_odds(profile['domain_pos'][domain], profile['domain_neg'][domain]) * 0.07))
        score += domain_bias
        if domain_bias > 0.03:
            reasons.append(f'Fuente aprendida como útil: {domain}')
        elif domain_bias < -0.03:
            reasons.append(f'Fuente penalizada por feedback: {domain}')
    score = max(-0.35, min(0.35, score))
    return round(score, 4), reasons[:3]

from __future__ import annotations

from typing import Any

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .entities import build_entity_text
from .rss import CONCEPT_LEXICON, parse_prompt


def _safe_similarity(a: str, b: str, analyzer: str, ngram_range: tuple[int, int]) -> float:
    a = (a or '').strip()
    b = (b or '').strip()
    if not a or not b:
        return 0.0
    try:
        vec = TfidfVectorizer(analyzer=analyzer, ngram_range=ngram_range, sublinear_tf=True, min_df=1)
        matrix = vec.fit_transform([a, b])
        return float(cosine_similarity(matrix[0:1], matrix[1:2])[0][0])
    except Exception:
        return 0.0


def expand_prompt(prompt: str) -> str:
    parsed = parse_prompt(prompt)
    pieces: list[str] = [parsed['raw']]
    for concept in parsed['concepts']:
        pieces.append(concept['label'])
        pieces.extend(concept['variants'][:8])
        canonical = concept.get('canonical')
        if canonical and canonical in CONCEPT_LEXICON:
            pieces.extend(CONCEPT_LEXICON[canonical].get('tags', []))
    pieces.extend(parsed.get('severity_filters', []))
    return ' '.join(str(piece) for piece in pieces if piece)


def build_document_text(article: dict[str, Any]) -> str:
    entities = article.get('entities') or {}
    tags = article.get('match_tags') or []
    return ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
        article.get('content') or '',
        article.get('feed_name') or '',
        ' '.join(tags),
        build_entity_text(entities),
    ])


def semantic_score(prompt: str, article: dict[str, Any]) -> tuple[float, list[str]]:
    expanded_prompt = expand_prompt(prompt)
    if not expanded_prompt.strip():
        return 0.0, []
    doc_text = build_document_text(article)
    word_sim = _safe_similarity(expanded_prompt, doc_text, analyzer='word', ngram_range=(1, 2))
    char_sim = _safe_similarity(expanded_prompt, doc_text, analyzer='char_wb', ngram_range=(3, 5))
    score = round(max(0.0, min((word_sim * 0.65) + (char_sim * 0.35), 1.0)), 4)
    details: list[str] = []
    if score >= 0.55:
        details.append('Alta similitud semántica')
    elif score >= 0.35:
        details.append('Similitud semántica media')
    elif score > 0:
        details.append('Similitud semántica débil')
    entities = article.get('entities') or {}
    shared = []
    for bucket in ('cves', 'vendors', 'products', 'malware_families', 'actors', 'tags'):
        for value in entities.get(bucket, []):
            if value.lower() in expanded_prompt.lower():
                shared.append(value)
    if shared:
        details.append('Entidades alineadas: ' + ', '.join(shared[:3]))
    return score, details

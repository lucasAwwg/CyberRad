#!/usr/bin/env bash
set -euo pipefail

# Uso:
# ./install_runner_mint.sh <RUNNER_URL> <REGISTRATION_TOKEN> <RUNNER_NAME>
# Ejemplo:
# ./install_runner_mint.sh https://github.com/tu-org/tu-repo ABCDEF123456 mint-runner-01

RUNNER_URL=${1:-}
REGISTRATION_TOKEN=${2:-}
RUNNER_NAME=${3:-mint-runner-01}
RUNNER_VERSION=2.328.0

if [[ -z "$RUNNER_URL" || -z "$REGISTRATION_TOKEN" ]]; then
  echo "Faltan parámetros: RUNNER_URL y REGISTRATION_TOKEN"
  exit 1
fi

mkdir -p "$HOME/actions-runner"
cd "$HOME/actions-runner"

curl -L -o actions-runner-linux-x64-${RUNNER_VERSION}.tar.gz \
  https://github.com/actions/runner/releases/download/v${RUNNER_VERSION}/actions-runner-linux-x64-${RUNNER_VERSION}.tar.gz

tar xzf ./actions-runner-linux-x64-${RUNNER_VERSION}.tar.gz
./config.sh --url "$RUNNER_URL" --token "$REGISTRATION_TOKEN" --labels "cyberrad-prod" --unattended --name "$RUNNER_NAME"
sudo ./svc.sh install
sudo ./svc.sh start

# Despliegue con Docker + GitHub Runner

## Arquitectura recomendada
- Repositorio GitHub con el código de CyberRad.
- Host Linux con Docker y Docker Compose.
- GitHub Actions con *self-hosted runner* en ese host.
- Despliegue automático al hacer `push` a `main`.

## Recomendación de sistema
Para Docker, usa Ubuntu Server o Ubuntu Desktop. Linux Mint puede servir para el runner, pero Docker no lo soporta oficialmente como distribución derivada de Ubuntu.

## 1) Preparar el host
En Ubuntu:
```bash
chmod +x deploy/install_docker_ubuntu.sh
./deploy/install_docker_ubuntu.sh
```

## 2) Preparar el repositorio
- Sube este proyecto a GitHub.
- En GitHub: `Settings > Actions > Runners > New self-hosted runner`.
- Copia la URL del repo y el token temporal.

## 3) Instalar el runner en Linux Mint
```bash
chmod +x deploy/install_runner_mint.sh
./deploy/install_runner_mint.sh https://github.com/TU-ORG/TU-REPO TOKEN_TEMPORAL mint-runner-01
```

## 4) Etiqueta del runner
El workflow usa:
- `self-hosted`
- `linux`
- `x64`
- `cyberrad-prod`

## 5) Despliegue
Cada `push` a `main` lanzará:
```bash
docker compose up -d --build
```

## 6) URL
Cuando el contenedor arranque:
- Aplicación: `http://IP_DEL_HOST:3000`


## Adaptación Icarus

- Usa `.gitlab-ci.yml` en la raíz para GitLab CI/CD.
- El compose principal publica `127.0.0.1:3001:3000` por defecto.
- Para pruebas locales en Kali usa `docker-compose.kali.yml`.

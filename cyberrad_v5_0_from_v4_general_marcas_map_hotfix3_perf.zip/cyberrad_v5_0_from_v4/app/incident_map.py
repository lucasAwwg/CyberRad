from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Any
import re

from .brands_map import (
    ATTACK_KEYWORDS,
    GLOBAL_COUNTRY_TERMS,
    COUNTRY_ALIASES,
    MAP_IMAGE_HEIGHT,
    MAP_IMAGE_PATH,
    MAP_IMAGE_WIDTH,
    MIN_BRANDS_MAP_YEAR,
    country_key,
    has_marcas_sector,
    infer_attack_label,
    infer_country_and_brand,
    normalize_country_name,
    project_country_to_map,
    world_xy,
    year_for_article,
)
from .rss import normalize_spaces

DIRECT_INCIDENT_TERMS = {
    'ransomware', 'breach', 'data breach', 'hack', 'hacked', 'cyberattack', 'cyber attack',
    'ciberataque', 'security incident', 'compromise', 'compromised', 'leak', 'leaked',
    'phishing', 'malware', 'intrusion', 'extortion', 'stolen data', 'customer data',
    'credential theft', 'account takeover', 'magecart', 'payment breach', 'skimmer'
}
ADVISORY_NOISE_TERMS = {
    'practical advice', 'advice', 'guide', 'guidance', 'analysis', 'research', 'report',
    'fundamentals', 'define goals', 'read actionable advice', 'best practices', 'podcast',
    'webinar', 'survey', 'newsletter'
}


def _norm(text: str | None) -> str:
    return normalize_spaces(text or '')


def article_blob(article: dict[str, Any]) -> str:
    return ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
        article.get('content') or '',
        article.get('feed_name') or '',
        article.get('feed_url') or '',
        article.get('article_url') or '',
        article.get('rationale') or '',
    ])


def has_direct_cyber_signal(article: dict[str, Any]) -> bool:
    text = _norm(article_blob(article))
    for term in DIRECT_INCIDENT_TERMS:
        if re.search(rf'(?<!\w){re.escape(term)}(?!\w)', text):
            return True
    return False


def detect_known_brand(article: dict[str, Any]) -> str | None:
    _country, brand, source = infer_country_and_brand(article)
    if brand and source in {'brand', 'entity'}:
        return brand
    return None


def validated_marcas_article(article: dict[str, Any]) -> bool:
    brand = detect_known_brand(article)
    if not brand:
        return False
    text = _norm(article_blob(article))
    if not has_direct_cyber_signal(article):
        return False
    if any(term in text for term in ADVISORY_NOISE_TERMS):
        if not any(term in text for term in ('breach', 'ransomware', 'hacked', 'hack', 'leak', 'cyberattack', 'compromise', 'magecart', 'skimmer', 'credential theft')):
            return False
    return True


def display_sector(article: dict[str, Any]) -> str:
    return 'marcas_retail' if validated_marcas_article(article) else 'general'


def filter_articles_for_sector_display(articles: list[dict[str, Any]], sector: str = 'general') -> list[dict[str, Any]]:
    sector_norm = (sector or 'general').strip().lower()
    output: list[dict[str, Any]] = []
    for article in articles:
        visible_sector = display_sector(article)
        if sector_norm == 'marcas_retail' and visible_sector != 'marcas_retail':
            continue
        if sector_norm == 'general' and visible_sector != 'general':
            continue
        item = dict(article)
        item['display_sector'] = visible_sector
        output.append(item)
    return output


def infer_country_general(article: dict[str, Any]) -> tuple[str | None, str]:
    entities = article.get('entities') or {}
    for field in ('locations', 'countries'):
        for value in entities.get(field, []) or []:
            canonical = normalize_country_name(value)
            if canonical:
                return canonical, 'entity-country'

    text = _norm(article_blob(article))
    for country, aliases in COUNTRY_ALIASES.items():
        for alias in aliases:
            if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', text):
                return normalize_country_name(country), 'country'

    for alias, canonical in GLOBAL_COUNTRY_TERMS:
        if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', text):
            return normalize_country_name(canonical), 'country-global'

    return None, 'unknown'


def infer_target_label(article: dict[str, Any], sector: str) -> str:
    brand = detect_known_brand(article)
    if sector == 'marcas_retail':
        return brand or 'Marca validada'
    entities = article.get('entities') or {}
    vendors = entities.get('vendors') or []
    if vendors:
        return str(vendors[0])
    return article.get('feed_name') or 'Incidente general'



def _year_selection(rows: list[dict[str, Any]], selected_year: int | str | None):
    current_year = datetime.now().year
    years = sorted({year_for_article(row) for row in rows if year_for_article(row) >= MIN_BRANDS_MAP_YEAR})
    latest_populated_year = max(years, default=current_year)
    available_years = list(range(MIN_BRANDS_MAP_YEAR, max(current_year, latest_populated_year) + 1))
    selected_norm = str(selected_year).strip().lower() if selected_year is not None else ''
    selected_mode = 'latest'
    if selected_norm in {'all', '2024+'}:
        selected_mode = 'all'
        active_year = 'all'
        active_rows = list(rows)
    elif selected_norm and selected_norm not in {'latest', 'none'}:
        try:
            requested_year = max(MIN_BRANDS_MAP_YEAR, int(selected_norm))
        except Exception:
            requested_year = latest_populated_year
            selected_mode = 'latest'
        else:
            selected_mode = 'specific'
        active_year = requested_year
        active_rows = [row for row in rows if year_for_article(row) == int(active_year)]
    else:
        active_year = latest_populated_year
        active_rows = [row for row in rows if year_for_article(row) == int(active_year)]
    year_counts = {'latest': sum(1 for row in rows if year_for_article(row) == latest_populated_year), 'all': len(rows)}
    year_counts.update({str(year): sum(1 for row in rows if year_for_article(row) == year) for year in available_years})
    years_payload = ['latest', 'all'] + [str(year) for year in available_years]
    return active_rows, years_payload, year_counts, str(active_year), selected_mode, str(latest_populated_year)


def _point_payload(country: str, grouped_items: list[dict[str, Any]], count: int) -> dict[str, Any]:
    x, y = world_xy(country)
    latest = grouped_items[0] if grouped_items else {}
    x_pct = round((x / MAP_IMAGE_WIDTH) * 100.0, 3)
    y_pct = round((y / MAP_IMAGE_HEIGHT) * 100.0, 3)
    labels = []
    for item in grouped_items:
        label = item.get('label')
        if label and label not in labels:
            labels.append(label)
    attack_types = []
    for item in grouped_items:
        attack = item.get('attack_type')
        if attack and attack not in attack_types:
            attack_types.append(attack)
    return {
        'country': country,
        'country_key': country_key(country),
        'count': count,
        'x': round(x, 2),
        'y': round(y, 2),
        'x_pct': x_pct,
        'y_pct': y_pct,
        'labels': labels[:6],
        'attack_types': attack_types[:6],
        'article_ids': [item['id'] for item in grouped_items if item.get('id')],
        'latest_date': latest.get('published_at'),
        'latest_label': latest.get('label') or '',
        'latest_attack_type': latest.get('attack_type') or 'Incidente ciber',
        'latest_source': latest.get('feed_name') or latest.get('source') or 'Fuente no inferida',
    }


def build_incident_map_data(articles: list[dict[str, Any]], sector: str = 'general', status: str = 'all', selected_year: int | str | None = None) -> dict[str, Any]:
    sector_norm = (sector or 'general').strip().lower()
    filtered = filter_articles_for_sector_display(articles, sector_norm if sector_norm in {'general', 'marcas_retail'} else 'general')
    if status != 'all':
        filtered = [row for row in filtered if row.get('status') == status]
    filtered = [row for row in filtered if year_for_article(row) >= MIN_BRANDS_MAP_YEAR]

    active_rows, years_payload, year_counts, active_year, selected_mode, latest_populated_year = _year_selection(filtered, selected_year)
    incidents: list[dict[str, Any]] = []
    country_counts: dict[str, int] = defaultdict(int)
    grouped_by_country: dict[str, list[dict[str, Any]]] = defaultdict(list)
    attack_counts: dict[str, int] = defaultdict(int)
    unresolved = 0
    status_counts = {
        'included': sum(1 for row in active_rows if row.get('status') == 'included'),
        'pending': sum(1 for row in active_rows if row.get('status') == 'pending'),
        'excluded': sum(1 for row in active_rows if row.get('status') == 'excluded'),
    }

    for article in active_rows:
        if sector_norm == 'marcas_retail':
            country, brand, source = infer_country_and_brand(article)
            label = brand or detect_known_brand(article) or 'Marca validada'
        else:
            country, source = infer_country_general(article)
            label = infer_target_label(article, 'general')
        country = normalize_country_name(country) if country else None
        attack = infer_attack_label(article)
        incident = {
            'id': article.get('id'),
            'title': article.get('title') or 'Sin título',
            'country': country or 'No inferido',
            'country_key': country_key(country or 'No inferido'),
            'label': label,
            'attack_type': attack,
            'published_at': article.get('published_at') or article.get('created_at'),
            'article_url': article.get('article_url') or '',
            'feed_name': article.get('feed_name') or '',
            'source': source,
            'score': round(float(article.get('relevance_score') or 0), 3),
            'status': article.get('status') or 'pending',
        }
        incidents.append(incident)
        attack_counts[attack] += 1
        px, py = project_country_to_map(country)
        if country and px is not None and py is not None:
            country_counts[country] += 1
            grouped_by_country[country].append(incident)
        else:
            unresolved += 1

    incidents.sort(key=lambda item: item.get('published_at') or '', reverse=True)
    points = []
    for country, count in sorted(country_counts.items(), key=lambda kv: (-kv[1], kv[0])):
        grouped = sorted(grouped_by_country[country], key=lambda item: item.get('published_at') or '', reverse=True)
        points.append(_point_payload(country, grouped, count))

    top_countries = [
        {
            'country': point['country'],
            'count': point['count'],
            'labels': point['labels'][:4],
        }
        for point in points[:10]
    ]
    top_attacks = [
        {'label': label, 'count': count}
        for label, count in sorted(attack_counts.items(), key=lambda kv: (-kv[1], kv[0]))[:8]
    ]

    totals = {
        'all_articles': len(active_rows),
        'visible_articles': len(incidents),
        'mapped_articles': len([item for item in incidents if item['country'] != 'No inferido']),
        'incidents': len(active_rows),
        'countries': len(country_counts),
        'targets': len({item['label'] for item in incidents if item['label']}),
        'unresolved': unresolved,
        'included': status_counts['included'],
        'pending': status_counts['pending'],
        'excluded': status_counts['excluded'],
    }

    if sector_norm == 'marcas_retail':
        title = 'Mapa anual · Marcas'
        description = 'Solo víctimas válidas del sector textil / retail / moda / ecommerce detectadas por el filtro de Marcas.'
    else:
        title = 'Mapa anual · General'
        description = 'Noticias generales de ciberseguridad con país detectado por contexto o localización explícita.'

    return {
        'map_type': sector_norm,
        'title': title,
        'description': description,
        'year': str(active_year),
        'selected_mode': selected_mode,
        'available_years': years_payload,
        'latest_populated_year': str(latest_populated_year),
        'year_counts': year_counts,
        'totals': totals,
        'points': points,
        'top_countries': top_countries,
        'top_attacks': top_attacks,
        'incidents': incidents[:24],
        'map_base_image': MAP_IMAGE_PATH,
        'methodology': 'El mapa usa anclas visuales por país. En Marcas se prioriza la marca víctima validada; en General se intenta inferir el país por contexto explícito en el texto.',
    }

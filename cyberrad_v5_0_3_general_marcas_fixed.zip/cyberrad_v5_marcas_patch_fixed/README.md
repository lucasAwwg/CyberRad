# CyberRad 5.0.3

Esta revisión corrige dos problemas de la versión anterior:

- vuelve a mostrar **noticias generales de ciberseguridad**
- endurece el filtro **Marcas** para evitar falsos positivos como noticias de negocio sin incidente ciber real

## Mejoras
- sección **General** + sección **Marcas** + **Mapa**
- loader animado en pantalla
- caché en memoria
- descarga concurrente de feeds
- mapa oscuro con anclas por país
- puerto 3001
- `docker-compose.kali.yml`

## Endpoints
- `/`
- `/health`
- `/api/dashboard?limit=40`
- `/scan/general?limit=40`
- `/scan/marcas?limit=40`
- `/scan/map?limit=40`

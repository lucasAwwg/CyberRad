
from __future__ import annotations

import html
import json
import re
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import feedparser
import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response

from app.feed_builder import build_google_news_brand_queries
from app.filters import MarcasFilter
from app.map_builder import build_map_payload
from app.trusted_sources import DIRECT_SOURCE_FEEDS

USER_AGENT = "CyberRad/5.0.3 General+Marcas (+https://localhost)"
REQUEST_TIMEOUT = 10
CACHE_TTL_SECONDS = 900
MAX_SCAN_ITEMS = 500
APP_PORT = 3001

api = FastAPI(title="CyberRad 5.0.3", version="5.0.3")
filter_engine = MarcasFilter()

_cache_lock = threading.Lock()
_cache_payload: dict[str, Any] | None = None
_cache_generated_at = 0.0

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"


@api.get("/", response_class=HTMLResponse)
def home() -> str:
    return build_home_html()


@api.get("/static/map.png")
def static_map() -> FileResponse:
    return FileResponse(STATIC_DIR / "map.png", media_type="image/png")


@api.get("/favicon.ico")
def favicon() -> Response:
    return Response(status_code=204)


@api.get("/health")
def health() -> dict[str, Any]:
    payload = get_dashboard_bundle(limit=40, force=False)
    return {
        "status": "ok",
        "service": "cyberrad",
        "version": "5.0.3",
        "port": APP_PORT,
        "cache_generated_at": payload["meta"]["generated_at"],
        "cache_age_seconds": payload["meta"]["cache_age_seconds"],
        "general": payload["summary"]["general_included"],
        "marcas": payload["summary"]["marcas_included"],
    }


@api.get("/api/dashboard")
def api_dashboard(limit: int = Query(default=40, ge=1, le=150), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    return JSONResponse(get_dashboard_bundle(limit=limit, force=bool(refresh)))


@api.get("/scan/general")
def scan_general(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["general_items"])


@api.get("/scan/marcas")
def scan_marcas(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["marcas_items"])


@api.get("/scan/map")
def scan_map(limit: int = Query(default=200, ge=1, le=500), refresh: int = Query(default=0, ge=0, le=1)) -> JSONResponse:
    bundle = get_dashboard_bundle(limit=limit, force=bool(refresh))
    return JSONResponse(bundle["map_markers"])


def get_dashboard_bundle(limit: int, force: bool = False) -> dict[str, Any]:
    payload = get_or_refresh_cache(force=force)
    generated_at = payload["generated_at"]
    general_items = payload["general_items"][:limit]
    marcas_items = payload["marcas_items"][:limit]
    map_markers = payload["map_markers"][:limit]
    cache_age = max(0, int(time.time() - generated_at))

    summary = dict(payload["summary"])
    summary["showing_general"] = len(general_items)
    summary["showing_marcas"] = len(marcas_items)
    summary["showing_markers"] = len(map_markers)

    return {
        "meta": {
            "generated_at": isoformat_from_ts(generated_at),
            "cache_age_seconds": cache_age,
            "cache_ttl_seconds": CACHE_TTL_SECONDS,
            "cache_hit": not force,
            "feed_count": payload["feed_count"],
        },
        "summary": summary,
        "general_items": general_items,
        "marcas_items": marcas_items,
        "map_markers": map_markers,
    }


def get_or_refresh_cache(force: bool = False) -> dict[str, Any]:
    global _cache_payload, _cache_generated_at
    now = time.time()
    with _cache_lock:
        if not force and _cache_payload and (now - _cache_generated_at) < CACHE_TTL_SECONDS:
            return _cache_payload

    payload = build_fresh_payload()

    with _cache_lock:
        _cache_payload = payload
        _cache_generated_at = payload["generated_at"]
        return _cache_payload


def build_fresh_payload() -> dict[str, Any]:
    feeds = DIRECT_SOURCE_FEEDS + build_google_news_brand_queries()
    raw_items = fetch_all_feeds(feeds)
    deduped = dedupe_items(raw_items)

    general_items: list[dict[str, Any]] = []
    marcas_decisions: list[dict[str, Any]] = []

    for item in deduped:
        general = filter_engine.classify_general(item)
        if general:
            general_items.append(general)

        decision = filter_engine.classify(item).to_dict()
        decision["published"] = item.get("published")
        marcas_decisions.append(decision)

    general_items.sort(key=lambda item: (item["score"], item.get("published") or ""), reverse=True)
    marcas_decisions.sort(key=lambda item: (item["include"], item["score"], item.get("published") or ""), reverse=True)
    marcas_included = [item for item in marcas_decisions if item.get("include")]

    payload = {
        "generated_at": time.time(),
        "feed_count": len(feeds),
        "general_items": general_items[:MAX_SCAN_ITEMS],
        "marcas_items": marcas_included[:MAX_SCAN_ITEMS],
        "map_markers": build_map_payload(marcas_included[:MAX_SCAN_ITEMS]),
        "summary": build_summary(deduped, general_items, marcas_decisions, marcas_included),
    }
    return payload


def fetch_all_feeds(feeds: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not feeds:
        return []
    max_workers = min(14, max(4, len(feeds)))
    items: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(fetch_feed, feed) for feed in feeds]
        for future in as_completed(futures):
            try:
                items.extend(future.result())
            except Exception:
                continue
    return items


def fetch_feed(feed: dict[str, Any]) -> list[dict[str, Any]]:
    headers = {"User-Agent": USER_AGENT}
    try:
        response = requests.get(feed["url"], headers=headers, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        parsed = feedparser.parse(response.content)
    except Exception:
        return []

    items: list[dict[str, Any]] = []
    for entry in parsed.entries:
        article_url = extract_article_url(entry.get("link", ""))
        title = clean_html(entry.get("title", ""))
        summary = clean_html(entry.get("summary", ""))
        content = ""
        if entry.get("content"):
            first = entry["content"][0]
            content = clean_html(first.get("value", ""))
        source = feed.get("name")
        if entry.get("source") and isinstance(entry["source"], dict):
            source = entry["source"].get("title") or source
        published = normalize_published(entry)
        items.append(
            {
                "title": title,
                "summary": summary,
                "content": content,
                "url": entry.get("link", ""),
                "article_url": article_url,
                "source": source,
                "publisher_domain": urlparse(article_url if article_url else feed["url"]).netloc,
                "published": published,
                "discovery_only_source": bool(feed.get("discovery_only")),
            }
        )
    return items


def build_summary(raw_items: list[dict[str, Any]], general_items: list[dict[str, Any]], all_marcas: list[dict[str, Any]], included_marcas: list[dict[str, Any]]) -> dict[str, Any]:
    unique_brands = sorted({item.get("brand") for item in included_marcas if item.get("brand")})
    unique_countries = sorted({item.get("map_country_label") for item in included_marcas if item.get("map_country_label")})
    return {
        "total_scanned": len(raw_items),
        "general_included": len(general_items),
        "marcas_included": len(included_marcas),
        "marcas_rejected_or_pending": max(0, len(all_marcas) - len(included_marcas)),
        "unique_brands": len(unique_brands),
        "unique_countries": len(unique_countries),
        "top_brands": top_counts(included_marcas, "brand"),
        "top_countries": top_counts(included_marcas, "map_country_label"),
        "top_general_sources": top_counts(general_items, "source"),
        "top_marcas_sources": top_counts(included_marcas, "source"),
    }


def top_counts(items: list[dict[str, Any]], key: str, limit: int = 8) -> list[dict[str, Any]]:
    counts: dict[str, int] = {}
    for item in items:
        value = str(item.get(key) or "").strip()
        if not value:
            continue
        counts[value] = counts.get(value, 0) + 1
    ordered = sorted(counts.items(), key=lambda x: (-x[1], x[0]))
    return [{"name": name, "count": count} for name, count in ordered[:limit]]


def dedupe_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: OrderedDict[str, dict[str, Any]] = OrderedDict()
    for item in items:
        key = make_key(item)
        if key not in seen:
            seen[key] = item
    return list(seen.values())


def make_key(item: dict[str, Any]) -> str:
    title = re.sub(r"\s+", " ", (item.get("title") or "").lower()).strip()
    article_url = (item.get("article_url") or "").strip().lower()
    return article_url or title


def extract_article_url(value: str) -> str:
    if not value:
        return ""
    if "news.google.com" not in value:
        return value
    parsed = urlparse(value)
    q = parse_qs(parsed.query)
    if q.get("url"):
        return q["url"][0]
    return value


def clean_html(value: str) -> str:
    if not value:
        return ""
    soup = BeautifulSoup(value, "html.parser")
    text = soup.get_text(" ", strip=True)
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def normalize_published(entry: dict[str, Any]) -> str | None:
    for key in ("published_parsed", "updated_parsed"):
        struct_time = entry.get(key)
        if struct_time:
            try:
                dt = datetime(*struct_time[:6], tzinfo=timezone.utc)
                return dt.isoformat()
            except Exception:
                pass
    for key in ("published", "updated"):
        value = entry.get(key)
        if value:
            return str(value)
    return None


def isoformat_from_ts(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


def short_date(value: str | None) -> str:
    if not value:
        return "sin fecha"
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.strftime("%d/%m/%Y %H:%M")
    except Exception:
        return value[:16]


def build_home_html() -> str:
    return """
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>CyberRad 5.0.3</title>
<style>
:root{
  --bg:#020b12; --panel:#071522; --panel2:#0a1b2c; --line:#0d7a64;
  --text:#edfdf5; --muted:#98b3bd; --green:#20e37a; --green2:#0bb36d; --chip:#0e2231;
}
*{box-sizing:border-box}
body{margin:0;font-family:Inter,Arial,sans-serif;background:radial-gradient(circle at top,#07213a 0,#03111d 20%,#020b12 55%,#02080d 100%);color:var(--text)}
.wrap{max-width:1500px;margin:0 auto;padding:22px}
.hero,.section{background:linear-gradient(180deg,rgba(6,19,31,.95),rgba(3,12,21,.95));border:1px solid rgba(32,227,122,.28);border-radius:24px;box-shadow:0 10px 40px rgba(0,0,0,.35);padding:20px;margin-bottom:18px}
.hero h1{margin:0 0 6px;font-size:50px;color:#87ffb8}
.hero p{margin:0;color:#bdd3de;font-size:18px}
.stats{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
.stat{background:#08131f;border:1px solid rgba(255,255,255,.08);padding:10px 14px;border-radius:999px;color:#bfe9cf}
.controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:18px}
input,button{border:none;border-radius:14px}
input{padding:12px 14px;background:#091626;color:white;width:100px;border:1px solid rgba(255,255,255,.08)}
button{padding:12px 16px;font-weight:800;cursor:pointer}
.btn-green{background:linear-gradient(180deg,var(--green),var(--green2));color:#02150b}
.btn-dark{background:#14253c;color:#dce9ef;border:1px solid rgba(255,255,255,.08)}
.grid{display:grid;grid-template-columns:1.05fr 1fr;gap:18px}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px}
.card{background:linear-gradient(180deg,#0a1730,#081323 70%,#07111e);border:1px solid rgba(74,110,170,.35);border-radius:26px;overflow:hidden;min-height:280px;display:flex;flex-direction:column;position:relative}
.thumb{height:98px;background:radial-gradient(circle at 20% 20%,rgba(178,58,255,.28),transparent 28%),radial-gradient(circle at 70% 25%,rgba(41,127,255,.28),transparent 30%),linear-gradient(180deg,#12213e,#0a1730)}
.body{padding:18px;display:flex;flex-direction:column;gap:12px;height:100%}
.meta{display:flex;gap:10px;align-items:center;flex-wrap:wrap;color:#b7c8d1}
.pill{padding:8px 12px;border-radius:999px;background:#482f88;color:#f4e8ff;font-weight:700}
.country{color:#dfe6ea}
.title{font-size:20px;font-weight:900;line-height:1.2}
.summary{color:#d8e8ef;line-height:1.45;min-height:66px}
.tags{display:flex;gap:8px;flex-wrap:wrap}
.tag{background:#07292a;color:#9af4bc;border:1px solid rgba(32,227,122,.28);padding:6px 10px;border-radius:999px;font-weight:700;font-size:14px}
.score{background:#3b2d08;color:#ffd85d;border:1px solid rgba(255,216,93,.35)}
.bottom{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:auto}
.date{color:#d3e7f1}
.link{background:linear-gradient(180deg,var(--green),var(--green2));padding:12px 18px;border-radius:16px;color:#02150b;text-decoration:none;font-weight:900}
.map-panel{position:relative;min-height:640px;background:#020508;border-radius:22px;overflow:hidden;border:1px solid rgba(255,255,255,.08)}
.map-panel img{display:block;width:100%;height:100%;object-fit:cover;opacity:.98}
.marker{position:absolute;transform:translate(-50%,-50%);width:60px;height:60px;border-radius:50%;background:radial-gradient(circle,rgba(56,241,120,.95) 0,rgba(18,176,83,.92) 45%,rgba(18,176,83,.2) 100%);box-shadow:0 0 0 10px rgba(43,255,133,.08),0 0 24px rgba(43,255,133,.55);display:flex;align-items:center;justify-content:center;font-weight:900;color:#02150b}
.marker.small{width:34px;height:34px;font-size:12px}
.label{position:absolute;transform:translate(-50%,12px);color:white;font-size:13px;font-weight:800;text-shadow:0 1px 3px black;white-space:nowrap}
.list-head{display:flex;justify-content:space-between;align-items:end;gap:10px;margin-bottom:14px}
.list-head h2{margin:0;font-size:28px}
.list-head p{margin:4px 0 0;color:var(--muted)}
.muted{color:var(--muted)}
.loader{position:fixed;inset:0;background:rgba(2,9,16,.82);backdrop-filter:blur(5px);display:flex;align-items:center;justify-content:center;z-index:9999}
.loader.hidden{display:none}
.loader-box{background:#081522;border:1px solid rgba(32,227,122,.28);padding:26px 30px;border-radius:24px;display:flex;flex-direction:column;align-items:center;gap:16px;min-width:280px}
.spinner{width:74px;height:74px;border-radius:50%;border:5px solid rgba(255,255,255,.10);border-top-color:#28ec81;border-right-color:#28ec81;animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.empty{padding:18px;border:1px dashed rgba(255,255,255,.12);border-radius:18px;color:#c4d7df;background:#091320}
@media (max-width:1200px){.grid{grid-template-columns:1fr}.hero h1{font-size:38px}}
</style>
</head>
<body>
<div class="loader" id="loader"><div class="loader-box"><div class="spinner"></div><div><div style="font-size:22px;font-weight:900;text-align:center">Cargando CyberRad</div><div class="muted" style="margin-top:6px;text-align:center">Consultando feeds y preparando mapa…</div></div></div></div>

<div class="wrap">
  <section class="hero">
    <h1>CyberRad 5.0.3</h1>
    <p>General + Marcas. Mantiene noticias ciber generales y separa Marcas solo cuando la víctima es una marca textil / retail / moda / ecommerce con incidente real.</p>
    <div class="stats" id="stats"></div>
    <div class="controls">
      <input id="limit" type="number" value="40" min="1" max="150" />
      <button class="btn-green" onclick="loadDashboard(false)">Cargar</button>
      <button class="btn-dark" onclick="loadDashboard(true)">Refresh feeds</button>
      <a class="link" href="/docs" style="padding:12px 16px">Docs</a>
    </div>
  </section>

  <section class="section">
    <div class="list-head">
      <div><h2>Noticias generales de ciberseguridad</h2><p>Todo lo ciber relevante que no depende del filtro de Marcas.</p></div>
      <div class="muted" id="generalCount"></div>
    </div>
    <div class="cards" id="generalCards"></div>
  </section>

  <div class="grid">
    <section class="section">
      <div class="list-head">
        <div><h2>Noticias incluidas en Marcas</h2><p>Solo víctimas válidas del sector textil / retail / moda / ecommerce.</p></div>
        <div class="muted" id="marcasCount"></div>
      </div>
      <div class="cards" id="marcasCards"></div>
    </section>

    <section class="section">
      <div class="list-head">
        <div><h2>Mapa de incidentes de Marcas</h2><p>Marcadores centrados por país con agrupación de noticias válidas.</p></div>
        <div class="muted" id="mapCount"></div>
      </div>
      <div class="map-panel" id="mapPanel">
        <img src="/static/map.png" alt="Mapa mundial oscuro" />
      </div>
    </section>
  </div>
</div>

<script>
const $ = (id) => document.getElementById(id);

function esc(v){
  return String(v ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
}

function trimText(v, max=180){
  const t = String(v ?? "");
  return t.length > max ? t.slice(0, max-1) + "…" : t;
}

function tagsFromItem(item){
  const tags = [];
  (item.incident_terms || []).slice(0,4).forEach(t => tags.push(`<span class="tag">${esc(t)}</span>`));
  if(item.brand){ tags.push(`<span class="tag">${esc(item.brand)}</span>`); }
  if(item.score != null){ tags.push(`<span class="tag score">Score ${esc(item.score)}</span>`); }
  return tags.join("");
}

function renderCard(item, mode){
  const source = esc(item.source || "Fuente");
  const country = esc(item.map_country_label || item.country_label || "");
  const title = esc(item.title || "Sin título");
  const summary = esc(trimText(item.summary || "", 190));
  const date = esc(formatDate(item.published));
  const link = esc(item.article_url || "#");
  const badge = mode === "marcas" ? `<span class="pill">Marcas</span>` : `<span class="pill" style="background:#183e62;color:#d7f1ff">General</span>`;
  return `<article class="card">
    <div class="thumb"></div>
    <div class="body">
      <div class="meta"><span>${source}</span>${badge}${country ? `<span class="country">${country}</span>` : ""}</div>
      <div class="title">${title}</div>
      <div class="summary">${summary || "Sin resumen."}</div>
      <div class="tags">${tagsFromItem(item)}</div>
      <div class="bottom"><div class="date">${date}</div><a class="link" href="${link}" target="_blank" rel="noreferrer">Abrir noticia</a></div>
    </div>
  </article>`;
}

function formatDate(v){
  if(!v) return "sin fecha";
  try{
    const d = new Date(v);
    if(isNaN(d)) return String(v).slice(0,16);
    return d.toLocaleString("es-ES");
  }catch{
    return String(v).slice(0,16);
  }
}

function renderMarkers(markers){
  const panel = $("mapPanel");
  panel.querySelectorAll(".marker,.label").forEach(n => n.remove());
  if(!markers.length){
    panel.insertAdjacentHTML("beforeend", `<div class="empty" style="position:absolute;left:18px;right:18px;bottom:18px">No hay marcadores válidos todavía.</div>`);
    return;
  }
  markers.forEach(m => {
    const count = Number(m.count || 0);
    const cls = count >= 10 ? "marker" : "marker small";
    const x = ((m.x_pct ?? 0.5) * 100).toFixed(2) + "%";
    const y = ((m.y_pct ?? 0.5) * 100).toFixed(2) + "%";
    panel.insertAdjacentHTML("beforeend",
      `<div class="${cls}" style="left:${x};top:${y}" title="${esc(m.country_label)} · ${esc(count)}">${esc(count)}</div>`+
      `<div class="label" style="left:${x};top:${y}">${esc(m.country_label || m.country_iso2 || "")}</div>`
    );
  });
}

function renderStats(summary, meta){
  const stats = [
    ["Escaneadas", summary.total_scanned],
    ["General", summary.general_included],
    ["Marcas", summary.marcas_included],
    ["Países", summary.unique_countries],
    ["Marcas únicas", summary.unique_brands],
    ["Feeds", meta.feed_count],
    ["Caché", meta.cache_age_seconds + "s"],
  ];
  $("stats").innerHTML = stats.map(([k,v]) => `<div class="stat"><strong>${esc(k)}:</strong> ${esc(v)}</div>`).join("");
  $("generalCount").textContent = `${summary.showing_general} visibles`;
  $("marcasCount").textContent = `${summary.showing_marcas} visibles`;
  $("mapCount").textContent = `${summary.showing_markers} países`;
}

async function loadDashboard(force){
  $("loader").classList.remove("hidden");
  try{
    const limit = Number($("limit").value || 40);
    const res = await fetch(`/api/dashboard?limit=${limit}&refresh=${force ? 1 : 0}`);
    const data = await res.json();
    renderStats(data.summary, data.meta);
    $("generalCards").innerHTML = (data.general_items || []).length
      ? data.general_items.map(item => renderCard(item, "general")).join("")
      : `<div class="empty">No se encontraron noticias generales válidas.</div>`;
    $("marcasCards").innerHTML = (data.marcas_items || []).length
      ? data.marcas_items.map(item => renderCard(item, "marcas")).join("")
      : `<div class="empty">No se encontraron noticias válidas para Marcas. Esto suele pasar cuando no hay víctima real + incidente claro.</div>`;
    renderMarkers(data.map_markers || []);
  } catch (e){
    $("generalCards").innerHTML = `<div class="empty">Error cargando noticias.</div>`;
    $("marcasCards").innerHTML = `<div class="empty">Error cargando Marcas.</div>`;
  } finally {
    $("loader").classList.add("hidden");
  }
}

loadDashboard(false);
</script>
</body>
</html>
""".strip()

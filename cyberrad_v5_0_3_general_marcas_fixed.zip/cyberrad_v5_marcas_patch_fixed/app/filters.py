
from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Any
from urllib.parse import urlparse

import tldextract

from app.brand_catalog import COUNTRY_TO_LABEL, TEXTILE_BRANDS
from app.trusted_sources import TRUSTED_PUBLISHER_DOMAINS, VENDOR_BLOG_DOMAINS

STRONG_INCIDENT_TERMS = {
    "data breach": r"\bdata breach(?:es)?\b",
    "breach": r"\bbreach(?:es|ed)?\b",
    "hacked": r"\bhacked\b",
    "hack": r"\bhack(?:ing|ers?)?\b",
    "cyberattack": r"\bcyber\s*attack(?:s)?\b",
    "ransomware": r"\bransomware\b",
    "leak": r"\bleak(?:ed|s)?\b",
    "compromise": r"\bcompromis(?:e|ed|es)\b",
    "exfiltration": r"\bexfiltrat(?:ion|ed|es?)\b",
    "stolen customer data": r"\bstolen customer data\b",
    "customer data exposed": r"\bcustomer data exposed\b",
    "intrusion": r"\bintrusion(?:s)?\b",
    "skimming": r"\bskimm(?:ing|er|ers)\b",
    "magecart": r"\bmagecart\b",
}

MEDIUM_INCIDENT_TERMS = {
    "phishing": r"\bphishing\b",
    "credential theft": r"\bcredential theft\b",
    "account takeover": r"\baccount takeover\b",
    "malware": r"\bmalware\b",
    "security incident": r"\bsecurity incident\b",
    "security breach": r"\bsecurity breach\b",
    "ddos": r"\bddos\b",
}

GENERAL_CYBER_TERMS = {
    "cyber": r"\bcyber\b",
    "security": r"\bsecurity\b",
    "infosec": r"\binfosec\b",
    "threat": r"\bthreat\b",
    "vulnerability": r"\bvulnerabilit(?:y|ies)\b",
    "malware": r"\bmalware\b",
    "ransomware": r"\bransomware\b",
    "data breach": r"\bdata breach(?:es)?\b",
    "hacked": r"\bhacked\b",
}

TEXTILE_CONTEXT_TERMS = {
    "fashion",
    "apparel",
    "textile",
    "clothing",
    "garment",
    "footwear",
    "sportswear",
    "luxury",
    "retail",
    "ecommerce",
    "online store",
    "department store",
    "beauty retailer",
}

NEGATIVE_ADVISORY_TERMS = {
    "practical advice",
    "guide",
    "fundamentals",
    "analysis",
    "research",
    "read actionable advice",
    "how to",
    "inside an ai-enabled",
    "why your automated pentesting tool",
    "threat to critical infrastructure",
    "leaders need to act",
    "predictions",
    "best practices",
}

BUSINESS_ONLY_TERMS = {
    "paid",
    "profit",
    "profits",
    "revenue",
    "sales",
    "earnings",
    "quarter",
    "difficult year",
    "leaving",
    "chief executive",
    "ceo",
    "board",
}

VICTIM_HINTS = {
    "customer",
    "customers",
    "shopper",
    "shoppers",
    "store",
    "stores",
    "retailer",
    "retailer's",
    "ecommerce",
    "online shop",
}

COMPILED_STRONG = {label: re.compile(pattern, re.I) for label, pattern in STRONG_INCIDENT_TERMS.items()}
COMPILED_MEDIUM = {label: re.compile(pattern, re.I) for label, pattern in MEDIUM_INCIDENT_TERMS.items()}
COMPILED_GENERAL = {label: re.compile(pattern, re.I) for label, pattern in GENERAL_CYBER_TERMS.items()}


@dataclass
class BrandHit:
    canonical: str
    alias: str
    country_iso2: str
    country_label: str
    sector: str


@dataclass
class MarcasDecision:
    include: bool
    score: float
    title: str
    source: str
    publisher_domain: str
    article_url: str
    brand: str | None
    brand_country_iso2: str | None
    brand_country_label: str | None
    sector: str | None
    incident_terms: list[str]
    rationale: list[str]
    discovery_only_source: bool
    map_country_iso2: str | None
    map_country_label: str | None
    status: str
    summary: str | None = None
    published: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class MarcasFilter:
    def __init__(self) -> None:
        self.brand_patterns: list[tuple[re.Pattern[str], BrandHit]] = []
        for brand in TEXTILE_BRANDS:
            for alias in brand["aliases"]:
                pattern = re.compile(rf"(?<!\w){re.escape(alias)}(?!\w)", re.I)
                hit = BrandHit(
                    canonical=brand["name"],
                    alias=alias,
                    country_iso2=brand["country"],
                    country_label=COUNTRY_TO_LABEL.get(brand["country"], brand["country"]),
                    sector=brand["sector"],
                )
                self.brand_patterns.append((pattern, hit))

    def classify(self, item: dict[str, Any]) -> MarcasDecision:
        title = (item.get("title") or "").strip()
        summary = (item.get("summary") or "").strip()
        content = (item.get("content") or "").strip()
        title_l = title.lower()
        summary_l = summary.lower()
        content_l = content.lower()
        combined = f"{title}\n{summary}\n{content}"
        combined_l = combined.lower()

        publisher_domain = _normalize_domain(item.get("publisher_domain") or item.get("source") or item.get("article_url") or "")
        article_url = item.get("article_url") or item.get("url") or ""
        article_domain = _normalize_domain(article_url)
        effective_domain = article_domain or publisher_domain
        discovery_only_source = bool(item.get("discovery_only_source"))

        score = 0.0
        rationale: list[str] = []

        https_ok = article_url.startswith("https://")
        if https_ok:
            score += 1
            rationale.append("URL HTTPS válida")
        else:
            rationale.append("URL no HTTPS o ausente")

        trusted_domain = self._is_trusted_domain(effective_domain)
        if trusted_domain:
            score += 2
            rationale.append("Dominio de noticia en allowlist de confianza")
        else:
            rationale.append("Dominio fuera de allowlist")

        if self._is_vendor_domain(effective_domain) or self._is_vendor_domain(publisher_domain):
            score -= 12
            rationale.append("Dominio vendor/blog de ciberseguridad")

        negative_hits = sorted(term for term in NEGATIVE_ADVISORY_TERMS if term in combined_l)
        if negative_hits:
            score -= 10
            rationale.append(f"Pinta a post educativo/advisory: {', '.join(negative_hits[:3])}")

        brand_hit, brand_weight = self._best_brand_hit(title, summary, content)
        if brand_hit:
            score += 8 + min(brand_weight, 4)
            rationale.append(f"Marca detectada: {brand_hit.canonical}")
        else:
            score -= 8
            rationale.append("No hay marca textil/retail víctima clara")

        strong_hits, medium_hits = self._incident_hits(title, summary, content)
        incident_hits = strong_hits + [h for h in medium_hits if h not in strong_hits]

        if strong_hits:
            score += 8
            rationale.append(f"Incidente fuerte detectado: {', '.join(strong_hits[:3])}")
        elif medium_hits:
            score += 2
            rationale.append(f"Solo señales medias de incidente: {', '.join(medium_hits[:3])}")
        else:
            score -= 8
            rationale.append("No hay incidente ciber claro")

        textile_hits = sorted(term for term in TEXTILE_CONTEXT_TERMS if term in combined_l)
        if textile_hits:
            score += 2
            rationale.append(f"Contexto retail/moda: {', '.join(textile_hits[:3])}")

        victim_hits = sorted(term for term in VICTIM_HINTS if term in combined_l)
        if victim_hits:
            score += 1
            rationale.append("Hay señales de víctima/cliente/tienda")

        if any(term in title_l for term in BUSINESS_ONLY_TERMS) and not (strong_hits or medium_hits):
            score -= 10
            rationale.append("Parece noticia de negocio no ciber")

        title_or_summary_cyber = bool(self._general_hits(title) or self._general_hits(summary))
        brand_in_title_or_summary = brand_weight >= 3
        mandatory_ok = all(
            [
                bool(brand_hit),
                brand_in_title_or_summary,
                bool(strong_hits or (medium_hits and title_or_summary_cyber)),
                https_ok,
                trusted_domain,
            ]
        )
        include = mandatory_ok and score >= 12
        status = "incluida" if include else ("pendiente" if score >= 8 else "excluida")

        return MarcasDecision(
            include=include,
            score=round(score, 2),
            title=title,
            source=item.get("source") or "",
            publisher_domain=effective_domain,
            article_url=article_url,
            brand=brand_hit.canonical if brand_hit else None,
            brand_country_iso2=brand_hit.country_iso2 if brand_hit else None,
            brand_country_label=brand_hit.country_label if brand_hit else None,
            sector=brand_hit.sector if brand_hit else None,
            incident_terms=incident_hits,
            rationale=rationale,
            discovery_only_source=discovery_only_source,
            map_country_iso2=brand_hit.country_iso2 if brand_hit else None,
            map_country_label=brand_hit.country_label if brand_hit else None,
            status=status,
            summary=summary,
            published=item.get("published"),
        )

    def classify_general(self, item: dict[str, Any]) -> dict[str, Any] | None:
        title = (item.get("title") or "").strip()
        summary = (item.get("summary") or "").strip()
        content = (item.get("content") or "").strip()
        article_url = item.get("article_url") or item.get("url") or ""
        publisher_domain = _normalize_domain(item.get("publisher_domain") or item.get("source") or article_url or "")
        article_domain = _normalize_domain(article_url)
        effective_domain = article_domain or publisher_domain
        combined = f"{title}\n{summary}\n{content}"
        combined_l = combined.lower()

        if not article_url.startswith("https://"):
            return None
        if not self._is_trusted_domain(effective_domain):
            return None
        if self._is_vendor_domain(effective_domain):
            return None
        if any(term in combined_l for term in NEGATIVE_ADVISORY_TERMS):
            return None

        strong_hits, medium_hits = self._incident_hits(title, summary, content)
        general_hits = self._general_hits(combined)
        if not (strong_hits or medium_hits or general_hits):
            return None

        score = 3 + len(strong_hits) * 4 + len(medium_hits) * 2 + min(len(general_hits), 3)
        return {
            "title": title,
            "summary": summary,
            "source": item.get("source") or "",
            "article_url": article_url,
            "publisher_domain": effective_domain,
            "incident_terms": strong_hits + [h for h in medium_hits if h not in strong_hits],
            "general_terms": general_hits,
            "score": round(score, 2),
            "published": item.get("published"),
        }

    def _best_brand_hit(self, title: str, summary: str, content: str) -> tuple[BrandHit | None, int]:
        candidates: list[tuple[int, BrandHit]] = []
        for pattern, hit in self.brand_patterns:
            weight = 0
            if pattern.search(title):
                weight += 8
            if pattern.search(summary):
                weight += 4
            if pattern.search(content):
                weight += 1
            if weight:
                candidates.append((weight, hit))
        if not candidates:
            return None, 0
        candidates.sort(key=lambda pair: pair[0], reverse=True)
        return candidates[0][1], candidates[0][0]

    def _incident_hits(self, title: str, summary: str, content: str) -> tuple[list[str], list[str]]:
        focus = f"{title}\n{summary}"
        full = f"{focus}\n{content}"
        strong = [label for label, pattern in COMPILED_STRONG.items() if pattern.search(focus) or pattern.search(full)]
        medium = [label for label, pattern in COMPILED_MEDIUM.items() if pattern.search(focus) or pattern.search(full)]
        return strong, medium

    def _general_hits(self, text: str) -> list[str]:
        return [label for label, pattern in COMPILED_GENERAL.items() if pattern.search(text)]

    @staticmethod
    def _is_trusted_domain(domain: str) -> bool:
        return _domain_in_set(domain, TRUSTED_PUBLISHER_DOMAINS)

    @staticmethod
    def _is_vendor_domain(domain: str) -> bool:
        return _domain_in_set(domain, VENDOR_BLOG_DOMAINS)


def _normalize_domain(value: str) -> str:
    if not value:
        return ""
    parsed = urlparse(value if "://" in value else f"https://{value}")
    host = parsed.netloc or parsed.path
    ext = tldextract.extract(host)
    if not ext.domain:
        return host.lower().strip()
    return f"{ext.domain}.{ext.suffix}".lower().strip(".")


def _domain_in_set(domain: str, allowed: set[str]) -> bool:
    if not domain:
        return False
    for entry in allowed:
        if domain == entry or domain.endswith(f".{entry}"):
            return True
    return False

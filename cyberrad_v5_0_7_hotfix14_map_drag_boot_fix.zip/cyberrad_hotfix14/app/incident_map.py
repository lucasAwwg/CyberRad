from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Any
import re

from .brands_map import (
    ATTACK_KEYWORDS,
    GLOBAL_COUNTRY_TERMS,
    COUNTRY_ALIASES,
    MAP_IMAGE_HEIGHT,
    MAP_IMAGE_PATH,
    MAP_IMAGE_WIDTH,
    MIN_BRANDS_MAP_YEAR,
    country_key,
    has_marcas_sector,
    infer_attack_label,
    BRAND_TO_COUNTRY,
    infer_country_and_brand,
    normalize_country_name,
    project_country_to_map,
    world_xy,
    year_for_article,
)
from .rss import normalize_spaces

DIRECT_INCIDENT_TERMS = {
    'ransomware', 'breach', 'breached', 'data breach', 'data leak', 'hack', 'hacked',
    'cyberattack', 'cyber attack', 'ciberataque', 'cybersecurity incident', 'security incident',
    'compromise', 'compromised', 'leak', 'leaked', 'ddos', 'distributed denial of service',
    'service disruption', 'outage', 'unauthorized access', 'phishing', 'malware', 'intrusion',
    'extortion', 'stolen data', 'customer data', 'credential theft', 'credential stuffing',
    'account takeover', 'magecart', 'payment breach', 'skimmer', 'web skimmer',
    'checkout compromise', 'exfiltration', 'data exposure', 'website defacement',
    'supply chain attack', 'infostealer'
}
ADVISORY_NOISE_TERMS = {
    'practical advice', 'advice', 'guide', 'guidance', 'analysis', 'research', 'report',
    'fundamentals', 'define goals', 'read actionable advice', 'best practices', 'podcast',
    'webinar', 'survey', 'newsletter', 'predictions', 'forecast', 'roundup'
}

STRONG_INCIDENT_CORE = {
    'ransomware', 'breach', 'breached', 'data breach', 'data leak', 'hacked', 'hack',
    'cyberattack', 'cyber attack', 'cybersecurity incident', 'security incident',
    'compromise', 'compromised', 'leak', 'leaked', 'ddos', 'distributed denial of service',
    'service disruption', 'outage', 'unauthorized access', 'malware', 'intrusion', 'extortion',
    'magecart', 'payment breach', 'skimmer', 'stolen data', 'customer data',
    'credential theft', 'credential stuffing', 'account takeover', 'web skimmer',
    'checkout compromise', 'exfiltration', 'website defacement', 'supply chain attack', 'infostealer'
}

ENTERTAINMENT_NOISE_TERMS = {
    'kanye west', ' ye ', " ye's", 'perdón público', 'perdon publico', 'fans', 'celebrity',
    'album', 'music', 'grammys', 'oscars', 'fashion week', 'runway', 'red carpet', 'festival',
    'gossip', 'viral', 'influencer', 'podcast', 'opinion', 'editorial', 'review', 'street style'
}

RETAIL_CONTEXT_TERMS = {
    'fashion', 'apparel', 'clothing', 'textile', 'retail', 'retailer', 'brand', 'brands', 'store', 'shop',
    'ecommerce', 'e-commerce', 'marketplace', 'luxury', 'footwear', 'sneaker', 'moda', 'ropa', 'textil', 'lujo', 'calzado'
}

AMBIGUOUS_BRANDS = {'next', 'guess', 'coach', 'gap', 'goat', 'cider', 'cos', 'arket', 'weekday', 'monki', 'revolve', 'hm', 'm&s', 'stockx'}
BRAND_LABELS = {k: k.title() for k in BRAND_TO_COUNTRY.keys()}
BRAND_LABELS.update({
    'h&m': 'H&M', 'hm group': 'H&M Group', 'm&s': 'Marks & Spencer', 'macys': "Macy's", "macy's": "Macy's",
    'hugo boss': 'Hugo Boss', 'pepe jeans': 'Pepe Jeans', 'jd sports': 'JD Sports', 'new look': 'New Look',
    'foot locker': 'Foot Locker', 'dr martens': 'Dr. Martens', 'banana republic': 'Banana Republic',
})


def _norm(text: str | None) -> str:
    return normalize_spaces(text or '')


def core_blob(article: dict[str, Any]) -> str:
    return ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
        article.get('content') or '',
    ])


def title_summary_blob(article: dict[str, Any]) -> str:
    return ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
    ])


def source_blob(article: dict[str, Any]) -> str:
    return ' '.join([
        article.get('feed_name') or '',
        article.get('feed_url') or '',
        article.get('article_url') or '',
        article.get('rationale') or '',
    ])


def article_blob(article: dict[str, Any]) -> str:
    return ' '.join([core_blob(article), source_blob(article)])


def _has_phrase(text: str, term: str) -> bool:
    return re.search(rf'(?<!\w){re.escape(term)}(?!\w)', text) is not None


def _term_hits(text: str, terms: set[str]) -> list[str]:
    return [term for term in sorted(terms, key=len, reverse=True) if _has_phrase(text, term)]


def _has_retail_context(text: str) -> bool:
    return any(_has_phrase(text, term) for term in RETAIL_CONTEXT_TERMS)


def has_direct_cyber_signal(article: dict[str, Any], *, include_source: bool = False) -> bool:
    blob = _norm(core_blob(article))
    if include_source:
        blob = f"{blob} {_norm(source_blob(article))}".strip()
    return bool(_term_hits(blob, DIRECT_INCIDENT_TERMS))


def detect_known_brand(article: dict[str, Any]) -> str | None:
    primary_blob = _norm(core_blob(article))
    title_blob = _norm(title_summary_blob(article))
    for brand in sorted(BRAND_TO_COUNTRY.keys(), key=len, reverse=True):
        if not _has_phrase(primary_blob, brand):
            continue
        if brand in AMBIGUOUS_BRANDS:
            context_blob = f"{primary_blob} {title_blob}"
            if not _has_retail_context(context_blob) and not any(_has_phrase(context_blob, hint) for hint in ('plc', 'inc', 'group', 'retailer', 'brand', 'fashion', 'apparel', 'clothing', 'marketplace', 'sneaker')):
                continue
        return BRAND_LABELS.get(brand, brand.title())
    return None


def has_strong_incident_core(article: dict[str, Any]) -> bool:
    text = _norm(core_blob(article))
    return bool(_term_hits(text, STRONG_INCIDENT_CORE))


def has_title_incident_signal(article: dict[str, Any]) -> bool:
    text = _norm(title_summary_blob(article))
    return bool(_term_hits(text, STRONG_INCIDENT_CORE | {'phishing'}))


def has_country_or_brand_anchor(article: dict[str, Any]) -> bool:
    country, _source = infer_country_general(article)
    if country:
        return True
    return detect_known_brand(article) is not None


def has_curated_general_context(article: dict[str, Any]) -> bool:
    source = _norm(source_blob(article))
    return any(term in source for term in (
        'google news -', 'bleepingcomputer', 'dark reading', 'crowdstrike', 'cisa',
        'cis advisories', 'recorded future', 'therecord', 'securityweek', 'hackread',
        'cybersecuritynews', 'the hacker news'
    ))


def has_strong_general_story(article: dict[str, Any]) -> bool:
    title_hit = has_title_incident_signal(article)
    direct_hit = has_direct_cyber_signal(article, include_source=False)
    anchored = has_country_or_brand_anchor(article)
    curated = has_curated_general_context(article)
    return (title_hit and anchored) or (direct_hit and anchored) or (title_hit and curated)


def has_entertainment_noise(article: dict[str, Any]) -> bool:
    text = _norm(core_blob(article))
    return any(term in text for term in ENTERTAINMENT_NOISE_TERMS)


def validated_general_article(article: dict[str, Any]) -> bool:
    if validated_marcas_article(article):
        return False
    text = _norm(core_blob(article))
    if has_entertainment_noise(article):
        return False
    direct_hit = has_direct_cyber_signal(article, include_source=False)
    strong_story = has_strong_general_story(article)
    if not direct_hit and not strong_story:
        return False
    if any(term in text for term in ADVISORY_NOISE_TERMS) and not (has_strong_incident_core(article) or has_title_incident_signal(article)):
        return False
    return True


def validated_marcas_article(article: dict[str, Any]) -> bool:
    brand = detect_known_brand(article)
    if not brand:
        return False
    text = _norm(core_blob(article))
    title_summary = _norm(title_summary_blob(article))
    if not has_direct_cyber_signal(article, include_source=False):
        return False
    if has_entertainment_noise(article):
        return False
    if any(term in text for term in ADVISORY_NOISE_TERMS) and not has_strong_incident_core(article):
        return False
    brand_norm = _norm(brand)
    brand_in_core = _has_phrase(text, brand_norm)
    brand_in_title_summary = _has_phrase(title_summary, brand_norm)
    attack_in_title_summary = bool(_term_hits(title_summary, STRONG_INCIDENT_CORE | {'phishing'}))
    if not brand_in_core:
        return False
    # Para Marcas la víctima debe aparecer claramente en título/resumen o, al menos,
    # el titular debe hablar de un incidente real mientras la marca se menciona en el cuerpo.
    if not brand_in_title_summary and not attack_in_title_summary:
        return False
    # Evita artículos donde la marca sale perdida en un cuerpo largo pero el foco real es otro.
    if not brand_in_title_summary and len(text) > 900:
        return False
    return True


def display_sector(article: dict[str, Any]) -> str:
    if validated_marcas_article(article):
        return 'marcas_retail'
    if validated_general_article(article):
        return 'general'
    return 'discarded'


def filter_articles_for_sector_display(articles: list[dict[str, Any]], sector: str = 'general') -> list[dict[str, Any]]:
    sector_norm = (sector or 'general').strip().lower()
    output: list[dict[str, Any]] = []
    for article in articles:
        visible_sector = display_sector(article)
        if visible_sector == 'discarded':
            continue
        if sector_norm == 'marcas_retail' and visible_sector != 'marcas_retail':
            continue
        # General actúa como vista global de incidentes ciber: incluye también
        # las noticias válidas del subconjunto Marcas para que no desaparezcan
        # del mapa principal ni de la lista al refrescar.
        if sector_norm == 'general' and visible_sector not in {'general', 'marcas_retail'}:
            continue
        item = dict(article)
        item['display_sector'] = visible_sector
        output.append(item)
    return output


def infer_country_general(article: dict[str, Any]) -> tuple[str | None, str]:
    entities = article.get('entities') or {}
    for field in ('locations', 'countries'):
        for value in entities.get(field, []) or []:
            canonical = normalize_country_name(value)
            if canonical:
                return canonical, 'entity-country'

    text = _norm(article_blob(article))
    for country, aliases in COUNTRY_ALIASES.items():
        for alias in aliases:
            if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', text):
                return normalize_country_name(country), 'country'

    for alias, canonical in GLOBAL_COUNTRY_TERMS:
        if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', text):
            return normalize_country_name(canonical), 'country-global'

    brand = detect_known_brand(article)
    if brand:
        for key, label in BRAND_LABELS.items():
            if label == brand and key in BRAND_TO_COUNTRY:
                return normalize_country_name(BRAND_TO_COUNTRY[key]), 'brand-country'

    return None, 'unknown'


def infer_target_label(article: dict[str, Any], sector: str) -> str:
    brand = detect_known_brand(article)
    if sector == 'marcas_retail':
        return brand or 'Marca validada'
    entities = article.get('entities') or {}
    vendors = entities.get('vendors') or []
    if vendors:
        return str(vendors[0])
    return article.get('feed_name') or 'Incidente general'



def _year_selection(rows: list[dict[str, Any]], selected_year: int | str | None):
    current_year = datetime.now().year
    years = sorted({year_for_article(row) for row in rows if year_for_article(row) >= MIN_BRANDS_MAP_YEAR})
    latest_populated_year = max(years, default=current_year)
    available_years = list(range(MIN_BRANDS_MAP_YEAR, max(current_year, latest_populated_year) + 1))
    selected_norm = str(selected_year).strip().lower() if selected_year is not None else ''
    selected_mode = 'latest'
    if selected_norm in {'all', '2024+'}:
        selected_mode = 'all'
        active_year = 'all'
        active_rows = list(rows)
    elif selected_norm and selected_norm not in {'latest', 'none'}:
        try:
            requested_year = max(MIN_BRANDS_MAP_YEAR, int(selected_norm))
        except Exception:
            requested_year = latest_populated_year
            selected_mode = 'latest'
        else:
            selected_mode = 'specific'
        active_year = requested_year
        active_rows = [row for row in rows if year_for_article(row) == int(active_year)]
    else:
        active_year = latest_populated_year
        active_rows = [row for row in rows if year_for_article(row) == int(active_year)]
    year_counts = {'latest': sum(1 for row in rows if year_for_article(row) == latest_populated_year), 'all': len(rows)}
    year_counts.update({str(year): sum(1 for row in rows if year_for_article(row) == year) for year in available_years})
    years_payload = ['latest', 'all'] + [str(year) for year in available_years]
    return active_rows, years_payload, year_counts, str(active_year), selected_mode, str(latest_populated_year)


def _point_payload(country: str, grouped_items: list[dict[str, Any]], count: int) -> dict[str, Any]:
    x, y = world_xy(country)
    latest = grouped_items[0] if grouped_items else {}
    x_pct = round((x / MAP_IMAGE_WIDTH) * 100.0, 3)
    y_pct = round((y / MAP_IMAGE_HEIGHT) * 100.0, 3)
    labels = []
    for item in grouped_items:
        label = item.get('label')
        if label and label not in labels:
            labels.append(label)
    attack_types = []
    for item in grouped_items:
        attack = item.get('attack_type')
        if attack and attack not in attack_types:
            attack_types.append(attack)
    return {
        'country': country,
        'country_key': country_key(country),
        'count': count,
        'x': round(x, 2),
        'y': round(y, 2),
        'x_pct': x_pct,
        'y_pct': y_pct,
        'labels': labels[:6],
        'attack_types': attack_types[:6],
        'article_ids': [item['id'] for item in grouped_items if item.get('id')],
        'latest_date': latest.get('published_at'),
        'latest_label': latest.get('label') or '',
        'latest_attack_type': latest.get('attack_type') or 'Incidente ciber',
        'latest_source': latest.get('feed_name') or latest.get('source') or 'Fuente no inferida',
    }


def build_incident_map_data(articles: list[dict[str, Any]], sector: str = 'general', status: str = 'all', selected_year: int | str | None = None) -> dict[str, Any]:
    sector_norm = (sector or 'general').strip().lower()
    filtered = filter_articles_for_sector_display(articles, sector_norm if sector_norm in {'general', 'marcas_retail'} else 'general')
    if status != 'all':
        filtered = [row for row in filtered if row.get('status') == status]
    filtered = [row for row in filtered if year_for_article(row) >= MIN_BRANDS_MAP_YEAR]

    active_rows, years_payload, year_counts, active_year, selected_mode, latest_populated_year = _year_selection(filtered, selected_year)
    incidents: list[dict[str, Any]] = []
    country_counts: dict[str, int] = defaultdict(int)
    grouped_by_country: dict[str, list[dict[str, Any]]] = defaultdict(list)
    attack_counts: dict[str, int] = defaultdict(int)
    unresolved = 0
    status_counts = {
        'included': sum(1 for row in active_rows if row.get('status') == 'included'),
        'pending': sum(1 for row in active_rows if row.get('status') == 'pending'),
        'excluded': sum(1 for row in active_rows if row.get('status') == 'excluded'),
    }

    for article in active_rows:
        if sector_norm == 'marcas_retail':
            country, brand, source = infer_country_and_brand(article)
            label = brand or detect_known_brand(article) or 'Marca validada'
        else:
            country, source = infer_country_general(article)
            label = infer_target_label(article, 'general')
        country = normalize_country_name(country) if country else None
        attack = infer_attack_label(article)
        incident = {
            'id': article.get('id'),
            'title': article.get('title') or 'Sin título',
            'country': country or 'No inferido',
            'country_key': country_key(country or 'No inferido'),
            'label': label,
            'attack_type': attack,
            'published_at': article.get('published_at') or article.get('created_at'),
            'article_url': article.get('article_url') or '',
            'feed_name': article.get('feed_name') or '',
            'source': source,
            'score': round(float(article.get('relevance_score') or 0), 3),
            'status': article.get('status') or 'pending',
        }
        incidents.append(incident)
        attack_counts[attack] += 1
        px, py = project_country_to_map(country)
        if country and px is not None and py is not None:
            country_counts[country] += 1
            grouped_by_country[country].append(incident)
        else:
            unresolved += 1

    incidents.sort(key=lambda item: item.get('published_at') or '', reverse=True)
    points = []
    for country, count in sorted(country_counts.items(), key=lambda kv: (-kv[1], kv[0])):
        grouped = sorted(grouped_by_country[country], key=lambda item: item.get('published_at') or '', reverse=True)
        points.append(_point_payload(country, grouped, count))

    top_countries = [
        {
            'country': point['country'],
            'count': point['count'],
            'labels': point['labels'][:4],
        }
        for point in points[:10]
    ]
    top_attacks = [
        {'label': label, 'count': count}
        for label, count in sorted(attack_counts.items(), key=lambda kv: (-kv[1], kv[0]))[:8]
    ]

    totals = {
        'all_articles': len(active_rows),
        'visible_articles': len(incidents),
        'mapped_articles': len([item for item in incidents if item['country'] != 'No inferido']),
        'incidents': len(active_rows),
        'countries': len(country_counts),
        'targets': len({item['label'] for item in incidents if item['label']}),
        'unresolved': unresolved,
        'included': status_counts['included'],
        'pending': status_counts['pending'],
        'excluded': status_counts['excluded'],
    }

    if sector_norm == 'marcas_retail':
        title = 'Mapa anual · Marcas'
        description = 'Solo víctimas válidas del sector textil / retail / moda / ecommerce detectadas por el filtro de Marcas.'
    else:
        title = 'Mapa anual · General'
        description = 'Noticias generales de ciberseguridad con país detectado por contexto o localización explícita.'

    return {
        'map_type': sector_norm,
        'title': title,
        'description': description,
        'year': str(active_year),
        'selected_mode': selected_mode,
        'available_years': years_payload,
        'latest_populated_year': str(latest_populated_year),
        'year_counts': year_counts,
        'totals': totals,
        'points': points,
        'top_countries': top_countries,
        'top_attacks': top_attacks,
        'incidents': incidents[:24],
        'map_base_image': MAP_IMAGE_PATH,
        'methodology': 'El mapa usa anclas visuales por país. En Marcas se prioriza la marca víctima validada; en General se intenta inferir el país por contexto explícito en el texto.',
    }

# CyberRad V4.5

Motor local de curación de noticias de ciberseguridad con:
- aliases y sinónimos
- scoring híbrido léxico + semántico
- aprendizaje por feedback manual
- deduplicación avanzada
- clustering temático de campañas
- exportación DOCX

## Arranque rápido (Windows CMD)

```bat
cd /d D:\Descargas\cyberrad_v4_5_semantic
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 3000 --app-dir .
```

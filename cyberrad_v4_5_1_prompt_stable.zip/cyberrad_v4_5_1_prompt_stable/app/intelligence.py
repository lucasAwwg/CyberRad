from __future__ import annotations

import json
from typing import Any

from .clustering import assign_clusters
from .entities import extract_entities
from .feedback import build_feedback_profile, score_feedback
from .rss import article_matches_date_window, detect_sector_categories, parse_prompt, score_against_prompt, thresholds_for_mode
from .semantic import semantic_score


def _mode_adjustments(mode: str) -> tuple[float, float, float]:
    if mode == 'flexible':
        return 0.45, 0.35, 0.20
    if mode == 'strict':
        return 0.58, 0.30, 0.12
    return 0.52, 0.32, 0.16


def _human_campaign(label: str | None) -> str | None:
    if not label:
        return None
    return label.split(':', 1)[-1]


def analyze_articles(rows: list[dict[str, Any]], prompt: str, date_window: str = 'all', relevance_mode: str = 'balanced') -> list[dict[str, Any]]:
    manual_rows = [row for row in rows if row.get('status_origin') == 'manual']
    profile = build_feedback_profile(manual_rows)
    parsed_prompt = parse_prompt(prompt)
    analyzed: list[dict[str, Any]] = []
    for row in rows:
        entities = extract_entities(row.get('title') or '', row.get('summary') or '', row.get('content') or '')
        lexical_score, lexical_rationale, tags, _ = score_against_prompt(
            prompt,
            row.get('title') or '',
            row.get('summary') or '',
            row.get('content') or '',
            feed_name=row.get('feed_name') or '',
            feed_url=row.get('feed_url') or '',
            published_at=row.get('published_at') or '',
            relevance_mode=relevance_mode,
        )
        base_tags = list(dict.fromkeys((row.get('match_tags') or []) + tags + entities.get('tags', [])))[:12]
        sector_categories, sector_tags, sector_reasons = detect_sector_categories(
            row.get('title') or '',
            row.get('summary') or '',
            row.get('content') or '',
            feed_name=row.get('feed_name') or '',
            feed_url=row.get('feed_url') or '',
            existing_tags=base_tags,
        )
        row['match_tags'] = list(dict.fromkeys(base_tags + sector_tags))[:12]
        row['sector_categories'] = sector_categories
        row['entities'] = entities
        sem_score, sem_reasons = semantic_score(prompt, row)
        fb_score_raw, fb_reasons = score_feedback(profile, row)
        fb_norm = max(0.0, min((fb_score_raw + 0.35) / 0.70, 1.0)) if profile.get('samples') else 0.0
        lex_w, sem_w, fb_w = _mode_adjustments(relevance_mode)
        hybrid = (lexical_score * lex_w) + (sem_score * sem_w) + (fb_norm * fb_w)
        if fb_score_raw < 0:
            hybrid += fb_score_raw * 0.25
        hybrid = round(max(0.0, min(hybrid, 1.0)), 4)
        include_threshold, pending_threshold = thresholds_for_mode(relevance_mode)
        if not parsed_prompt['raw']:
            status = 'pending'
        elif hybrid >= include_threshold:
            status = 'included'
        elif hybrid >= pending_threshold:
            status = 'pending'
        else:
            status = 'excluded'
        reasons = [f"Léxico {lexical_score:.2f}", f"Semántico {sem_score:.2f}"]
        if profile.get('samples'):
            reasons.append(f"Feedback {fb_score_raw:+.2f}")
        reasons.append(lexical_rationale)
        reasons.extend(sem_reasons[:2])
        reasons.extend(fb_reasons[:2])
        reasons.extend(sector_reasons[:2])
        if not article_matches_date_window(row.get('published_at'), date_window):
            status = 'excluded'
            reasons.insert(0, f"Fuera de ventana temporal {date_window}")
        row['computed_status'] = status
        row['semantic_score'] = sem_score
        row['feedback_score'] = fb_score_raw
        row['hybrid_score'] = hybrid
        row['rationale'] = '. '.join([reason for reason in reasons if reason]) + f'. Score final {hybrid:.2f}.'
        analyzed.append(row)
    cluster_map = assign_clusters(analyzed)
    for row in analyzed:
        cluster_meta = cluster_map.get(row['id'], {})
        row['duplicate_group'] = cluster_meta.get('duplicate_group')
        row['duplicate_rank'] = cluster_meta.get('duplicate_rank')
        row['campaign_cluster'] = cluster_meta.get('campaign_cluster')
        if row.get('campaign_cluster'):
            row['match_tags'] = list(dict.fromkeys(row['match_tags'] + [_human_campaign(row['campaign_cluster'])]))[:12]
            row['rationale'] += f" Cluster temático: {_human_campaign(row['campaign_cluster'])}."
        if row.get('duplicate_group') and row.get('duplicate_rank', 1) > 1:
            row['rationale'] += ' Detectada como cobertura duplicada de un mismo evento.'
    return analyzed

# CyberRad 5.0 — patch del filtro **Marcas** (textil/retail/ecommerce + ciberseguridad)

Este paquete rehace la lógica de **Marcas** para que deje de meter posts genéricos de ciberseguridad y muestre lo que querías:

- **solo incidentes ciber reales o plausibles**
- **solo si la víctima es una marca o retailer real**
- foco en **moda, textil, lujo, calzado, sportswear, beauty retail y ecommerce de consumo**
- salida preparada para **tarjetas** y para **mapa**

## Qué corrige

El problema de la versión anterior era este:

- detectaba palabras como `brand`, `store`, `retail`, `fashion`
- pero no exigía una **marca víctima concreta**
- entonces colaban posts tipo:
  - Microsoft Security Blog
  - BleepingComputer opinion / research
  - advisory / guides / fundamentals / threat intel general

Con este patch, **Marcas** solo entra si se cumplen estas reglas:

1. hay una **marca o retailer concreto** detectado
2. hay un **incidente ciber** detectado
3. la noticia final va por **HTTPS**
4. el dominio final de la noticia está en una **allowlist** de medios/portales reputados
5. se expulsan dominios de **vendor blogs** y textos tipo advisory/guide/research

## Cómo decide si una noticia entra en Marcas

### Incluye solo si

- detecta una marca como `Mango`, `Nike`, `Adidas`, `Zara`, `H&M`, `Pepe Jeans`, etc.
- detecta términos como:
  - `data breach`
  - `breach`
  - `hacked`
  - `cyberattack`
  - `ransomware`
  - `leak`
  - `compromise`
  - `Magecart`
  - `skimming`
  - `customer data exposed`
- el enlace final de la noticia es **HTTPS**
- el dominio final está permitido

### Excluye automáticamente si

- parece post educativo o advisory
- el dominio es de vendor blog
- no hay víctima clara
- no hay incidente claro
- habla de ciberseguridad en general, pero no de una **marca afectada**

## Fuentes y descubrimiento

El patch usa dos capas:

### 1) feeds directos / oficiales / sectoriales

- BleepingComputer
- SecurityWeek (data breaches)
- The Record
- FashionNetwork (retail / business / industry)
- ET Retail (apparel / sportswear / footwear)
- The Guardian (fashion / retail / cybercrime)

### 2) Google News RSS por marca

Genera búsquedas tipo:

- `"Mango" (data breach OR cyberattack OR ransomware ...)`
- `"Nike" (...)`
- `"Zara" (...)`

Eso sirve para descubrir noticias en diarios nacionales e internacionales.

Luego, **la noticia final** solo entra si el dominio real es **HTTPS** y está en la allowlist de confianza.

## Importante sobre seguridad de fuentes

Este patch **reduce mucho el riesgo**, pero **no puede garantizar riesgo cero de malware**.

Lo que sí hace:

- exige **HTTPS**
- deja la validación TLS por defecto de `requests`
- usa **allowlist** de dominios reputados
- bloquea dominios de vendor blogs para el filtro Marcas

## Estructura

- `app/brand_catalog.py` → marcas textiles y país de referencia para el mapa
- `app/trusted_sources.py` → feeds y allowlists
- `app/feed_builder.py` → queries Google News por marca
- `app/filters.py` → scoring y decisión de inclusión
- `app/country_anchors.py` → centros visuales calibrados por país para el mapa
- `app/map_builder.py` → payload agregado por país para el mapa
- `app/main.py` → API FastAPI y runner

## Integración rápida con CyberRad

La idea es sustituir la lógica antigua de `Marcas` por esta:

1. obtienes items RSS
2. a cada item le pasas `MarcasFilter.classify(...)`
3. pintas en la UI **solo** los que tengan `include = true`
4. para el mapa, usas `build_map_payload(...)`

Campos útiles de salida:

- `include`
- `score`
- `brand`
- `incident_terms`
- `map_country_iso2`
- `map_country_label`
- `status`
- `rationale`

## Cómo arrancarlo con Docker en Kali / Linux

```bash
authorized_dir="$HOME/cyberrad_v5_marcas_patch"
mkdir -p "$authorized_dir"
cd "$authorized_dir"
```

Copia aquí el contenido del zip y luego:

```bash
docker compose up -d --build
```

Probar:

```bash
curl http://127.0.0.1:8080/health
curl "http://127.0.0.1:8080/scan/marcas?limit=50"
curl "http://127.0.0.1:8080/scan/map?limit=50"
```

Parar:

```bash
docker compose down
```

## Sin Docker

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:api --host 0.0.0.0 --port 8080
```

## Regla de producto recomendada

Usa esta regla en tu lógica general de UI:

> El filtro Marcas solo debe mostrar noticias donde la víctima principal sea una marca o retailer real de consumo del sector textil/moda/luxury/footwear/ecommerce, y donde exista un incidente ciber concreto. No incluir blogs educativos, advisory posts, análisis generales ni publicaciones de vendors si no informan de una marca afectada específica.

## Siguiente paso recomendado

En tu frontend:

- el botón **Marcas** debe consumir `/scan/marcas`
- el mapa debe consumir `/scan/map`
- los marcadores deben usar `map_country_iso2`
- si `status == "pendiente"`, puedes dejarlo en revisión manual



## Fix del mapa: sin geocoder y sin puntos corridos

Este ajuste cambia la salida de `/scan/map` para que **no dependa de geocodificación dinámica**.

Ahora el backend devuelve **un marcador por país**, con:

- `country_iso2`
- `country_label`
- `count`
- `brands`
- `incident_terms`
- `lat`
- `lng`
- `x_pct`
- `y_pct`
- `anchor_source`

### Regla recomendada para frontend

Para un mapa mundi estático como el negro con fronteras blancas:

- **no geocodifiques el nombre del país en el navegador**
- **no intentes calcular el punto con un geocoder externo**
- pinta el punto directamente con `x_pct` y `y_pct`
- usa `transform: translate(-50%, -50%)` para centrar bien la burbuja

Ejemplo de colocación:

```css
.country-marker {
  position: absolute;
  left: calc(var(--x) * 100%);
  top: calc(var(--y) * 100%);
  transform: translate(-50%, -50%);
}
```

Con esto se evita que países como **Cuba, Estados Unidos o Panamá** salgan desplazados.

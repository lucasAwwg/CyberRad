from __future__ import annotations

import json
import re
from collections import OrderedDict
from datetime import datetime, timezone
from typing import Any
from urllib.parse import parse_qs, urlparse

import feedparser
import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI
from fastapi.responses import JSONResponse

from app.feed_builder import build_google_news_brand_queries
from app.filters import MarcasFilter
from app.map_builder import build_map_payload
from app.trusted_sources import DIRECT_SOURCE_FEEDS

USER_AGENT = "CyberRad/5.0 Marcas Textil Patch (+https://localhost)"
TIMEOUT = 20

api = FastAPI(title="CyberRad Marcas 5.0 Patch", version="5.0")
filter_engine = MarcasFilter()


@api.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@api.get("/scan/marcas")
def scan_marcas(limit: int = 200) -> JSONResponse:
    items = run_scan(limit=limit)
    return JSONResponse(items)


@api.get("/scan/map")
def scan_map(limit: int = 200) -> JSONResponse:
    items = run_scan(limit=limit)
    return JSONResponse(build_map_payload(items))


def run_scan(limit: int = 200) -> list[dict[str, Any]]:
    raw_items: list[dict[str, Any]] = []
    for feed in DIRECT_SOURCE_FEEDS + build_google_news_brand_queries():
        raw_items.extend(fetch_feed(feed))

    deduped = dedupe_items(raw_items)
    decisions = [filter_engine.classify(item).to_dict() | {"published": item.get("published")} for item in deduped]
    decisions.sort(key=lambda item: (item["include"], item["score"], item.get("published") or ""), reverse=True)
    return decisions[:limit]


def fetch_feed(feed: dict[str, Any]) -> list[dict[str, Any]]:
    try:
        parsed = feedparser.parse(feed["url"])
    except Exception:
        return []

    items: list[dict[str, Any]] = []
    for entry in parsed.entries:
        article_url = extract_article_url(entry.get("link", ""))
        title = clean_html(entry.get("title", ""))
        summary = clean_html(entry.get("summary", ""))
        content = ""
        if entry.get("content"):
            first = entry["content"][0]
            content = clean_html(first.get("value", ""))
        source = feed.get("name")
        if entry.get("source") and isinstance(entry["source"], dict):
            source = entry["source"].get("title") or source
        published = normalize_published(entry)
        items.append(
            {
                "title": title,
                "summary": summary,
                "content": content,
                "url": entry.get("link", ""),
                "article_url": article_url,
                "source": source,
                "publisher_domain": urlparse(article_url if article_url else feed["url"]).netloc,
                "published": published,
                "discovery_only_source": bool(feed.get("discovery_only")),
            }
        )
    return items


def dedupe_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: OrderedDict[str, dict[str, Any]] = OrderedDict()
    for item in items:
        key = make_key(item)
        if key not in seen:
            seen[key] = item
    return list(seen.values())


def make_key(item: dict[str, Any]) -> str:
    title = re.sub(r"\s+", " ", (item.get("title") or "").lower()).strip()
    article_url = (item.get("article_url") or "").strip().lower()
    return article_url or title


def extract_article_url(url: str) -> str:
    if not url:
        return ""
    parsed = urlparse(url)
    if "news.google.com" not in parsed.netloc:
        return url
    qs = parse_qs(parsed.query)
    direct = qs.get("url")
    if direct:
        return direct[0]
    return url


def clean_html(value: str) -> str:
    if not value:
        return ""
    soup = BeautifulSoup(value, "html.parser")
    text = soup.get_text(" ", strip=True)
    return re.sub(r"\s+", " ", text).strip()


def normalize_published(entry: Any) -> str:
    if getattr(entry, "published_parsed", None):
        dt = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
        return dt.isoformat()
    if entry.get("published"):
        return str(entry.get("published"))
    return ""


if __name__ == "__main__":
    output = run_scan(limit=200)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = f"/app/out/marcas_scan_{ts}.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(output, fh, ensure_ascii=False, indent=2)
    print(path)

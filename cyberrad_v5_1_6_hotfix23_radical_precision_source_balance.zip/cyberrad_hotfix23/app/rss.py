from __future__ import annotations

import hashlib
import html
import json
import re
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from typing import Any
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

STOPWORDS = {
    'para', 'como', 'sobre', 'entre', 'desde', 'hasta', 'that', 'this', 'with', 'from',
    'have', 'will', 'would', 'there', 'their', 'them', 'about', 'https', 'http', 'www',
    'security', 'cyber', 'news', 'and', 'the', 'una', 'unos', 'unas', 'por', 'porque',
    'pero', 'also', 'into', 'your', 'what', 'where', 'when', 'been', 'they', 'them',
    'los', 'las', 'del', 'con', 'sin', 'que', 'or', 'o', 'de', 'el', 'la', 'un', 'una',
    'latest', 'report', 'reports', 'analysis', 'blog', 'update', 'updates', 'new',
}

HEADERS = {'User-Agent': 'CyberRadV4.5/1.0 (+https://localhost:3000)'}

CONCEPT_LEXICON: dict[str, dict[str, Any]] = {
    'active_directory': {
        'label': 'Active Directory',
        'aliases': ['active directory', 'ad', 'domain controller', 'domain controllers', 'ldap', 'kerberos', 'ntlm', 'group policy', 'gpo', 'windows domain', 'directory services', 'azure ad', 'entra id', 'microsoft entra id', 'aad'],
        'context': ['microsoft', 'windows', 'domain', 'directory', 'identity', 'authentication', 'ldap', 'kerberos', 'gpo'],
        'ambiguous_aliases': {'ad'},
        'tags': ['Identity', 'Microsoft'],
    },
    'cve': {
        'label': 'CVE / Vulnerabilidades',
        'aliases': ['cve', 'vulnerability', 'vulnerabilities', 'security advisory', 'security advisories', 'advisory', 'advisories', 'flaw', 'security flaw', 'patch', 'exploit', 'exploited cve', 'zero-day', '0day', '0-day', 'actively exploited'],
        'tags': ['Vulnerability'],
    },
    'malware': {
        'label': 'Malware',
        'aliases': ['malware', 'ransomware', 'trojan', 'loader', 'backdoor', 'stealer', 'rat', 'wiper', 'botnet', 'infostealer', 'worm', 'dropper'],
        'tags': ['Malware'],
    },
    'ransomware': {
        'label': 'Ransomware',
        'aliases': ['ransomware', 'encryptor', 'double extortion', 'extortion group'],
        'tags': ['Malware', 'Ransomware'],
    },
    'phishing': {
        'label': 'Phishing',
        'aliases': ['phishing', 'smishing', 'vishing', 'credential theft', 'credential phishing', 'email lure'],
        'tags': ['Phishing'],
    },
    'edr': {
        'label': 'EDR / XDR',
        'aliases': ['edr', 'xdr', 'endpoint detection and response', 'extended detection and response'],
        'tags': ['Endpoint'],
    },
    'iam': {
        'label': 'Identity / IAM',
        'aliases': ['iam', 'identity', 'identity management', 'identity and access management', 'authentication', 'mfa', '2fa', 'sso'],
        'tags': ['Identity'],
    },
    'windows': {
        'label': 'Windows',
        'aliases': ['windows', 'windows server', 'microsoft windows', 'powershell'],
        'tags': ['Windows'],
    },
    'linux': {
        'label': 'Linux',
        'aliases': ['linux', 'ubuntu', 'debian', 'red hat', 'rhel', 'kernel', 'linux kernel'],
        'tags': ['Linux'],
    },
    'cloud': {
        'label': 'Cloud',
        'aliases': ['cloud', 'aws', 'azure', 'gcp', 'google cloud', 'kubernetes', 'container', 'docker'],
        'tags': ['Cloud'],
    },
    'incident': {
        'label': 'Incidentes',
        'aliases': ['incident', 'incident response', 'breach', 'outage', 'compromise', 'intrusion', 'attack', 'cyberattack'],
        'tags': ['Incident'],
    },
    'threat_intel': {
        'label': 'Threat Intel',
        'aliases': ['threat intelligence', 'threat intel', 'ioc', 'ttps', 'campaign', 'apt', 'actor'],
        'tags': ['ThreatIntel'],
    },
}

ALIAS_TO_CANONICAL: dict[str, str] = {}
for canonical, meta in CONCEPT_LEXICON.items():
    for alias in meta['aliases']:
        ALIAS_TO_CANONICAL[alias.lower()] = canonical
    ALIAS_TO_CANONICAL[meta['label'].lower()] = canonical

SOURCE_PRIORITY = {
    'cisa.gov': 0.18, 'nist.gov': 0.17, 'nvd.nist.gov': 0.17, 'us-cert.gov': 0.17,
    'microsoft.com': 0.16, 'crowdstrike.com': 0.16, 'google.com': 0.11, 'googleblog.com': 0.10,
    'fortinet.com': 0.14, 'incibe.es': 0.14, 'cisecurity.org': 0.14, 'ubuntu.com': 0.11,
    'qualys.com': 0.13, 'bleepingcomputer.com': 0.15, 'darkreading.com': 0.15, 'thehackernews.com': 0.13,
}

SPECIALIST_SOURCE_HINTS = (
    'bleepingcomputer', 'dark reading', 'darkreading', 'the hacker news', 'crowdstrike',
    'cisa', 'nist', 'incibe', 'fortinet', 'qualys', 'microsoft security', 'security advisory',
    'security advisories', 'threat intel', 'threat research', 'duo security', 'grafana security',
)

GENERIC_AGGREGATOR_HINTS = (
    'google news -', 'ap retail cyber', 'reuters retail cyber', 'nyt retail cyber',
    'washington post retail cyber', 'guardian fashion cyber', 'bbc fashion cyber',
)

BRAND_FALSE_POSITIVE_TERMS = (
    'gunman', 'shooting', 'court told', 'immigrants', 'amnesty', 'hezbollah', 'diplomatic talks',
    'harvest', 'festival', 'celebration', 'wildfire', 'earthquake', 'murder', 'homicide', 'killing',
    'school attack', 'election', 'parliament', 'football', 'basketball', 'weather',
)

VENDORS = ['Microsoft', 'Google', 'Fortinet', 'Cisco', 'VMware', 'Palo Alto', 'Ivanti', 'FortiOS', 'Ubuntu', 'Linux', 'Windows', 'Synology', 'Grafana', 'Chrome', 'Duo', 'TeamViewer', 'FortiManager', 'Exchange', 'Entra', 'Active Directory']
SEVERITY_TERMS = {'critical': 0.12, 'high severity': 0.08, 'actively exploited': 0.14, 'zero-day': 0.14, '0day': 0.14, '0-day': 0.14, 'remote code execution': 0.12, 'rce': 0.12, 'privilege escalation': 0.10, 'auth bypass': 0.10, 'authentication bypass': 0.10, 'bypass': 0.05}
NOISE_PATTERNS = ['top 10', 'predictions for', 'market report', 'stock', 'streaming', 'music', 'royalty fraud', 'newsletter', 'press release', 'sponsored', 'webinar', 'podcast']
CVE_RE = re.compile(r'\bCVE-\d{4}-\d{4,7}\b', re.IGNORECASE)

CYBER_CONTEXT_TERMS = [
    'cyber', 'cybersecurity', 'security incident', 'cyber incident', 'breach', 'data breach', 'data leak',
    'ransomware', 'malware', 'phishing', 'credential theft', 'credential stuffing', 'account takeover',
    'vulnerability', 'exploit', 'zero-day', '0-day', 'attacker', 'threat actor', 'botnet', 'intrusion',
    'compromise', 'compromised', 'unauthorized access', 'ddos', 'infostealer', 'skimmer', 'magecart',
    'web skimmer', 'payment breach', 'exfiltration', 'incident response', 'soc', 'iam', 'mfa', 'cloud security'
]
AMBIGUOUS_ATTACK_TERMS = ['hack', 'hacks', 'hacked', 'hacking', 'risk', 'digital', 'attack', 'attacked']
NON_CYBER_HACK_PHRASES = [
    'fitness hack', 'gym hack', 'workout hack', 'life hack', 'life hacks', 'health hack', 'beauty hack',
    'travel hack', 'food hack', 'kitchen hack', 'morning hack', 'sleep hack', 'productivity hack',
    'wellness hack', 'diet hack', 'nutrition hack', 'home hack', 'study hack'
]
NON_CYBER_CONTEXT_TERMS = [
    'fitness', 'gym', 'workout', 'wellness', 'diet', 'nutrition', 'recipe', 'beauty', 'lifestyle', 'self improvement',
    'morning routine', 'gut health', 'mental health', 'skincare', 'sleep routine', 'travel tips', 'packing tips',
    'healthy eating', 'weight loss', 'calories', 'protein', 'supplements', 'productivity', 'study tips', 'home decor'
]
IMAGE_URL_BLACKLIST_HINTS = ['logo', 'icon', 'avatar', 'favicon', 'sprite', 'placeholder', 'ads.', '/ads/', 'pixel']
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.webp', '.gif', '.avif')

STRONG_CYBER_TERMS = [
    'ransomware', 'malware', 'phishing', 'data breach', 'breach', 'leaked data', 'data leak', 'cyberattack',
    'cyber attack', 'hacking group', 'threat actor', 'exploit', 'vulnerability', 'zero-day', '0-day', 'botnet',
    'infostealer', 'spyware', 'ddos', 'credential stuffing', 'account takeover', 'compromise', 'compromised',
    'intrusion', 'incident response', 'cve', 'security flaw', 'unauthorized access', 'payment breach', 'web skimmer',
    'magecart', 'credential theft', 'security advisory', 'security bulletin', 'patch tuesday', 'actively exploited'
]
EXPLICIT_CYBER_ATTACK_CONTEXTS = [
    'hacked account', 'hacked accounts', 'hacked systems', 'system hacked', 'systems hacked', 'network hacked',
    'customer data stolen', 'customer data exposed', 'database exposed', 'database leaked', 'servers compromised',
    'email accounts compromised', 'cloud environment compromised', 'stolen credentials', 'stolen customer data',
    'malware attack', 'phishing attack', 'ransomware attack', 'attack on systems', 'attack on networks',
    'attack on accounts', 'attack on infrastructure', 'attack on data'
]
CYBER_INFRA_TERMS = [
    'system', 'systems', 'network', 'networks', 'server', 'servers', 'endpoint', 'endpoints', 'account', 'accounts',
    'database', 'databases', 'credentials', 'identity', 'identities', 'cloud', 'tenant', 'vpn', 'firewall', 'mfa',
    'iam', 'checkout', 'payment page', 'ecommerce platform', 'website', 'web application', 'api', 'source code',
    'repository', 'repositories', 'customer data', 'production environment', 'infrastructure'
]
CYBER_ACTION_TERMS = [
    'breach', 'breached', 'leaked', 'exposed', 'stolen', 'compromised', 'compromise', 'intrusion', 'phishing',
    'malware', 'ransomware', 'exfiltration', 'credential stuffing', 'ddos', 'unauthorized access', 'exploit',
    'vulnerability', 'hacked', 'hack', 'hacking', 'attacker', 'threat actor'
]
HARD_NEGATIVE_CONTEXTS = {
    'physical/animal attack context': [
        'attacked by dogs', 'attacked by dog', 'dog attack', 'dogs attack', 'animal attack', 'bitten by dog',
        'mauled', 'shark attack', 'bear attack'
    ],
    'military attack context': [
        'missile attack', 'missiles', 'bombard', 'bombardment', 'shelling', 'airstrike', 'drone strike',
        'battlefield', 'troops', 'war', 'front line', 'killed in attack', 'military strike', 'artillery'
    ],
    'marketing/branding context': [
        'storytelling', 'brand campaign', 'marketing campaign', 'advertising campaign', 'pr campaign', 'brand equity',
        'new campaign', 'campaign launch', 'creative campaign'
    ],
    'lifestyle/fitness hack context': [
        'fitness hack', 'life hack', 'health hack', 'beauty hack', 'productivity hack', 'food hack', 'travel hack',
        'morning hack', 'sleep hack', 'diet hack', 'nutrition hack', 'gym hack', 'workout hack'
    ],
}
MARKETING_CONTEXT_TERMS = ['marketing', 'advertising', 'storytelling', 'brand equity', 'creative', 'campaign', 'pr']
BUSINESS_NOISE_TERMS = ['shares rose', 'stock price', 'quarterly earnings', 'earnings beat', 'guidance', 'market share']


MARCAS_RETAIL_TERMS = [
    'fashion', 'fashion retail', 'fashion retailer', 'apparel', 'clothing', 'textile', 'textiles',
    'luxury brand', 'luxury brands', 'fashion brand', 'fashion brands', 'clothing brand',
    'online store', 'online stores', 'fashion ecommerce', 'fashion e-commerce', 'ecommerce fashion',
    'fashion store', 'fashion stores', 'boutique', 'boutiques', 'department store', 'department stores',
    'ecommerce', 'e-commerce', 'moda', 'textil', 'textiles', 'tiendas de ropa', 'ropa', 'lujo',
    'tienda online', 'tiendas online', 'cadena textil', 'cadenas textiles', 'retail de moda',
    'empresa textil', 'empresas textiles', 'sector fashion', 'sector apparel', 'sector textile',
    'fashion house', 'fashion houses', 'luxury house', 'luxury retail', 'online fashion retailer',
    'fashion marketplace', 'luxury fashion', 'apparel retailer', 'textile company'
]

MARCAS_RETAIL_GENERIC_TERMS = [
    'retail', 'retailer', 'retailers', 'brand', 'brands', 'marca', 'marcas', 'shop', 'shops',
    'webshop', 'online shop', 'shopping cart', 'checkout', 'point of sale', 'pos terminal',
    'mall retailer', 'b2b', 'b2c'
]

MARCAS_RETAIL_STRONG_TERMS = [
    'fashion', 'apparel', 'clothing', 'textile', 'luxury brand', 'fashion brand', 'fashion retailer',
    'fashion ecommerce', 'fashion store', 'boutique', 'moda', 'textil', 'tiendas de ropa', 'lujo',
    'cadena textil', 'retail de moda', 'empresa textil', 'fashion house', 'luxury retail'
]

MARCAS_RETAIL_COMPANY_HINTS = [
    'zara', 'inditex', 'h&m', 'hm', 'shein', 'uniqlo', 'primark', 'mango', 'gap', 'nike',
    'adidas', 'lululemon', 'under armour', 'pvh', 'tommy hilfiger', 'calvin klein', 'puma',
    'burberry', 'gucci', 'prada', 'louis vuitton', 'dior', 'hermes', 'chanel', 'armani',
    'balenciaga', 'saks', 'macys', "macy's", 'nordstrom', 'asos', 'boohoo', 'zalando',
    'farfetch', 'yoox', 'net-a-porter', "victoria's secret", 'abercrombie', 'hollister',
    'tapestry', 'coach', 'kate spade', 'michael kors', 'ralph lauren', 'decathlon', 'hm group', 'fast retailing', 'levi strauss', 'levis', 'guess', 'superdry', 'moncler', 'burberry group', 'next plc', 'marks and spencer', 'm&s', 'river island', 'sephora', 'lvmh', 'kering', 'otb group'
]

MARCAS_RETAIL_CYBER_TERMS = [
    'cyberattack', 'cyber attack', 'cyber incident', 'security incident', 'data breach',
    'breach', 'breached', 'leaked data', 'leak', 'leakage', 'ransomware', 'malware',
    'phishing', 'credential theft', 'stolen credentials', 'account takeover', 'payment breach',
    'payment skimmer', 'magecart', 'e-skimming', 'skimmer', 'fraud', 'digital fraud', 'hack',
    'hacked', 'hacking', 'compromise', 'compromised', 'attacked', 'attack', 'intrusion',
    'ddos', 'botnet', 'web skimmer', 'supply chain attack', 'security flaw', 'vulnerability',
    'vulnerabilities', 'exploit', 'exploited', 'payment card', 'carding', 'checkout compromise',
    'customer data', 'customer records', 'customer account', 'account breach', 'store outage',
    'robo de credenciales', 'brecha de datos',
    'ataque cibernético', 'ciberataque', 'ciberincidente', 'incidente de ciberseguridad',
    'filtración', 'filtracion', 'fraude digital', 'malware', 'ransomware', 'compromiso de pagos'
]

MARCAS_RETAIL_STRONG_TERMS_EXT = [
    'brand', 'brands', 'retail', 'retailer', 'fashion', 'apparel', 'clothing', 'luxury', 'footwear',
    'shop', 'store', 'online store', 'ecommerce', 'e-commerce', 'webshop', 'marketplace', 'b2b', 'b2c',
    'direct-to-consumer', 'dtc', 'boutique', 'fashion retailer', 'clothing retailer', 'fashion ecommerce',
    'online fashion', 'luxury brand', 'textile retail', 'online fashion retailer', 'online clothing store',
    'digital fashion marketplace', 'ecommerce apparel platform', 'luxury ecommerce platform', 'fashion webshop',
    'streetwear ecommerce', 'sneaker marketplace', 'marketplace fashion', 'apparel platform', 'fashion marketplace'
]

MARCAS_RETAIL_COMPANY_HINTS_EXT = [
    'zalando', 'asos', 'shein', 'boohoo', 'prettylittlething', 'farfetch', 'yoox', 'net-a-porter', 'about you',
    'revolve', 'ssense', 'mytheresa', 'vinted', 'stockx', 'goat', 'fashion nova', 'urban outfitters', 'uniqlo',
    'h&m', 'zara', 'mango', 'nike', 'adidas', 'puma', 'primark', 'decathlon', 'matchesfashion', 'the outnet',
    'namshi', 'cider', 'boohoo man', 'pretty little thing', 'stockx', 'goat', 'vinted', 'about you', 'mytheresa', 'revolve', 'ssense', 'zalando', 'asos', 'shein', 'boohoo', 'prettylittlething', 'farfetch', 'yoox', 'net-a-porter', 'urban outfitters', 'mango', 'zara', 'h&m', 'nike', 'adidas', 'puma', 'primark', 'decathlon', 'uniqlo'
]

MARCAS_RETAIL_EXCLUSION_TERMS = [
    'telecom', 'telco', 'bank', 'banking', 'hospital', 'healthcare', 'government', 'ministries', 'ministry',
    'cryptocurrency', 'crypto exchange', 'blockchain', 'telegram', 'messaging app', 'infrastructure', 'pipeline',
    'utility company', 'software vendor', 'enterprise software', 'saas platform', 'database vendor', 'erp',
    'adobe', 'oracle', 'sap', 'salesforce', 'servicenow', 'vmware', 'atlassian', 'microsoft exchange', 'jira'
]


def clean_html(value: str | None) -> str:
    if not value:
        return ''
    soup = BeautifulSoup(value, 'html.parser')
    return html.unescape(soup.get_text(' ', strip=True))


def normalize_spaces(text: str | None) -> str:
    return re.sub(r'\s+', ' ', (text or '').strip().lower())


def normalize_tokens(text: str) -> list[str]:
    tokens = re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9\-]{2,}", text.lower())
    return [token for token in tokens if token not in STOPWORDS]


def token_set(text: str) -> set[str]:
    return set(normalize_tokens(text))


def unique(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        key = normalize_spaces(item)
        if key and key not in seen:
            seen.add(key)
            out.append(item)
    return out


def phrase_pattern(phrase: str) -> str:
    pieces = [re.escape(piece) for piece in normalize_spaces(phrase).split() if piece]
    if not pieces:
        return ''
    return r'(?<!\w)' + r'\s+'.join(pieces) + r'(?!\w)'


def phrase_in_text(text: str, phrase: str) -> bool:
    pattern = phrase_pattern(phrase)
    if not pattern:
        return False
    return re.search(pattern, normalize_spaces(text), flags=re.IGNORECASE) is not None


def parse_datetime_to_dt(value: str | None) -> datetime:
    if not value:
        return datetime.now(tz=timezone.utc)
    value = value.strip()
    try:
        return parsedate_to_datetime(value).astimezone(timezone.utc)
    except Exception:
        pass
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(timezone.utc)
    except Exception:
        return datetime.now(tz=timezone.utc)


def parse_datetime(value: str | None) -> str:
    return parse_datetime_to_dt(value).isoformat()


def article_matches_date_window(published_at: str | None, date_window: str) -> bool:
    date_window = (date_window or 'all').strip().lower()
    if date_window == 'all':
        return True
    article_dt = parse_datetime_to_dt(published_at)
    now = datetime.now(tz=timezone.utc)
    now_date = now.date()
    article_date = article_dt.date()
    if date_window == 'today':
        return article_date == now_date
    if date_window == 'yesterday':
        return article_date == (now_date - timedelta(days=1))
    try:
        days = int(date_window)
    except Exception:
        return True
    return article_dt >= (now - timedelta(days=days))


def split_prompt_terms(prompt: str) -> tuple[list[str], list[str]]:
    quoted = re.findall(r'"([^"]+)"', prompt)
    prompt_wo_quotes = re.sub(r'"[^"]+"', ' ', prompt)
    pieces = re.split(r'\n|,|;|\||\b(?:or|o)\b', prompt_wo_quotes, flags=re.IGNORECASE)
    include_terms: list[str] = []
    exclude_terms: list[str] = []
    for piece in pieces + quoted:
        item = piece.strip().strip("'“”‘’")
        if not item:
            continue
        if item.startswith('-'):
            exclude_terms.append(item[1:].strip())
        else:
            include_terms.append(item)
    return unique(include_terms), unique(exclude_terms)


def canonical_for_term(term: str) -> str | None:
    norm = normalize_spaces(term)
    if norm in ALIAS_TO_CANONICAL:
        return ALIAS_TO_CANONICAL[norm]
    for alias, canonical in ALIAS_TO_CANONICAL.items():
        if alias == norm or phrase_in_text(norm, alias) or phrase_in_text(alias, norm):
            return canonical
    return None


def variants_for_term(term: str) -> list[str]:
    canonical = canonical_for_term(term)
    if canonical:
        meta = CONCEPT_LEXICON[canonical]
        return unique([meta['label'], *meta['aliases'], term])
    parts = normalize_tokens(term)
    acronym = ''.join(p[0] for p in parts) if len(parts) > 1 else ''
    variants = [term]
    if 2 <= len(acronym) <= 6:
        variants.append(acronym)
    return unique(variants)


def unique_concepts(concepts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for concept in concepts:
        key = concept['canonical'] or normalize_spaces(concept['label'])
        if key in seen:
            continue
        seen.add(key)
        out.append(concept)
    return out


def parse_prompt(prompt: str) -> dict[str, Any]:
    prompt = (prompt or '').strip()
    include_terms, exclude_terms = split_prompt_terms(prompt)
    inferred_terms: list[str] = []
    if prompt and len(include_terms) <= 1:
        lower_prompt = normalize_spaces(prompt)
        for alias in sorted(ALIAS_TO_CANONICAL.keys(), key=len, reverse=True):
            if phrase_in_text(lower_prompt, alias):
                inferred_terms.append(CONCEPT_LEXICON[ALIAS_TO_CANONICAL[alias]]['label'])
    all_include = unique(include_terms + inferred_terms)
    concepts = []
    for term in all_include:
        canonical = canonical_for_term(term)
        label = CONCEPT_LEXICON[canonical]['label'] if canonical else term
        concepts.append({'term': term, 'canonical': canonical, 'label': label, 'variants': variants_for_term(term)})
    severity_filters = [term for term in ['critical', 'high severity', 'actively exploited', 'zero-day', 'rce', 'privilege escalation'] if phrase_in_text(prompt, term)]
    return {'raw': prompt, 'concepts': unique_concepts(concepts), 'exclude_terms': exclude_terms, 'severity_filters': severity_filters}


def get_domain_score(url: str | None) -> float:
    if not url:
        return 0.0
    netloc = urlparse(url).netloc.lower().replace('www.', '')
    best = 0.0
    for domain, score in SOURCE_PRIORITY.items():
        if netloc == domain or netloc.endswith('.' + domain) or domain in netloc:
            best = max(best, score)
    return best



def normalize_media_url(url: str | None, base_url: str | None = None) -> str | None:
    value = html.unescape((url or '').strip())
    if not value:
        return None
    if base_url:
        value = urljoin(base_url, value)
    lowered = value.lower()
    if lowered.startswith(('data:', 'blob:', 'javascript:', 'mailto:')):
        return None
    return value


def media_url_looks_real(url: str | None) -> bool:
    value = (url or '').strip()
    if not value:
        return False
    lowered = value.lower()
    if any(hint in lowered for hint in IMAGE_URL_BLACKLIST_HINTS):
        return False
    if any(lowered.endswith(ext) for ext in IMAGE_EXTENSIONS):
        return True
    return any(token in lowered for token in ('image', 'photo', 'media', 'cdn', 'wp-content', 'img', 'upload'))


def extract_image_from_html_fragment(fragment: str | None, base_url: str | None = None) -> str | None:
    if not fragment:
        return None
    try:
        soup = BeautifulSoup(fragment, 'html.parser')
    except Exception:
        return None
    candidates: list[str] = []
    for img in soup.find_all('img'):
        candidate = img.get('src') or img.get('data-src') or img.get('data-lazy-src')
        if not candidate:
            srcset = img.get('srcset') or img.get('data-srcset') or ''
            if srcset:
                candidate = srcset.split(',')[-1].strip().split(' ')[0]
        candidate = normalize_media_url(candidate, base_url)
        if candidate and media_url_looks_real(candidate):
            candidates.append(candidate)
    return candidates[0] if candidates else None


def non_cyber_context_reasons(title: str, summary: str, content: str, feed_name: str = '', feed_url: str = '') -> list[str]:
    blob = normalize_spaces(' '.join([title or '', summary or '', content or '', feed_name or '', feed_url or '']))
    title_summary = normalize_spaces(' '.join([title or '', summary or '']))
    hard_hits = [term for term in NON_CYBER_HACK_PHRASES if phrase_in_text(title_summary, term)]
    lifestyle_hits = [term for term in NON_CYBER_CONTEXT_TERMS if phrase_in_text(blob, term)]
    ambiguous_hits = [term for term in AMBIGUOUS_ATTACK_TERMS if phrase_in_text(blob, term)]
    cyber_hits = [term for term in CYBER_CONTEXT_TERMS if phrase_in_text(blob, term)]
    reasons: list[str] = []
    if hard_hits and not cyber_hits:
        reasons.append(f"Contexto no ciber detectado: {', '.join(hard_hits[:3])}")
    elif lifestyle_hits and ambiguous_hits and not cyber_hits:
        reasons.append(f"Términos ambiguos en contexto lifestyle/salud: {', '.join((lifestyle_hits + ambiguous_hits)[:4])}")
    return reasons


def strong_negative_context_reasons(title: str, summary: str, content: str) -> list[str]:
    title_summary = normalize_spaces(' '.join([title or '', summary or '']))
    blob = normalize_spaces(' '.join([title or '', summary or '', content or '']))
    cyber_hits = [term for term in STRONG_CYBER_TERMS + EXPLICIT_CYBER_ATTACK_CONTEXTS if phrase_in_text(blob, term)]
    reasons: list[str] = []
    for label, patterns in HARD_NEGATIVE_CONTEXTS.items():
        hits = [pattern for pattern in patterns if phrase_in_text(title_summary, pattern) or phrase_in_text(blob, pattern)]
        if hits and not cyber_hits:
            reasons.append(f"{label}: {', '.join(hits[:3])}")
    if not cyber_hits:
        marketing_hits = [term for term in MARKETING_CONTEXT_TERMS if phrase_in_text(title_summary, term)]
        if marketing_hits and ('identity' in title_summary or 'campaign' in title_summary):
            reasons.append(f"marketing/branding context: {', '.join(marketing_hits[:3])}")
        business_hits = [term for term in BUSINESS_NOISE_TERMS if phrase_in_text(blob, term)]
        if business_hits:
            reasons.append(f"business/market context without cyber evidence: {', '.join(business_hits[:2])}")
    return unique(reasons)[:4]


def cyber_signal_profile(title: str, summary: str, content: str) -> tuple[float, list[str], list[str]]:
    title_summary = normalize_spaces(' '.join([title or '', summary or '']))
    blob = normalize_spaces(' '.join([title or '', summary or '', content or '']))
    strong_hits = [term for term in STRONG_CYBER_TERMS if phrase_in_text(blob, term)]
    explicit_hits = [term for term in EXPLICIT_CYBER_ATTACK_CONTEXTS if phrase_in_text(blob, term)]
    infra_hits = [term for term in CYBER_INFRA_TERMS if phrase_in_text(blob, term)]
    action_hits = [term for term in CYBER_ACTION_TERMS if phrase_in_text(blob, term)]
    ambiguous_hits = [term for term in AMBIGUOUS_ATTACK_TERMS if phrase_in_text(blob, term)]
    score = 0.0
    if strong_hits:
        title_summary_hits = [term for term in strong_hits if phrase_in_text(title_summary, term)]
        score += min(len(title_summary_hits) * 0.28, 0.72)
        score += min(max(len(strong_hits) - len(title_summary_hits), 0) * 0.08, 0.20)
    if explicit_hits:
        score += min(len(explicit_hits) * 0.22, 0.44)
    combo = bool(infra_hits) and bool(action_hits)
    if combo:
        score += 0.24
    if 'identity' in ambiguous_hits and not combo and not strong_hits and not explicit_hits:
        score -= 0.08
    if ambiguous_hits and not strong_hits and not explicit_hits and not combo:
        score -= 0.16
    reasons: list[str] = []
    if strong_hits:
        reasons.append(f"señales ciber fuertes: {', '.join(unique(strong_hits)[:4])}")
    if explicit_hits:
        reasons.append(f"contexto explícito de ataque ciber: {', '.join(unique(explicit_hits)[:3])}")
    if combo:
        reasons.append(f"combinación de infraestructura + compromiso: {', '.join(unique((infra_hits + action_hits))[:4])}")
    return round(max(0.0, min(score, 1.0)), 4), reasons, unique(ambiguous_hits)


def duplicate_resolution_priority(article: dict[str, Any]) -> float:
    source_meta = source_profile(article.get('feed_name') or '', article.get('feed_url') or '', article.get('article_url') or '')
    relevance = float(article.get('hybrid_score') or article.get('relevance_score') or 0.0)
    priority = relevance
    priority += max(0.0, float(source_meta.get('bonus') or 0.0))
    if source_meta.get('specialist_signal'):
        priority += 0.12
    if source_meta.get('is_feedly'):
        priority += 0.09
    if source_meta.get('is_google_aggregator'):
        priority -= 0.08
    if article.get('image_url'):
        priority += 0.01
    return round(priority, 4)


def source_profile(feed_name: str = '', feed_url: str = '', article_url: str = '') -> dict[str, Any]:
    feed_blob = normalize_spaces(' '.join([feed_name or '', feed_url or '']))
    article_bonus = get_domain_score(article_url)
    feed_bonus = get_domain_score(feed_url)
    feed_blob_lower = feed_blob.lower()
    is_feedly = 'feedly.com' in (feed_url or '').lower() or 'feedly' in feed_blob_lower
    is_google_aggregator = 'news.google.com' in (feed_url or '').lower() or any(phrase_in_text(feed_blob, term) for term in GENERIC_AGGREGATOR_HINTS)
    specialist_signal = any(phrase_in_text(feed_blob, term) for term in SPECIALIST_SOURCE_HINTS) or article_bonus >= 0.13

    bonus = max(article_bonus, feed_bonus)
    if is_feedly and specialist_signal:
        bonus += 0.10
    elif is_feedly:
        bonus += 0.05
    if specialist_signal:
        bonus += 0.05
    if is_google_aggregator:
        bonus -= 0.08
    bonus = round(max(-0.14, min(bonus, 0.34)), 4)

    return {
        'bonus': bonus,
        'is_feedly': is_feedly,
        'is_google_aggregator': is_google_aggregator,
        'specialist_signal': specialist_signal,
        'article_domain_bonus': article_bonus,
    }


def extract_tags_from_text(article_blob: str) -> list[str]:
    tags: list[str] = []
    for canonical, meta in CONCEPT_LEXICON.items():
        if any(phrase_in_text(article_blob, alias) for alias in meta['aliases'] if len(alias) > 2):
            tags.extend(meta.get('tags', []))
    for cve in CVE_RE.findall(article_blob):
        tags.append(cve.upper())
    for vendor in VENDORS:
        if phrase_in_text(article_blob, vendor):
            tags.append(vendor)
    return unique(tags)

def detect_sector_categories(title: str, summary: str, content: str, feed_name: str = '', feed_url: str = '', existing_tags: list[str] | None = None) -> tuple[list[str], list[str], list[str]]:
    primary_blob = normalize_spaces(' '.join([title or '', summary or '', content or '']))
    source_blob = normalize_spaces(' '.join([feed_name or '', feed_url or '']))
    blob = primary_blob
    title_summary_blob = normalize_spaces(' '.join([title or '', summary or '']))

    sector_terms = unique(MARCAS_RETAIL_TERMS + MARCAS_RETAIL_STRONG_TERMS_EXT)
    company_terms = unique(MARCAS_RETAIL_COMPANY_HINTS + MARCAS_RETAIL_COMPANY_HINTS_EXT)
    strong_sector_hits = [term for term in unique(MARCAS_RETAIL_STRONG_TERMS + MARCAS_RETAIL_STRONG_TERMS_EXT) if phrase_in_text(blob, term)]
    generic_sector_hits = [term for term in unique(MARCAS_RETAIL_GENERIC_TERMS + ['brand', 'brands', 'shop', 'store', 'retail', 'b2b', 'b2c']) if phrase_in_text(blob, term)]
    company_hits = [term for term in company_terms if phrase_in_text(blob, term)]
    cyber_hits = [term for term in MARCAS_RETAIL_CYBER_TERMS if phrase_in_text(blob, term)]
    exclusion_hits = [term for term in MARCAS_RETAIL_EXCLUSION_TERMS if phrase_in_text(blob, term)]
    hard_false_hits = [term for term in BRAND_FALSE_POSITIVE_TERMS if phrase_in_text(title_summary_blob, term)]

    title_sector_hits = [term for term in sector_terms if phrase_in_text(title_summary_blob, term)]
    title_company_hits = [term for term in company_terms if phrase_in_text(title_summary_blob, term)]
    title_cyber_hits = [term for term in MARCAS_RETAIL_CYBER_TERMS if phrase_in_text(title_summary_blob, term)]

    tags_norm = {normalize_spaces(tag) for tag in (existing_tags or [])}
    cyber_tag_support = bool(tags_norm & {'malware', 'ransomware', 'phishing', 'incident', 'threatintel', 'vulnerability'})

    strong_sector_score = min(len(unique(strong_sector_hits)) * 0.44, 2.8)
    generic_sector_score = min(len(unique(generic_sector_hits)) * 0.24, 1.4)
    company_score = min(len(unique(company_hits)) * 1.25, 5.0)
    cyber_score = min(len(unique(cyber_hits)) * 0.42, 2.5) + (0.20 if cyber_tag_support else 0.0)
    exclusion_penalty = min(len(unique(exclusion_hits + hard_false_hits)) * 0.70, 2.4)

    feed_bias = 0.0
    if any(phrase_in_text(source_blob, term) for term in ('fashion cyber', 'moda ciber', 'mode cyber', 'retail cyber', 'retail payments and magecart', 'global fashion retail cyber')) and (title_sector_hits or title_company_hits or strong_sector_hits):
        feed_bias += 0.05
    if company_hits and cyber_hits:
        feed_bias += 0.10

    title_sector_bonus = 0.0
    if title_sector_hits:
        title_sector_bonus += 0.24
    if title_company_hits:
        title_sector_bonus += 0.32
    if title_cyber_hits:
        title_sector_bonus += 0.22

    retail_context = strong_sector_score + generic_sector_score + company_score + title_sector_bonus + feed_bias
    total_score = retail_context + cyber_score - exclusion_penalty

    has_brand_or_retail_context = bool(title_company_hits or company_hits) or len(unique(title_sector_hits or strong_sector_hits)) >= 1 or len(unique(generic_sector_hits)) >= 2
    has_real_cyber_context = bool(title_cyber_hits or cyber_hits) or cyber_tag_support
    source_only_signal = not bool(title_company_hits or title_sector_hits or company_hits or strong_sector_hits or len(unique(generic_sector_hits)) >= 2)

    categories: list[str] = []
    extra_tags: list[str] = []
    reasons: list[str] = []

    if company_hits:
        reasons.append(f"Marca/retailer detectado: {', '.join(unique(company_hits)[:4])}")
    if strong_sector_hits or generic_sector_hits:
        reasons.append(f"Contexto retail/fashion: {', '.join(unique((title_sector_hits + strong_sector_hits + generic_sector_hits))[:5])}")
    if cyber_hits or title_cyber_hits:
        reasons.append(f"Contexto ciber: {', '.join(unique(title_cyber_hits + cyber_hits)[:4])}")
    elif cyber_tag_support:
        reasons.append('Contexto ciber inferido por tags técnicas')
    if exclusion_hits or hard_false_hits:
        reasons.append(f"Penalización sector ajeno: {', '.join(unique(exclusion_hits + hard_false_hits)[:4])}")

    include_marcas = False
    if has_brand_or_retail_context and has_real_cyber_context and not source_only_signal and not hard_false_hits:
        if title_company_hits and title_cyber_hits and total_score >= 0.30:
            include_marcas = True
        elif company_hits and cyber_hits and total_score >= 0.42:
            include_marcas = True
        elif len(unique(strong_sector_hits)) >= 1 and len(unique(cyber_hits)) >= 1 and total_score >= 0.50:
            include_marcas = True
        elif len(unique(generic_sector_hits)) >= 2 and len(unique(cyber_hits)) >= 1 and total_score >= 0.62:
            include_marcas = True

    if include_marcas:
        categories.append('marcas_retail')
        extra_tags.extend(['Marcas', 'Retail/Fashion'])
        print(f"[CyberRad][Marcas] INCLUDE title={title[:90]!r} score={total_score:.2f} retail={retail_context:.2f} cyber={cyber_score:.2f} penalty={exclusion_penalty:.2f}")
    elif has_brand_or_retail_context or cyber_hits or exclusion_hits or hard_false_hits:
        print(f"[CyberRad][Marcas] EXCLUDE title={title[:90]!r} score={total_score:.2f} retail={retail_context:.2f} cyber={cyber_score:.2f} penalty={exclusion_penalty:.2f} reasons={'; '.join(reasons[:3])}")

    return unique(categories), unique(extra_tags), reasons


def title_cluster_key(title: str) -> str:
    cleaned = CVE_RE.sub(' ', title or '')
    tokens = [t for t in normalize_tokens(cleaned) if len(t) > 2][:10]
    if not tokens:
        return hashlib.sha1((title or '').encode('utf-8', errors='ignore')).hexdigest()[:20]
    return '-'.join(tokens)


def variant_score(variant: str, title: str, summary: str, content: str, concept: dict[str, Any]) -> tuple[float, str | None]:
    variant_norm = normalize_spaces(variant)
    if not variant_norm:
        return 0.0, None
    blob = ' '.join([title, summary, content])
    canonical = concept.get('canonical')
    meta = CONCEPT_LEXICON.get(canonical or '', {})
    ambiguous_aliases = set(meta.get('ambiguous_aliases', set()))
    if variant_norm in ambiguous_aliases:
        direct_ok = phrase_in_text(blob, meta.get('label', ''))
        context_ok = any(phrase_in_text(blob, ctx) for ctx in meta.get('context', []))
        if not direct_ok and not context_ok:
            return 0.0, None
    if phrase_in_text(title, variant_norm):
        return 1.0, f"Coincidencia en título con '{variant_norm}'"
    if phrase_in_text(summary, variant_norm):
        return 0.84, f"Coincidencia en resumen con '{variant_norm}'"
    if phrase_in_text(content, variant_norm):
        return 0.62, f"Coincidencia en contenido con '{variant_norm}'"
    variant_tokens = normalize_tokens(variant_norm)
    if len(variant_tokens) >= 2:
        title_tokens = token_set(title)
        summary_tokens = token_set(summary)
        content_tokens = token_set(content)
        title_overlap = len(set(variant_tokens) & title_tokens) / len(set(variant_tokens))
        summary_overlap = len(set(variant_tokens) & summary_tokens) / len(set(variant_tokens))
        content_overlap = len(set(variant_tokens) & content_tokens) / len(set(variant_tokens))
        score = max(title_overlap * 0.86, summary_overlap * 0.70, content_overlap * 0.50)
        if score >= 0.38:
            return score, f"Coincidencia parcial con '{variant_norm}'"
    return 0.0, None


def score_concept(concept: dict[str, Any], title: str, summary: str, content: str) -> tuple[float, str]:
    best_score = 0.0
    best_reason = f"Sin coincidencia clara para '{concept['label']}'"
    for variant in concept['variants']:
        score, reason = variant_score(variant, title, summary, content, concept)
        if score > best_score and reason:
            best_score = score
            best_reason = reason
    return round(min(best_score, 1.0), 4), best_reason


def recency_boost(published_at: str | None) -> tuple[float, str | None]:
    dt = parse_datetime_to_dt(published_at)
    days_old = max((datetime.now(tz=timezone.utc) - dt).total_seconds() / 86400, 0)
    if days_old <= 1:
        return 0.08, 'Muy reciente'
    if days_old <= 3:
        return 0.06, 'Reciente (3d)'
    if days_old <= 7:
        return 0.04, 'Reciente (7d)'
    if days_old <= 15:
        return 0.02, 'Reciente (15d)'
    return 0.0, None


def score_against_prompt(prompt: str, title: str, summary: str, content: str, feed_name: str = '', feed_url: str = '', article_url: str = '', published_at: str | None = None, relevance_mode: str = 'balanced') -> tuple[float, str, list[str], str]:
    parsed = parse_prompt(prompt)
    if not parsed['raw']:
        return 0.0, 'Sin prompt activo; la noticia queda pendiente para revisión manual.', [], title_cluster_key(title)
    article_blob = normalize_spaces(' '.join([title or '', summary or '', content or '', feed_name or '', feed_url or '']))
    extracted_tags = extract_tags_from_text(article_blob)
    negative_hits = [term for term in parsed['exclude_terms'] if term and phrase_in_text(article_blob, term)]
    negative_context = strong_negative_context_reasons(title, summary, content)
    if negative_context:
        return 0.0, f"Excluida por contexto no ciber: {' | '.join(negative_context[:2])}.", extracted_tags[:8], title_cluster_key(title)
    non_cyber_reasons = non_cyber_context_reasons(title, summary, content, feed_name=feed_name, feed_url=feed_url)
    if non_cyber_reasons:
        return 0.0, '. '.join(non_cyber_reasons) + '.', extracted_tags[:8], title_cluster_key(title)

    cyber_signal_score, cyber_signal_reasons, ambiguous_hits = cyber_signal_profile(title, summary, content)
    source_meta = source_profile(feed_name, feed_url, article_url)
    source_bonus = source_meta['bonus']
    if cyber_signal_score < 0.22:
        if ambiguous_hits:
            return 0.0, f"Excluida: términos ambiguos sin evidencia ciber suficiente ({', '.join(ambiguous_hits[:4])}).", extracted_tags[:8], title_cluster_key(title)
        return 0.0, 'Excluida: evidencia ciber insuficiente en título/resumen/contenido.', extracted_tags[:8], title_cluster_key(title)

    concept_hits: list[tuple[float, str, str]] = []
    for concept in parsed['concepts']:
        score, reason = score_concept(concept, title or '', summary or '', content or '')
        if score > 0:
            concept_hits.append((score, reason, concept['label']))

    recency_score, recency_label = recency_boost(published_at)
    severity_bonus = 0.0
    severity_labels: list[str] = []
    for term, bonus in SEVERITY_TERMS.items():
        if phrase_in_text(article_blob, term):
            severity_bonus = max(severity_bonus, bonus)
            severity_labels.append(term)
    if 'cve' in {c['canonical'] for c in parsed['concepts'] if c.get('canonical')} and any(tag.startswith('CVE-') for tag in extracted_tags):
        severity_bonus += 0.05
    for noise in NOISE_PATTERNS:
        if phrase_in_text(article_blob, noise):
            severity_bonus -= 0.08
            break
    if not concept_hits:
        if negative_hits:
            return 0.0, f"Excluida por términos negativos del prompt: {', '.join(negative_hits[:4])}.", extracted_tags[:8], title_cluster_key(title)
        return 0.0, 'No se detectaron coincidencias suficientemente claras con el prompt.', extracted_tags[:8], title_cluster_key(title)

    concept_hits.sort(key=lambda item: item[0], reverse=True)
    best_score, best_reason, best_label = concept_hits[0]
    support_bonus = min(sum(score for score, _, _ in concept_hits[1:]) * 0.12, 0.18)
    diversity_bonus = 0.05 if len(concept_hits) >= 2 else 0.0
    final_score = best_score + support_bonus + diversity_bonus + source_bonus + recency_score + severity_bonus
    final_score += min(cyber_signal_score * 0.22, 0.16)
    if source_meta['is_google_aggregator'] and (best_score < 0.78 or cyber_signal_score < 0.40) and len(concept_hits) < 2:
        final_score -= 0.14
    if source_meta['is_feedly'] and source_meta['specialist_signal'] and cyber_signal_score >= 0.34 and best_score >= 0.38:
        final_score += 0.10
    if negative_hits:
        final_score -= 0.45
    if relevance_mode == 'flexible':
        final_score += 0.03
    elif relevance_mode == 'strict':
        final_score -= 0.05
    if cyber_signal_score < 0.34 and not source_meta['specialist_signal']:
        final_score = min(final_score, 0.27)
    final_score = round(max(0.0, min(final_score, 1.0)), 4)

    reasons = [best_reason, f"Tema principal: {best_label}"]
    reasons.extend(cyber_signal_reasons[:2])
    if len(concept_hits) >= 2:
        reasons.append('Soporte adicional de otros términos del prompt')
    if source_meta['is_feedly'] and source_meta['specialist_signal']:
        reasons.append('Feedly / fuente especializada reforzada')
    elif source_bonus > 0:
        reasons.append('Fuente prioritaria / especializada')
    elif source_meta['is_google_aggregator']:
        reasons.append('Agregador general penalizado frente a fuentes más especializadas')
    if recency_label:
        reasons.append(recency_label)
    if severity_labels:
        reasons.append(f"Severidad detectada: {', '.join(unique(severity_labels)[:3])}")
    if negative_hits:
        reasons.append(f"Penalizada por: {', '.join(negative_hits[:3])}")
    matched_labels = [label for _, _, label in concept_hits[:4]]
    tags = unique(matched_labels + extracted_tags)[:10]
    rationale = '. '.join(reasons) + f". Score {final_score:.2f}."
    return final_score, rationale, tags, title_cluster_key(title)


def thresholds_for_mode(relevance_mode: str) -> tuple[float, float]:
    if relevance_mode == 'flexible':
        return 0.42, 0.20
    if relevance_mode == 'strict':
        return 0.68, 0.36
    return 0.55, 0.28


def classify_article(prompt: str, title: str, summary: str, content: str, published_at: str | None, date_window: str = 'all', relevance_mode: str = 'balanced', feed_name: str = '', feed_url: str = '', article_url: str = '') -> tuple[float, str, str, list[str], str]:
    score, rationale, tags, cluster_key = score_against_prompt(prompt, title, summary, content, feed_name=feed_name, feed_url=feed_url, article_url=article_url, published_at=published_at, relevance_mode=relevance_mode)
    include_threshold, pending_threshold = thresholds_for_mode(relevance_mode)
    if not prompt.strip():
        status = 'pending'
    elif score >= include_threshold:
        status = 'included'
    elif score >= pending_threshold:
        status = 'pending'
    else:
        status = 'excluded'
    if not article_matches_date_window(published_at, date_window):
        status = 'excluded'
        rationale = f"Excluida por fecha: fuera de la ventana temporal '{date_window}'. " + rationale
    return score, status, rationale, tags, cluster_key


def local_name(tag: str) -> str:
    return tag.split('}', 1)[-1].lower()


def child_text(node: ET.Element, *names: str) -> str:
    wanted = {name.lower() for name in names}
    for child in list(node):
        if local_name(child.tag) in wanted and (child.text or '').strip():
            return child.text.strip()
    return ''


def first_link(node: ET.Element) -> str | None:
    for child in list(node):
        if local_name(child.tag) != 'link':
            continue
        href = child.attrib.get('href') or (child.text or '').strip()
        rel = child.attrib.get('rel', 'alternate')
        if href and rel in {'alternate', '', 'self'}:
            return href
    return None


def entry_media_xml(node: ET.Element) -> tuple[str | None, str | None]:
    image_url = None
    video_url = None
    for child in node.iter():
        tag = local_name(child.tag)
        if tag in {'content', 'thumbnail', 'enclosure'}:
            url = child.attrib.get('url') or child.attrib.get('href')
            type_ = (child.attrib.get('type') or '').lower()
            if url and not image_url and ('image' in type_ or url.lower().endswith(('.jpg', '.jpeg', '.png', '.webp', '.gif'))):
                image_url = url
            if url and not video_url and ('video' in type_ or 'youtube.com' in url or 'youtu.be' in url or 'vimeo.com' in url):
                video_url = url
    return image_url, video_url


def entry_media_json(item: dict[str, Any]) -> tuple[str | None, str | None]:
    image_url = normalize_media_url(item.get('image') or item.get('banner_image'))
    video_url = None
    attachments = item.get('attachments') or []
    if isinstance(attachments, list):
        for attachment in attachments:
            if not isinstance(attachment, dict):
                continue
            url = normalize_media_url(attachment.get('url'))
            mime = (attachment.get('mime_type') or attachment.get('type') or '').lower()
            if url and not image_url and (('image' in mime) or media_url_looks_real(url)):
                image_url = url
            if url and not video_url and ('video' in mime or 'youtube.com' in url or 'youtu.be' in url or 'vimeo.com' in url):
                video_url = url
    if not image_url:
        for key in ('content_html', 'content_text', 'summary', 'summary_html'):
            image_url = extract_image_from_html_fragment(item.get(key), item.get('url') or item.get('external_url'))
            if image_url:
                break
    if not video_url:
        for key in ('external_url', 'url'):
            candidate = item.get(key)
            if isinstance(candidate, str) and any(x in candidate for x in ('youtube.com', 'youtu.be', 'vimeo.com')):
                video_url = candidate
                break
    return image_url, video_url


def enrich_from_article(url: str) -> tuple[str | None, str | None]:
    if not url:
        return None, None
    lowered = url.lower()
    if lowered.endswith(('.xml', '.rss', '.rdf', '.json', '.atom')):
        return None, None
    try:
        response = requests.get(url, headers=HEADERS, timeout=6, allow_redirects=True)
        response.raise_for_status()
    except Exception:
        return None, None
    content_type = (response.headers.get('content-type') or '').lower()
    if any(kind in content_type for kind in ('xml', 'rss', 'json', 'atom')):
        return None, None
    final_url = response.url or url
    soup = BeautifulSoup(response.text, 'html.parser')
    def meta_value(*keys: str) -> str | None:
        for key in keys:
            tag = soup.find('meta', attrs={'property': key}) or soup.find('meta', attrs={'name': key}) or soup.find('meta', attrs={'itemprop': key})
            if tag and tag.get('content'):
                value = normalize_media_url(tag['content'], final_url)
                if value and media_url_looks_real(value):
                    return value
        return None
    image = meta_value('og:image', 'og:image:url', 'twitter:image', 'twitter:image:src', 'image', 'parsely-image-url')
    if not image:
        link_tag = soup.find('link', attrs={'rel': 'image_src'})
        if link_tag and link_tag.get('href'):
            candidate = normalize_media_url(link_tag.get('href'), final_url)
            if candidate and media_url_looks_real(candidate):
                image = candidate
    if not image:
        image = extract_image_from_html_fragment(str(soup), final_url)
    video = meta_value('og:video', 'twitter:player')
    return image, video


def safe_feedly_url(article_url: str | None) -> str | None:
    return None


def parse_xml_items(xml_text: str) -> list[dict[str, Any]]:
    root = ET.fromstring(xml_text)
    root_name = local_name(root.tag)
    items: list[dict[str, Any]] = []
    if root_name == 'rss':
        channel = next((child for child in list(root) if local_name(child.tag) == 'channel'), root)
        for item in channel.findall('./*'):
            if local_name(item.tag) != 'item':
                continue
            items.append({'title': child_text(item, 'title'), 'link': child_text(item, 'link') or first_link(item), 'summary': child_text(item, 'description', 'summary'), 'content': child_text(item, 'encoded', 'content'), 'published': child_text(item, 'pubdate', 'published', 'updated', 'date'), 'id': child_text(item, 'guid', 'id'), 'xml_node': item})
        return items
    if root_name == 'feed':
        for entry in root.findall('./*'):
            if local_name(entry.tag) != 'entry':
                continue
            items.append({'title': child_text(entry, 'title'), 'link': first_link(entry), 'summary': child_text(entry, 'summary'), 'content': child_text(entry, 'content'), 'published': child_text(entry, 'published', 'updated'), 'id': child_text(entry, 'id'), 'xml_node': entry})
        return items
    if root_name == 'rdf':
        for item in root.findall('./*'):
            if local_name(item.tag) != 'item':
                continue
            items.append({'title': child_text(item, 'title'), 'link': child_text(item, 'link') or first_link(item), 'summary': child_text(item, 'description', 'summary'), 'content': child_text(item, 'encoded', 'content'), 'published': child_text(item, 'date', 'pubdate', 'published', 'updated'), 'id': child_text(item, 'guid', 'id'), 'xml_node': item})
        return items
    return items


def parse_json_items(text: str) -> list[dict[str, Any]]:
    payload = json.loads(text)
    if not isinstance(payload, dict):
        return []
    items: list[dict[str, Any]] = []
    for item in payload.get('items', []):
        if not isinstance(item, dict):
            continue
        image_url, video_url = entry_media_json(item)
        items.append({'title': item.get('title') or '', 'link': item.get('url') or item.get('external_url') or '', 'summary': item.get('summary') or item.get('content_text') or '', 'content': item.get('content_html') or item.get('content_text') or item.get('summary') or '', 'published': item.get('date_published') or item.get('date_modified') or '', 'id': item.get('id') or item.get('url') or item.get('external_url') or '', 'image_url': image_url, 'video_url': video_url})
    return items


def parse_items(feed_text: str, content_type: str = '') -> list[dict[str, Any]]:
    stripped = (feed_text or '').lstrip()
    is_json = 'json' in (content_type or '').lower() or stripped.startswith('{')
    if is_json:
        return parse_json_items(feed_text)
    return parse_xml_items(feed_text)


def parse_feed(feed: dict[str, Any], prompt: str, max_articles: int = 20, date_window: str = 'all', relevance_mode: str = 'balanced') -> list[dict[str, Any]]:
    response = requests.get(feed['url'], headers=HEADERS, timeout=15)
    response.raise_for_status()
    parsed_entries = parse_items(response.text, response.headers.get('content-type', ''))
    if max_articles and int(max_articles) > 0:
        parsed_entries = parsed_entries[:int(max_articles)]
    articles: list[dict[str, Any]] = []
    for entry in parsed_entries:
        title = clean_html(entry.get('title'))
        article_url = entry.get('link') or feed['url']
        summary = clean_html(entry.get('summary'))
        content_text = clean_html(entry.get('content'))
        published_at = parse_datetime(entry.get('published'))
        image_url = entry.get('image_url')
        video_url = entry.get('video_url')
        if entry.get('xml_node') is not None:
            xml_image, xml_video = entry_media_xml(entry['xml_node'])
            image_url = image_url or xml_image
            video_url = video_url or xml_video
        image_url = image_url or extract_image_from_html_fragment(entry.get('content'), article_url) or extract_image_from_html_fragment(entry.get('summary'), article_url)
        image_url = normalize_media_url(image_url, article_url)
        if image_url and not media_url_looks_real(image_url):
            image_url = None
        if not image_url and article_url:
            fetched_image, fetched_video = enrich_from_article(article_url)
            image_url = image_url or fetched_image
            video_url = video_url or fetched_video
        score, status, rationale, tags, cluster_key = classify_article(prompt, title, summary, content_text, published_at, date_window=date_window, relevance_mode=relevance_mode, feed_name=feed.get('name', ''), feed_url=feed.get('url', ''), article_url=article_url)
        decision = status.upper()
        short_reason = (rationale or '').split('. ')[0][:180]
        print(f"[CyberRad][Classify] {decision} title={title[:100]!r} feed={str(feed.get('name') or '')[:40]!r} reason={short_reason!r} score={score:.2f}")
        unique_source = entry.get('id') or article_url or f"{feed['url']}::{title}"
        unique_key = hashlib.sha256(unique_source.encode('utf-8', errors='ignore')).hexdigest()
        articles.append({'unique_key': unique_key, 'feed_id': feed.get('id'), 'feed_name': feed.get('name'), 'feed_url': feed.get('url'), 'title': title or '(Sin título)', 'article_url': article_url, 'feedly_url': safe_feedly_url(article_url), 'summary': summary, 'content': content_text, 'published_at': published_at, 'image_url': image_url, 'video_url': video_url, 'status': status, 'status_origin': 'auto', 'relevance_score': score, 'rationale': rationale, 'match_tags': json.dumps(tags, ensure_ascii=False), 'cluster_key': cluster_key})
    return articles

const statsEl = document.getElementById('stats');
const feedsListEl = document.getElementById('feedsList');
const articlesContainer = document.getElementById('articlesContainer');
const dialog = document.getElementById('articleDialog');
const dialogContent = document.getElementById('articleDialogContent');
const promptInput = document.getElementById('promptInput');
const promptSaveStatusEl = document.getElementById('promptSaveStatus');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const runtimeProfileInput = document.getElementById('runtimeProfileInput');
const runtimeProfileHint = document.getElementById('runtimeProfileHint');
const intervalInput = document.getElementById('intervalInput');
const maxArticlesInput = document.getElementById('maxArticlesInput');
const autoRefreshInput = document.getElementById('autoRefreshInput');
const dateWindowInput = document.getElementById('dateWindowInput');
const relevanceModeInput = document.getElementById('relevanceModeInput');
const hideDuplicatesInput = document.getElementById('hideDuplicatesInput');
const mapSectionTitle = document.getElementById('mapSectionTitle');
const mapSectionDescription = document.getElementById('mapSectionDescription');
const mapMethodology = document.getElementById('mapMethodology');
const brandsMapYearSelect = document.getElementById('brandsMapYearSelect');
const brandsMapDownloadBtn = document.getElementById('brandsMapDownloadBtn');
const brandsMapStats = document.getElementById('brandsMapStats');
const brandsMapCanvas = document.getElementById('brandsMapCanvas');
const brandsMapTopCountries = document.getElementById('brandsMapTopCountries');
const brandsMapTopAttacks = document.getElementById('brandsMapTopAttacks');
const brandsMapIncidents = document.getElementById('brandsMapIncidents');
const mapIncidentsTitle = document.getElementById('mapIncidentsTitle');
const screenLoader = document.getElementById('screenLoader');
const screenLoaderText = document.getElementById('screenLoaderText');

const PROMPT_DRAFT_KEY = 'cyberrad_prompt_draft_v50';
const CURRENT_MAP_YEAR = String(new Date().getFullYear());
let currentStatus = 'all';
let currentSector = 'general';
let knownArticleIds = new Set();
let lastServerPrompt = '';
let promptDirty = false;
let autosaveTimer = null;
let saveInFlight = false;
let currentMapData = null;
let currentMapDataBySector = { general: null, marcas_retail: null };
let mapYearBySector = { general: CURRENT_MAP_YEAR, marcas_retail: CURRENT_MAP_YEAR };
let currentMapYear = preferredMapYearForSector(currentSector);
let currentStateSnapshot = null;
let asyncWorkWasRunning = false;
let dashboardReloadTimer = null;
let backgroundRefreshInFlight = false;
let lastStatsSignature = "";
const AUTO_RELOAD_MS = 600000;
const STATE_POLL_MS = 180000;
const STATE_CACHE_MS = 20000;
const UI_CACHE_TTL_MS = 45000;
let mapRequestSeq = 0;
let articlesRequestSeq = 0;
let lastRenderedMapSignature = '';
let mapLoaderVisible = false;
let mapLoaderShownAt = 0;
const MAP_BASE_IMAGE_URL = '/static/world-outline.svg';
const MAP_MIN_LOADER_MS = 520;
let mapBaseImageReadyPromise = null;
let bootstrappedContent = false;
let stateFetchPromise = null;
let stateFetchMode = "full";
let lastStateLoadedAt = 0;
let statePollInFlight = false;
let currentMapInteractionController = null;
let mapFetchController = null;
let articlesFetchController = null;
let countryFetchController = null;
const articlesResponseCache = new Map();
const mapResponseCache = new Map();


async function api(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', headers: { 'Content-Type': 'application/json' }, ...options });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(detail || 'Error en la petición');
  }
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function escapeHtml(value = '') {
  return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}
function escapeAttribute(value = '') { return escapeHtml(value); }

function currentImageProfile() {
  return runtimeProfileInput?.value || currentStateSnapshot?.settings?.runtime_profile || 'low_resource';
}

function proxiedImageUrl(url = '') {
  const value = String(url || '').trim();
  if (!value) return '';
  return `/api/image-proxy?url=${encodeURIComponent(value)}&profile=${encodeURIComponent(currentImageProfile())}`;
}

function articleImageMarkup(article, className = 'article-image') {
  const rawUrl = String(article?.image_url || '').trim();
  const sourceLabel = escapeHtml(article?.feed_name || 'CyberRad');
  const fallback = `
    <div class="article-image-fallback" aria-hidden="true">
      <span>${sourceLabel}</span>
      <small>Imagen no disponible</small>
    </div>
  `;
  if (!rawUrl) {
    return `<div class="article-image-shell no-image">${fallback}</div>`;
  }
  return `
    <div class="article-image-shell">
      <img class="${className}" src="${escapeAttribute(proxiedImageUrl(rawUrl))}" data-raw-src="${escapeAttribute(rawUrl)}" alt="${escapeAttribute(article?.title || 'Imagen de la noticia')}" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="handleArticleImageError(this)" />
      ${fallback}
    </div>
  `;
}

function isAutoRefreshEnabled() {
  return Boolean(currentStateSnapshot?.settings?.auto_refresh_enabled);
}

window.handleArticleImageError = function handleArticleImageError(img) {
  const shell = img?.closest('.article-image-shell');
  const rawSrc = img?.dataset?.rawSrc || '';
  if (img && rawSrc && !img.dataset.triedRaw) {
    img.dataset.triedRaw = '1';
    img.src = rawSrc;
    img.referrerPolicy = 'strict-origin-when-cross-origin';
    return;
  }
  if (shell) shell.classList.add('is-broken');
  if (img) img.remove();
};

function safeSetValue(element, value) {
  if (!element) return;
  element.value = value;
}

function safeSetChecked(element, checked) {
  if (!element) return;
  element.checked = Boolean(checked);
}

function preferredMapYearForSector(sector) {
  const sectorKey = sector === 'marcas_retail' ? 'marcas_retail' : 'general';
  return mapYearBySector[sectorKey] || CURRENT_MAP_YEAR;
}

function clearResponseCaches() {
  articlesResponseCache.clear();
  mapResponseCache.clear();
}

function readUiCache(store, key) {
  const entry = store.get(key);
  if (!entry) return null;
  if ((Date.now() - Number(entry.ts || 0)) > UI_CACHE_TTL_MS) {
    store.delete(key);
    return null;
  }
  return entry.data;
}

function writeUiCache(store, key, data) {
  if (store.size > 24) store.clear();
  store.set(key, { ts: Date.now(), data });
  return data;
}

function articlesCacheKey(sector = currentSector, status = currentStatus) {
  return `${sector}::${status}`;
}

function mapCacheKey(sector = currentSector, status = currentStatus, year = preferredMapYearForSector(sector)) {
  return `${sector}::${status}::${year || 'latest'}`;
}

function setBusy(active, message = 'Cargando…') {
  if (!screenLoader || !screenLoaderText) return;
  screenLoader.classList.toggle('hidden', !active);
  screenLoaderText.textContent = message;
}

function setPromptStatus(message, tone = 'muted') {
  if (!promptSaveStatusEl) return;
  promptSaveStatusEl.textContent = message;
  promptSaveStatusEl.className = `save-status ${tone}`;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function preloadMapBaseImage() {
  if (mapBaseImageReadyPromise) return mapBaseImageReadyPromise;
  mapBaseImageReadyPromise = new Promise(resolve => {
    const img = new Image();
    img.decoding = 'async';
    img.loading = 'eager';
    img.onload = () => resolve(true);
    img.onerror = () => resolve(false);
    img.src = MAP_BASE_IMAGE_URL;
    if (img.complete) resolve(true);
  });
  return mapBaseImageReadyPromise;
}

function ensureMapShell(message = 'Radar cargando incidencias…') {
  const current = brandsMapCanvas?.querySelector('.map-backdrop');
  if (current) return;
  brandsMapCanvas.innerHTML = `
    <div class="map-backdrop clean-map map-backdrop-loading">
      <div class="map-panzoom">
        <div class="map-surface">
          <img class="map-base-image" src="${MAP_BASE_IMAGE_URL}" alt="Mapa mundial" draggable="false" loading="eager" decoding="async" />
        </div>
      </div>
      <div class="map-hint">Rueda para zoom · Arrastra para mover · Doble clic para centrar</div>
    </div>
  `;
  ensureMapLoader(message);
}

function persistPromptDraft(value) {
  try {
    if (value && value !== lastServerPrompt) localStorage.setItem(PROMPT_DRAFT_KEY, value);
    else localStorage.removeItem(PROMPT_DRAFT_KEY);
  } catch (error) {}
}

function loadLocalPromptDraft() {
  try { return localStorage.getItem(PROMPT_DRAFT_KEY) || ''; } catch (error) { return ''; }
}

function formatDate(value) {
  if (!value) return 'Sin fecha';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('es-ES');
}

function renderStats(stats, feedback = {}) {
  const activeFeeds = Number(stats.active_feed_count || 0);
  const totalFeeds = Number(stats.feed_count || 0);
  statsEl.innerHTML = `
    <div class="stat-box"><span>Total</span><strong>${stats.total_articles}</strong></div>
    <div class="stat-box"><span>Feeds activos</span><strong>${activeFeeds}</strong><small>${totalFeeds} disponibles</small></div>
    <div class="stat-box"><span>Incluidas</span><strong>${stats.included_count}</strong></div>
    <div class="stat-box"><span>Pendientes</span><strong>${stats.pending_count}</strong></div>
    <div class="stat-box"><span>Excluidas</span><strong>${stats.excluded_count}</strong></div>
    <div class="stat-box"><span>Feedback</span><strong>${feedback.feedback_events || 0}</strong></div>
  `;
}

function applySettingsToForm(settings) {
  const focusedElement = document.activeElement;
  const serverPrompt = settings.prompt || '';
  if (promptInput && !promptDirty && focusedElement !== promptInput) {
    safeSetValue(promptInput, serverPrompt);
    lastServerPrompt = serverPrompt;
    persistPromptDraft('');
  }
  if (runtimeProfileInput && focusedElement !== runtimeProfileInput) safeSetValue(runtimeProfileInput, settings.runtime_profile || 'low_resource');
  if (intervalInput && focusedElement !== intervalInput) safeSetValue(intervalInput, Number(settings.poll_interval_seconds || 300));
  if (maxArticlesInput && focusedElement !== maxArticlesInput) safeSetValue(maxArticlesInput, Number(settings.max_articles_per_feed || 0));
  if (dateWindowInput && focusedElement !== dateWindowInput) safeSetValue(dateWindowInput, settings.date_window || 'all');
  if (relevanceModeInput && focusedElement !== relevanceModeInput) safeSetValue(relevanceModeInput, settings.relevance_mode || 'balanced');
  safeSetChecked(autoRefreshInput, settings.auto_refresh_enabled);
  safeSetChecked(hideDuplicatesInput, settings.hide_duplicates);
  renderRuntimeProfileHint();
}


function renderRuntimeProfileHint() {
  if (!runtimeProfileHint) return;
  const selected = runtimeProfileInput?.value || currentStateSnapshot?.settings?.runtime_profile || 'low_resource';
  const profiles = currentStateSnapshot?.runtime_profiles || {};
  const profile = profiles[selected] || null;
  if (!profile) {
    runtimeProfileHint.textContent = 'Todos los perfiles mantienen todos los feeds activos. Low resource baja artículos por feed y comprime más las imágenes; Balanced equilibra; Full amplía volumen y calidad.';
    return;
  }
  const label = profile.label || selected;
  const count = Number(profile.enabled_feed_count || 0);
  const description = profile.description || '';
  const maxArticles = Number(profile.max_articles_per_feed || 0);
  const imageQuality = String(profile.image_quality_profile || selected);
  runtimeProfileHint.textContent = `${label}: ${description} (${count} feeds activos · ${maxArticles} artículos/feed · imagen ${imageQuality}).`;
}

function renderFeeds(feeds) {
  if (!feeds.length) {
    feedsListEl.innerHTML = '<p class="empty-state">Todavía no hay feeds.</p>';
    return;
  }
  feedsListEl.innerHTML = feeds.map(feed => `
    <div class="feed-row">
      <div>
        <strong>${escapeHtml(feed.name)}</strong>
        <div class="article-meta wrap-anywhere">${escapeHtml(feed.url)}</div>
      </div>
      <div class="feed-actions">
        <button class="secondary-btn" onclick="toggleFeed(${feed.id}, ${feed.is_enabled ? 'false' : 'true'})">${feed.is_enabled ? 'Pausar' : 'Activar'}</button>
        <button class="secondary-btn" onclick="removeFeed(${feed.id})">Borrar</button>
      </div>
    </div>
  `).join('');
}

function statusChip(status) {
  const labels = { included: 'Incluida', pending: 'Pendiente', excluded: 'Excluida' };
  return `<span class="status-chip status-${status}">${labels[status] || status}</span>`;
}

function renderTags(tags = []) {
  if (!Array.isArray(tags) || !tags.length) return '';
  return `<div class="tag-row">${tags.slice(0, 6).map(tag => `<span class="tag-chip">${escapeHtml(tag)}</span>`).join('')}</div>`;
}

function sectorMeta(article) {
  return article.display_sector === 'marcas_retail' ? '<span class="sector-chip">Marcas</span>' : '<span class="sector-chip general-chip">General</span>';
}

function renderArticlesSkeleton(count = 6) {
  articlesContainer.innerHTML = Array.from({ length: count }).map(() => `
    <article class="article-card article-card-skeleton">
      <div class="article-image skeleton-box"></div>
      <div class="article-body">
        <div class="article-meta card-topline"><span class="skeleton-line short"></span><span class="skeleton-line short"></span></div>
        <div class="skeleton-line title"></div>
        <div class="skeleton-line"></div>
        <div class="skeleton-line"></div>
        <div class="skeleton-line short"></div>
      </div>
    </article>
  `).join('');
}

function renderArticles(articles) {
  if (!articles.length) {
    articlesContainer.innerHTML = '<div class="card empty-state">No hay noticias para este filtro.</div>';
    return;
  }
  const newIds = new Set(articles.map(a => a.id));
  articlesContainer.innerHTML = articles.map(article => {
    const isNew = !knownArticleIds.has(article.id);
    return `
      <article class="article-card ${isNew ? 'slide-in' : ''}">
        ${articleImageMarkup(article)}
        <div class="article-body">
          <div class="article-meta card-topline">
            <span>${escapeHtml(article.feed_name || 'Feed')}</span>
            ${sectorMeta(article)}
            <span>Híbrido ${Number(article.relevance_score || 0).toFixed(2)} · Sem ${Number(article.semantic_score || 0).toFixed(2)}</span>
          </div>
          <h3 class="article-title">${escapeHtml(article.title)}</h3>
          <p class="article-summary">${escapeHtml((article.summary || article.content || '').slice(0, 240))}</p>
          ${renderTags(article.match_tags)}
          <p class="article-rationale">${escapeHtml((article.rationale || 'Sin explicación').slice(0, 180))}</p>
          <div class="article-meta">
            <span>${formatDate(article.published_at || article.created_at)}</span>
            ${statusChip(article.status)}
          </div>
          <div class="status-actions">
            <button onclick="setArticleStatus(${article.id}, 'included')">Incluir</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'pending')">Pendiente</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'excluded')">Excluir</button>
            <button class="secondary-btn" onclick="showArticle(${article.id})">Ver</button>
          </div>
        </div>
      </article>
    `;
  }).join('');
  knownArticleIds = newIds;
}

function mapPointSize(count, maxCount) {
  return 10 + Math.round(8 * Math.sqrt((count || 1) / (maxCount || 1)));
}

function renderMapStats(totals = {}, yearLabel = 'Último con datos') {
  brandsMapStats.innerHTML = `
    <div class="stat-box"><span>Noticias</span><strong>${Number(totals.all_articles || 0)}</strong><small>Incl ${Number(totals.included || 0)} · Pend ${Number(totals.pending || 0)} · Excl ${Number(totals.excluded || 0)}</small></div>
    <div class="stat-box"><span>Países</span><strong>${Number(totals.countries || 0)}</strong><small>Con punto en mapa</small></div>
    <div class="stat-box"><span>En mapa</span><strong>${Number(totals.mapped_articles || 0)}</strong><small>Con país detectado</small></div>
    <div class="stat-box"><span>Ventana</span><strong>${escapeHtml(yearLabel)}</strong><small>Filtro actual</small></div>
  `;
}

function renderList(el, items, formatter, empty = 'Sin datos todavía.') {
  if (!items || !items.length) {
    el.innerHTML = `<div class="empty-mini wide">${escapeHtml(empty)}</div>`;
    return;
  }
  el.innerHTML = items.map(formatter).join('');
}

function mapLoaderMarkup(message = 'Radar cargando incidencias…') {
  return `
    <div class="map-loader-overlay" data-map-loader="true" aria-live="polite">
      <div class="radar-loader" aria-hidden="true">
        <div class="radar-ring radar-ring-a"></div>
        <div class="radar-ring radar-ring-b"></div>
        <div class="radar-ring radar-ring-c"></div>
        <div class="radar-sweep"></div>
        <div class="radar-cross radar-cross-x"></div>
        <div class="radar-cross radar-cross-y"></div>
        <span class="radar-blip radar-blip-a"></span>
        <span class="radar-blip radar-blip-b"></span>
        <span class="radar-blip radar-blip-c"></span>
        <span class="radar-core"></span>
      </div>
      <div class="map-loader-copy">
        <strong>Escaneando mapa…</strong>
        <span>${escapeHtml(message)}</span>
      </div>
    </div>
  `;
}

function ensureMapLoader(message = 'Radar cargando incidencias…') {
  let overlay = brandsMapCanvas.querySelector('[data-map-loader="true"]');
  if (!overlay) {
    const backdrop = brandsMapCanvas.querySelector('.map-backdrop');
    if (backdrop) {
      backdrop.insertAdjacentHTML('beforeend', mapLoaderMarkup(message));
      overlay = brandsMapCanvas.querySelector('[data-map-loader="true"]');
    } else {
      ensureMapShell(message);
      overlay = brandsMapCanvas.querySelector('[data-map-loader="true"]');
    }
  }
  if (overlay) {
    overlay.classList.remove('hidden');
    const copy = overlay.querySelector('.map-loader-copy span');
    if (copy) copy.textContent = message;
  }
  mapLoaderVisible = true;
  mapLoaderShownAt = Date.now();
}

function hideMapLoader() {
  brandsMapCanvas.querySelectorAll('[data-map-loader="true"]').forEach(node => node.classList.add('hidden'));
  mapLoaderVisible = false;
}

function renderMapLoading(message = 'Radar cargando incidencias…') {
  ensureMapLoader(message);
}

function buildMapMarkup(data) {
  const points = Array.isArray(data.points) ? data.points : [];
  const maxCount = Math.max(...points.map(point => point.count || 0), 1);
  const markers = points.map(point => {
    const size = mapPointSize(point.count, maxCount);
    return `
      <button class="map-marker" style="left:${point.x_pct}%; top:${point.y_pct}%; width:${size}px; height:${size}px;" data-country="${escapeAttribute(point.country)}" data-article-ids="${escapeAttribute((point.article_ids || []).join(','))}" data-tooltip="${escapeAttribute(JSON.stringify(point))}" aria-label="${escapeAttribute(point.country)} ${point.count} incidentes">
        <span>${point.count}</span>
      </button>
    `;
  }).join('');
  const empty = !Number((data.totals || {}).incidents || 0) ? '<div class="map-overlay-empty">No hay datos suficientes para pintar el mapa todavía.</div>' : '';
  return `
    <div class="map-backdrop clean-map">
      <div class="map-panzoom" id="mapPanzoom">
        <div class="map-surface" id="mapSurface">
          <img class="map-base-image" src="${escapeAttribute(data.map_base_image || MAP_BASE_IMAGE_URL)}" alt="Mapa mundial" draggable="false" loading="eager" decoding="async" />
          <div class="map-layer">${markers}</div>
        </div>
      </div>
      <div class="map-hint">Rueda para zoom · Arrastra para mover · Doble clic para centrar</div>
      <div id="mapTooltip" class="map-tooltip hidden"></div>
      ${empty}
    </div>
  `;
}

function attachMapInteractions() {
  currentMapInteractionController?.abort();
  currentMapInteractionController = new AbortController();
  const { signal } = currentMapInteractionController;

  const stage = brandsMapCanvas.querySelector('.map-backdrop');
  const panzoom = brandsMapCanvas.querySelector('#mapPanzoom');
  const surface = brandsMapCanvas.querySelector('#mapSurface');
  const tooltip = brandsMapCanvas.querySelector('#mapTooltip');
  if (!stage || !panzoom || !surface || !tooltip) return;

  const state = { scale: 1, x: 0, y: 0, pointerId: null, dragging: false, startX: 0, startY: 0, downX: 0, downY: 0, moved: false, raf: 0 };

  const clampPan = () => {
    const rect = panzoom.getBoundingClientRect();
    const scaledWidth = rect.width * state.scale;
    const scaledHeight = rect.height * state.scale;
    const minX = Math.min(0, rect.width - scaledWidth);
    const minY = Math.min(0, rect.height - scaledHeight);
    state.x = Math.min(0, Math.max(minX, state.x));
    state.y = Math.min(0, Math.max(minY, state.y));
  };

  const applyTransformNow = () => {
    clampPan();
    surface.style.transform = `translate3d(${state.x.toFixed(2)}px, ${state.y.toFixed(2)}px, 0) scale(${state.scale.toFixed(4)})`;
    const markerCompScale = Math.min(1, Math.max(0.28, 1 / Math.pow(state.scale, 1.22)));
    surface.style.setProperty('--marker-comp-scale', markerCompScale.toFixed(4));
    surface.classList.add('is-ready');
    state.raf = 0;
  };

  const applyTransform = () => {
    if (state.raf) return;
    state.raf = requestAnimationFrame(applyTransformNow);
  };

  const resetView = () => {
    state.scale = 1;
    state.x = 0;
    state.y = 0;
    applyTransform();
  };

  const zoomAt = (clientX, clientY, delta) => {
    const rect = panzoom.getBoundingClientRect();
    const nextScale = Math.min(4.2, Math.max(1, state.scale * delta));
    if (nextScale === state.scale) return;
    const originX = clientX - rect.left;
    const originY = clientY - rect.top;
    const worldX = (originX - state.x) / state.scale;
    const worldY = (originY - state.y) / state.scale;
    state.scale = nextScale;
    state.x = originX - worldX * state.scale;
    state.y = originY - worldY * state.scale;
    applyTransform();
  };

  const stopDrag = event => {
    if (event?.pointerId != null && state.pointerId != null && event.pointerId !== state.pointerId) return;
    if (state.pointerId != null) {
      try { panzoom.releasePointerCapture?.(state.pointerId); } catch (error) {}
    }
    state.pointerId = null;
    state.dragging = false;
    panzoom.classList.remove('is-dragging');
  };

  applyTransform();

  surface.querySelectorAll('img').forEach(node => {
    node.draggable = false;
    node.ondragstart = event => event.preventDefault();
  });

  panzoom.onwheel = event => {
    event.preventDefault();
    const delta = event.deltaY < 0 ? 1.12 : 0.9;
    zoomAt(event.clientX, event.clientY, delta);
  };

  panzoom.onpointerdown = event => {
    if (event.button !== 0) return;
    event.preventDefault();
    state.pointerId = event.pointerId;
    state.dragging = true;
    state.moved = false;
    state.downX = event.clientX;
    state.downY = event.clientY;
    state.startX = event.clientX - state.x;
    state.startY = event.clientY - state.y;
    panzoom.setPointerCapture?.(event.pointerId);
    panzoom.classList.add('is-dragging');
    tooltip.classList.add('hidden');
  };

  panzoom.onpointermove = event => {
    if (!state.dragging || state.pointerId !== event.pointerId) return;
    state.x = event.clientX - state.startX;
    state.y = event.clientY - state.startY;
    const movedX = Math.abs(event.clientX - state.downX);
    const movedY = Math.abs(event.clientY - state.downY);
    state.moved = state.moved || movedX > 4 || movedY > 4;
    tooltip.classList.add('hidden');
    applyTransform();
  };

  panzoom.onpointerup = stopDrag;
  panzoom.onpointercancel = stopDrag;
  window.addEventListener('pointerup', stopDrag, { passive: true, signal });

  panzoom.ondblclick = event => {
    event.preventDefault();
    resetView();
  };

  const moveTooltip = (event, marker) => {
    const payload = JSON.parse(marker.dataset.tooltip || '{}');
    const labels = (payload.labels || []).slice(0, 4).join(', ') || payload.latest_label || 'Sin objetivo inferido';
    const attacks = (payload.attack_types || []).slice(0, 3).join(', ') || payload.latest_attack_type || 'Incidente ciber';
    tooltip.innerHTML = `
      <strong>${escapeHtml(payload.country || 'País no inferido')}</strong>
      <span>${payload.count || 0} incidentes</span>
      <small>Objetivos: ${escapeHtml(labels)}</small>
      <small>Tipos: ${escapeHtml(attacks)}</small>
      <small>Última fecha: ${escapeHtml(formatDate(payload.latest_date || ''))}</small>
      <small>Fuente: ${escapeHtml(payload.latest_source || 'Fuente no inferida')}</small>
    `;
    tooltip.classList.remove('hidden');
    const bounds = stage.getBoundingClientRect();
    const ttRect = tooltip.getBoundingClientRect();
    const gap = 14;
    const localX = event.clientX - bounds.left;
    const localY = event.clientY - bounds.top;
    let left = localX + gap;
    let top = localY + gap;
    if (left + ttRect.width > bounds.width - 8) left = localX - ttRect.width - gap;
    if (top + ttRect.height > bounds.height - 8) top = localY - ttRect.height - gap;
    left = Math.max(8, Math.min(left, bounds.width - ttRect.width - 8));
    top = Math.max(8, Math.min(top, bounds.height - ttRect.height - 8));
    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
  };

  stage.querySelectorAll('.map-marker').forEach(marker => {
    marker.onmouseenter = event => moveTooltip(event, marker);
    marker.onmousemove = event => moveTooltip(event, marker);
    marker.onmouseleave = () => tooltip.classList.add('hidden');
    marker.onclick = event => {
      event.preventDefault();
      if (state.moved) return;
      const articleId = (marker.dataset.articleIds || '').split(',').filter(Boolean)[0] || '';
      const row = brandsMapIncidents.querySelector(`[data-article-id="${CSS.escape(String(articleId))}"]`);
      if (row) row.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    };
  });
}

async function renderMap(data) {
  const signature = JSON.stringify({
    type: data.map_type, year: data.year, mode: data.selected_mode,
    totals: data.totals,
    points: (data.points || []).map(point => [point.country, point.count, point.x_pct, point.y_pct]),
  });
  currentMapData = data;
  currentMapDataBySector[data.map_type || currentSector || 'general'] = data;
  if (mapSectionTitle) mapSectionTitle.textContent = data.title || 'Mapa anual';
  if (mapSectionDescription) mapSectionDescription.textContent = data.description || '';
  if (mapIncidentsTitle) mapIncidentsTitle.textContent = data.map_type === 'marcas_retail' ? 'Últimos incidentes de Marcas' : 'Últimos incidentes generales';
  if (mapMethodology) mapMethodology.textContent = data.methodology || '';

  const selectedValue = String(data.year || CURRENT_MAP_YEAR);
  currentMapYear = selectedValue;
  mapYearBySector[data.map_type || currentSector || 'general'] = selectedValue;
  if (brandsMapYearSelect) {
    const count = Number((data.year_counts || {})[selectedValue] || (data.totals || {}).all_articles || 0);
    brandsMapYearSelect.innerHTML = `<option value="${escapeAttribute(selectedValue)}" selected>${escapeHtml(`${selectedValue}${count ? ` · ${count}` : ''}`)}</option>`;
    brandsMapYearSelect.disabled = true;
  }

  const yearLabel = `Año actual · ${data.year || selectedValue}`;
  renderMapStats(data.totals || {}, yearLabel);
  await preloadMapBaseImage();
  const elapsedLoader = mapLoaderVisible ? (Date.now() - mapLoaderShownAt) : MAP_MIN_LOADER_MS;
  if (mapLoaderVisible && elapsedLoader < MAP_MIN_LOADER_MS) await wait(MAP_MIN_LOADER_MS - elapsedLoader);
  if (signature !== lastRenderedMapSignature) {
    brandsMapCanvas.innerHTML = buildMapMarkup(data);
    lastRenderedMapSignature = signature;
  }
  hideMapLoader();
  renderList(brandsMapTopCountries, data.top_countries, item => `
    <div class="map-list-item">
      <strong>${escapeHtml(item.country)}</strong>
      <span>${item.count} incidentes</span>
      <small>${escapeHtml((item.labels || []).join(', ') || 'Sin objetivos inferidos')}</small>
    </div>
  `);
  renderList(brandsMapTopAttacks, data.top_attacks, item => `
    <div class="map-list-item compact">
      <strong>${escapeHtml(item.label)}</strong>
      <span>${item.count}</span>
    </div>
  `);
  renderList(brandsMapIncidents, data.incidents, item => `
    <article class="incident-row" data-article-id="${escapeAttribute(String(item.id || ''))}">
      <div>
        <div class="incident-badges">
          <span class="tag-chip country-badge">${escapeHtml(item.country || 'No inferido')}</span>
          <span class="tag-chip attack-badge">${escapeHtml(item.attack_type || 'Incidente ciber')}</span>
          <span class="tag-chip">${escapeHtml(item.label || 'Sin objetivo')}</span>
        </div>
        <h4>${escapeHtml(item.title)}</h4>
        <p>${escapeHtml(item.feed_name || item.source || 'Fuente no inferida')}</p>
      </div>
      <div class="incident-meta">
        <span>${escapeHtml(formatDate(item.published_at))}</span>
        <a class="button-link secondary-btn" href="${escapeAttribute(item.article_url)}" target="_blank" rel="noopener noreferrer">Abrir</a>
      </div>
    </article>
  `, 'Sin incidentes todavía.');
  attachMapInteractions();
}


function hasVisibleNews(state) {
  const stats = state?.stats || {};
  return Number(stats.total_articles || 0) > 0;
}

function startupInProgress(state) {
  return Boolean(state?.startup?.in_progress);
}

function rescoreInProgress(state) {
  const jobs = state?.jobs || {};
  return Boolean(jobs.rescore_in_progress || jobs.rescore_pending);
}

function buildStartupMessage(state) {
  const result = state?.startup?.result || {};
  const feeds = Number(result.feeds || 0);
  const scanned = Number(result.scanned || 0);
  const inserted = Number(result.inserted || 0);
  if (feeds || scanned || inserted) {
    return `Preparando primeras noticias… feeds ${feeds} · escaneadas ${scanned} · nuevas ${inserted}`;
  }
  return 'Preparando primeras noticias…';
}

function queueDashboardReload(delay = 350, silent = true) {
  clearTimeout(dashboardReloadTimer);
  dashboardReloadTimer = setTimeout(async () => {
    try {
      await Promise.all([
        loadArticles(),
        loadMap({ showLoader: false }),
      ]);
    } catch (error) {
      console.error(error);
    }
  }, delay);
}

async function waitForInitialData() {
  let state = currentStateSnapshot || await loadState();
  if (hasVisibleNews(state) || !startupInProgress(state)) return state;

  const deadline = Date.now() + 45000;
  while (Date.now() < deadline) {
    setBusy(true, buildStartupMessage(state));
    await new Promise(resolve => setTimeout(resolve, 1800));
    state = await loadState({ force: true });
    if (hasVisibleNews(state) || !startupInProgress(state)) {
      return state;
    }
  }
  return state;
}

async function pollStateAndMaybeRefresh() {
  const state = await loadState({ force: true, lite: true });
  const busyNow = startupInProgress(state) || rescoreInProgress(state);

  if (startupInProgress(state) && !hasVisibleNews(state)) {
    setBusy(true, buildStartupMessage(state));
  } else if (!saveInFlight) {
    setBusy(false);
  }

  if (rescoreInProgress(state)) {
    setPromptStatus('Configuración guardada. Recalculando en segundo plano…', 'progress');
  }

  if (asyncWorkWasRunning && !busyNow) {
    queueDashboardReload(150, true);
    if (!promptDirty) setPromptStatus('Recalculo terminado.', 'success');
  }

  asyncWorkWasRunning = busyNow;
  return state;
}

async function loadState(options = {}) {
  const { force = false, lite = false } = options;
  const now = Date.now();
  if (!force && stateFetchPromise) return stateFetchPromise;
  if (!force && currentStateSnapshot && (now - lastStateLoadedAt) < STATE_CACHE_MS) return currentStateSnapshot;
  stateFetchMode = lite ? 'lite' : 'full';
  stateFetchPromise = (async () => {
    const previousSignature = lastStatsSignature;
    const state = await api(lite ? '/api/state?lite=1' : '/api/state');
    renderStats(state.stats || currentStateSnapshot?.stats || {}, state.feedback || currentStateSnapshot?.feedback || {});
    if (!lite && Array.isArray(state.feeds)) renderFeeds(state.feeds);
    if (state.settings) applySettingsToForm(state.settings || {});
    currentStateSnapshot = {
      ...(currentStateSnapshot || {}),
      ...state,
      settings: { ...(currentStateSnapshot?.settings || {}), ...(state.settings || {}) },
      feeds: lite ? (currentStateSnapshot?.feeds || []) : (state.feeds || []),
    };
    lastStatsSignature = stateStatsSignature(currentStateSnapshot);
    if (previousSignature && previousSignature !== lastStatsSignature) clearResponseCaches();
    lastStateLoadedAt = Date.now();
    return currentStateSnapshot;
  })();
  try {
    return await stateFetchPromise;
  } finally {
    stateFetchPromise = null;
    stateFetchMode = 'full';
  }
}

async function loadArticles(options = {}) {
  const { preferCache = true, force = false } = options;
  const requestSeq = ++articlesRequestSeq;
  const sectorSnapshot = currentSector;
  const statusSnapshot = currentStatus;
  const cacheKey = articlesCacheKey(sectorSnapshot, statusSnapshot);
  const cached = !force && preferCache ? readUiCache(articlesResponseCache, cacheKey) : null;
  if (cached) {
    if (requestSeq === articlesRequestSeq && sectorSnapshot === currentSector && statusSnapshot === currentStatus) {
      renderArticles(cached.articles || []);
    }
    return cached;
  }

  if (!cached && !articlesContainer.querySelector('.article-card')) renderArticlesSkeleton(6);

  articlesFetchController?.abort();
  articlesFetchController = new AbortController();
  const params = new URLSearchParams({ limit: '24', page: '1', status: statusSnapshot, sector: sectorSnapshot });
  try {
    const payload = await api(`/api/articles?${params.toString()}`, { signal: articlesFetchController.signal });
    writeUiCache(articlesResponseCache, cacheKey, payload);
    if (requestSeq !== articlesRequestSeq || sectorSnapshot !== currentSector || statusSnapshot !== currentStatus) {
      return payload;
    }
    renderArticles(payload.articles || []);
    return payload;
  } catch (error) {
    if (error?.name === 'AbortError') return cached || { articles: [] };
    throw error;
  }
}

async function loadMap(options = {}) {
  const { showLoader = false, preferCache = true, force = false } = options;
  const requestSeq = ++mapRequestSeq;
  mapFetchController?.abort();
  mapFetchController = new AbortController();
  const sectorKey = currentSector === 'marcas_retail' ? 'marcas_retail' : 'general';
  const statusSnapshot = currentStatus;
  const preferredYear = preferredMapYearForSector(sectorKey);
  currentMapYear = preferredYear;
  const cacheKey = mapCacheKey(sectorKey, statusSnapshot, preferredYear);
  const cached = !force && preferCache ? readUiCache(mapResponseCache, cacheKey) : null;

  if (cached) {
    if (requestSeq === mapRequestSeq && sectorKey === (currentSector === 'marcas_retail' ? 'marcas_retail' : 'general') && statusSnapshot === currentStatus) {
      hideMapLoader();
      await renderMap(cached);
    }
    return cached;
  }

  if (showLoader || !currentMapDataBySector[sectorKey]) {
    const loaderMessage = sectorKey === 'marcas_retail' ? 'Radar buscando marcas víctimas y países…' : 'Radar buscando incidentes y países…';
    ensureMapShell(loaderMessage);
    renderMapLoading(loaderMessage);
    await wait(16);
  }
  const params = new URLSearchParams({ sector: sectorKey, status: statusSnapshot });
  if (preferredYear && !['latest', 'all'].includes(String(preferredYear))) params.set('year', String(preferredYear));
  try {
    const data = await api(`/api/incidents-map?${params.toString()}`, { signal: mapFetchController.signal });
    writeUiCache(mapResponseCache, cacheKey, data);
    const fallbackData = currentMapDataBySector[sectorKey] || currentMapData;
    if (requestSeq !== mapRequestSeq) return fallbackData || data;
    const incomingIncidents = Number((data.totals || {}).incidents || (data.incidents_count || 0) || 0);
    const existingIncidents = Number((fallbackData?.totals || {}).incidents || 0);
    if (!incomingIncidents && existingIncidents && fallbackData?.map_type === data.map_type) {
      hideMapLoader();
      await renderMap(fallbackData);
      return fallbackData;
    }
    await renderMap(data);
    return data;
  } catch (error) {
    if (error?.name === 'AbortError') return currentMapDataBySector[sectorKey] || currentMapData || cached;
    const fallbackData = currentMapDataBySector[sectorKey] || currentMapData || cached;
    if (!fallbackData) {
      hideMapLoader();
      throw error;
    }
    console.error(error);
    hideMapLoader();
    await renderMap(fallbackData);
    return fallbackData;
  }
}


function stateStatsSignature(state) {
  const stats = state?.stats || {};
  const startup = state?.startup || {};
  return JSON.stringify({
    total: Number(stats.total_articles || 0),
    included: Number(stats.included_count || 0),
    pending: Number(stats.pending_count || 0),
    excluded: Number(stats.excluded_count || 0),
    startup: Boolean(startup.in_progress),
    finished: startup.finished_at || '',
    rescoreFinished: state?.jobs?.rescore_last_finished_at || '',
  });
}

async function backgroundRefresh() {
  if (backgroundRefreshInFlight) return;
  backgroundRefreshInFlight = true;
  try {
    await Promise.all([
      loadArticles({ preferCache: true }),
      loadMap({ showLoader: false, preferCache: true }),
    ]);
  } finally {
    backgroundRefreshInFlight = false;
  }
}

async function showArticle(articleId) {
  const article = await api(`/api/articles/${articleId}`);
  dialogContent.innerHTML = `
    <h2>${escapeHtml(article.title)}</h2>
    ${articleImageMarkup(article, 'dialog-image')}
    <p><strong>Fuente:</strong> ${escapeHtml(article.feed_name || 'N/D')}</p>
    <p><strong>Fecha:</strong> ${escapeHtml(formatDate(article.published_at || article.created_at))}</p>
    <p><strong>Tags:</strong> ${(article.match_tags || []).map(escapeHtml).join(', ') || 'Sin tags'}</p>
    <p><strong>Score híbrido:</strong> ${Number(article.relevance_score || 0).toFixed(2)} · <strong>Semántico:</strong> ${Number(article.semantic_score || 0).toFixed(2)} · <strong>Feedback:</strong> ${Number(article.feedback_score || 0).toFixed(2)}</p>
    <p><strong>Explicación:</strong> ${escapeHtml(article.rationale || 'Sin explicación')}</p>
    <p>${escapeHtml(article.summary || '')}</p>
    <p>${escapeHtml(article.content || '')}</p>
    <p><strong>Artículo:</strong> <a href="${escapeAttribute(article.article_url)}" target="_blank" rel="noopener noreferrer">Abrir noticia</a></p>
  `;
  dialog.showModal();
}
window.showArticle = showArticle;

async function setArticleStatus(articleId, status) {
  await api(`/api/articles/${articleId}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  await loadState({ force: true });
  await Promise.all([loadArticles(), loadMap({ showLoader: false })]);
}
window.setArticleStatus = setArticleStatus;

async function toggleFeed(feedId, is_enabled) {
  await api(`/api/feeds/${feedId}`, { method: 'PATCH', body: JSON.stringify({ is_enabled }) });
  await loadState({ force: true });
  await Promise.all([loadArticles(), loadMap({ showLoader: false })]);
}
window.toggleFeed = toggleFeed;

async function removeFeed(feedId) {
  await api(`/api/feeds/${feedId}`, { method: 'DELETE' });
  await loadState({ force: true });
  await Promise.all([loadArticles(), loadMap({ showLoader: false })]);
}
window.removeFeed = removeFeed;

function currentSettingsPayload(promptOnly = false) {
  const promptValue = promptInput?.value || '';
  if (promptOnly) return { prompt: promptValue };
  return {
    prompt: promptValue,
    runtime_profile: runtimeProfileInput?.value || 'low_resource',
    poll_interval_seconds: Number(intervalInput?.value || 300),
    ...(maxArticlesInput ? { max_articles_per_feed: Number(maxArticlesInput.value || 0) } : {}),
    auto_refresh_enabled: Boolean(autoRefreshInput?.checked),
    date_window: dateWindowInput?.value || 'all',
    relevance_mode: relevanceModeInput?.value || 'balanced',
    hide_duplicates: Boolean(hideDuplicatesInput?.checked),
  };
}

async function saveSettings(promptOnly = false, source = 'manual') {
  if (saveInFlight) return;
  saveInFlight = true;
  saveSettingsBtn.disabled = true;
  const originalButtonText = saveSettingsBtn.textContent;
  saveSettingsBtn.textContent = source === 'manual' ? 'Guardando…' : 'Autoguardando…';
  setPromptStatus(source === 'manual' ? 'Guardando configuración…' : 'Autoguardando prompt…', 'progress');
  try {
    const payload = currentSettingsPayload(promptOnly);
    const result = await api('/api/settings', { method: 'PATCH', body: JSON.stringify(payload) });
    if (typeof payload.prompt === 'string') {
      lastServerPrompt = promptInput.value;
      promptDirty = false;
      persistPromptDraft('');
    }
    applySettingsToForm(result.settings || {});
    currentStateSnapshot = { ...(currentStateSnapshot || {}), settings: result.settings || {} };
    const jobsBusy = Boolean(result.jobs?.rescore_in_progress || result.jobs?.rescore_pending);
    setPromptStatus(jobsBusy ? 'Configuración guardada. Recalculando en segundo plano…' : 'Configuración guardada.', jobsBusy ? 'progress' : 'success');
    if (!promptOnly) {
      await loadState({ force: true });
      if (jobsBusy) queueDashboardReload(900);
      else queueDashboardReload(150);
    }
  } catch (error) {
    setPromptStatus(`Error al guardar: ${error.message}`, 'error');
    throw error;
  } finally {
    saveInFlight = false;
    saveSettingsBtn.disabled = false;
    saveSettingsBtn.textContent = originalButtonText;
  }
}

async function addFeed() {
  const payload = {
    name: document.getElementById('feedNameInput').value || null,
    url: document.getElementById('feedUrlInput').value,
  };
  await api('/api/feeds', { method: 'POST', body: JSON.stringify(payload) });
  const feedNameInput = document.getElementById('feedNameInput');
  const feedUrlInput = document.getElementById('feedUrlInput');
  if (feedNameInput) feedNameInput.value = '';
  if (feedUrlInput) feedUrlInput.value = '';
  await loadState({ force: true });
  await Promise.all([loadArticles(), loadMap({ showLoader: false })]);
}

async function refreshNow() {
  setBusy(true, 'Actualizando feeds y recalculando…');
  try {
    await api('/api/refresh', { method: 'POST' });
    await loadState({ force: true });
    await Promise.all([
      loadArticles({ force: true }),
      loadMap({ showLoader: true, force: true }),
    ]);
  } finally {
    setBusy(false);
  }
}

saveSettingsBtn?.addEventListener('click', () => saveSettings(false, 'manual'));
runtimeProfileInput?.addEventListener('change', () => {
  renderRuntimeProfileHint();
  saveSettings(false, 'manual').catch(console.error);
});
document.getElementById('addFeedBtn')?.addEventListener('click', addFeed);
document.getElementById('refreshBtn')?.addEventListener('click', refreshNow);
brandsMapDownloadBtn?.addEventListener('click', () => {
  if (!currentMapData) return;
  const blob = new Blob([JSON.stringify(currentMapData, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `cyberrad_${currentSector}_${currentMapYear || 'latest'}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 500);
});
brandsMapYearSelect?.addEventListener('change', async () => {
  const sectorKey = currentSector === 'marcas_retail' ? 'marcas_retail' : 'general';
  currentMapYear = brandsMapYearSelect.value || preferredMapYearForSector(sectorKey);
  mapYearBySector[sectorKey] = currentMapYear;
  await loadMap();
});

promptInput?.addEventListener('input', () => {
  promptDirty = promptInput.value !== lastServerPrompt;
  persistPromptDraft(promptInput.value);
  setPromptStatus(promptDirty ? 'Borrador local guardado.' : 'Prompt sincronizado con el servidor.', promptDirty ? 'warning' : 'success');
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => {
    if (promptDirty) saveSettings(true, 'autosave').catch(console.error);
  }, 900);
});

promptInput?.addEventListener('blur', () => {
  if (promptDirty) saveSettings(true, 'autosave').catch(console.error);
});

window.addEventListener('beforeunload', () => persistPromptDraft(promptInput?.value || ''));
window.addEventListener('keydown', event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
    event.preventDefault();
    saveSettings(false, 'manual').catch(console.error);
  }
});

document.querySelectorAll('.status-filter').forEach(button => {
  button.addEventListener('click', async () => {
    document.querySelectorAll('.status-filter').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    currentStatus = button.dataset.status;
    clearMapCountrySelection();
    await Promise.all([
      loadArticles({ preferCache: true }),
      loadMap({ showLoader: false, preferCache: true }),
    ]);
  });
});

document.querySelectorAll('.sector-filter').forEach(button => {
  button.addEventListener('click', async () => {
    document.querySelectorAll('.sector-filter').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    currentSector = button.dataset.sector || 'general';
    currentMapYear = preferredMapYearForSector(currentSector);
    clearMapCountrySelection();
    await Promise.all([
      loadArticles({ preferCache: true }),
      loadMap({ showLoader: false, preferCache: true }),
    ]);
  });
});

async function boot() {
  setBusy(true, 'Cargando CyberRad…');
  currentSector = 'general';
  currentStatus = 'all';
  try {
    let state = await loadState({ force: true });
    state = await waitForInitialData();
    lastServerPrompt = state.settings?.prompt || '';
    const localDraft = loadLocalPromptDraft();
    if (localDraft && localDraft !== lastServerPrompt) {
      if (promptInput) promptInput.value = localDraft;
      promptDirty = true;
      setPromptStatus('Borrador local recuperado.', 'warning');
    } else {
      setPromptStatus('Prompt sincronizado con el servidor.', 'success');
    }
    preloadMapBaseImage().catch(() => false);
    let [articlePayload, mapPayload] = await Promise.all([
      loadArticles({ force: true }),
      loadMap({ showLoader: true, force: true }),
    ]);

    const visibleArticles = Number(articlePayload?.total_visible || articlePayload?.articles?.length || 0);
    const visibleIncidents = Number((mapPayload?.totals || {}).incidents || 0);
    if (currentSector === 'general' && Number((state?.stats || {}).total_articles || 0) > 0 && visibleArticles === 0 && visibleIncidents === 0) {
      clearResponseCaches();
      await wait(220);
      [articlePayload, mapPayload] = await Promise.all([
        loadArticles({ force: true }),
        loadMap({ showLoader: false, force: true }),
      ]);
    }

    bootstrappedContent = true;
    if (startupInProgress(state) && Number((mapPayload?.totals || {}).incidents || 0) === 0 && Number((state?.stats || {}).total_articles || 0) === 0) {
      setBusy(true, buildStartupMessage(state));
    } else {
      setBusy(false);
    }
    asyncWorkWasRunning = startupInProgress(state) || rescoreInProgress(state);
  } finally {
    if (!startupInProgress(currentStateSnapshot) || hasVisibleNews(currentStateSnapshot)) {
      setBusy(false);
    }
  }
  setInterval(async () => {
    if (document.hidden || statePollInFlight || !isAutoRefreshEnabled()) return;
    statePollInFlight = true;
    try {
      const before = lastStatsSignature;
      const state = await pollStateAndMaybeRefresh();
      const after = stateStatsSignature(state);
      if (before && after !== before) {
        clearResponseCaches();
        await backgroundRefresh();
      }
    } catch (error) {
      console.error(error);
    } finally {
      statePollInFlight = false;
    }
  }, STATE_POLL_MS);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && bootstrappedContent && isAutoRefreshEnabled()) {
      if (!statePollInFlight) {
        statePollInFlight = true;
        pollStateAndMaybeRefresh().catch(console.error).finally(() => { statePollInFlight = false; });
      }
    }
  });
}



// HOTFIX20_PROFESSIONAL_RELIABILITY
let selectedMapCountry = null;
let selectedMapCountryPage = 1;
let selectedCountryPayload = null;
let selectedCountryLoading = false;
const MAP_COUNTRY_PAGE_SIZE = 20;

async function fetchSelectedCountryPage(country = selectedMapCountry, page = selectedMapCountryPage) {
  const canonicalCountry = String(country || '').trim();
  if (!canonicalCountry || !currentMapData) {
    selectedCountryPayload = null;
    selectedCountryLoading = false;
    return null;
  }
  selectedCountryLoading = true;
  renderMapCountrySelection(currentMapData);
  countryFetchController?.abort();
  countryFetchController = new AbortController();
  const sectorKey = currentSector === 'marcas_retail' ? 'marcas_retail' : 'general';
  const params = new URLSearchParams({
    sector: sectorKey,
    status: currentStatus,
    country: canonicalCountry,
    page: String(page || 1),
    page_size: String(MAP_COUNTRY_PAGE_SIZE),
  });
  const preferredYear = preferredMapYearForSector(sectorKey);
  if (preferredYear && !['latest', 'all'].includes(String(preferredYear))) params.set('year', String(preferredYear));
  try {
    const payload = await api(`/api/incidents-map/country?${params.toString()}`, { signal: countryFetchController.signal });
    if (selectedMapCountry !== canonicalCountry || selectedMapCountryPage !== Number(payload.page || page || 1)) return payload;
    selectedCountryPayload = payload;
    selectedCountryLoading = false;
    renderMapCountrySelection(currentMapData);
    return payload;
  } catch (error) {
    if (error?.name === 'AbortError') return null;
    selectedCountryLoading = false;
    selectedCountryPayload = { country: canonicalCountry, total: 0, page: 1, pages: 1, incidents: [], error: error.message || 'Error' };
    renderMapCountrySelection(currentMapData);
    return null;
  }
}

function mapPointSize(count, maxCount) {
  const ratio = Math.sqrt((count || 1) / (maxCount || 1));
  return 22 + Math.round(18 * ratio);
}

function countryIncidentRows(data, country) {
  const incidents = Array.isArray(data?.incidents) ? data.incidents : [];
  if (!country) return incidents;
  return incidents.filter(item => String(item.country || '') === String(country));
}

function renderMapCountrySelection(data) {
  const selectedPayload = selectedMapCountry && selectedCountryPayload && selectedCountryPayload.country === selectedMapCountry
    ? selectedCountryPayload
    : null;

  const previewRows = Array.isArray(data?.incidents_preview) ? data.incidents_preview : [];
  const title = selectedMapCountry
    ? `${selectedMapCountry} · ${Number(selectedPayload?.total || 0)} noticias vinculadas al marcador`
    : (data.map_type === 'marcas_retail' ? 'Últimos resultados de Marcas' : 'Últimos resultados generales');
  if (mapIncidentsTitle) mapIncidentsTitle.textContent = title;

  if (selectedMapCountry && selectedCountryLoading && !selectedPayload) {
    brandsMapIncidents.innerHTML = '<div class="card empty-state">Cargando noticias del país seleccionado…</div>';
    return;
  }

  if (selectedMapCountry) {
    const rows = Array.isArray(selectedPayload?.incidents) ? selectedPayload.incidents : [];
    const total = Number(selectedPayload?.total || 0);
    const totalPages = Math.max(1, Number(selectedPayload?.pages || 1));
    const currentPage = Math.max(1, Number(selectedPayload?.page || selectedMapCountryPage || 1));
    renderList(brandsMapIncidents, rows, item => `
      <article class="incident-row highlighted" data-article-id="${escapeAttribute(String(item.id || ''))}">
        <div>
          <div class="incident-badges">
            <button class="tag-chip country-badge country-badge-button" onclick="selectMapCountry('${escapeAttribute(String(item.country || 'No inferido'))}'); event.stopPropagation();">${escapeHtml(item.country || 'No inferido')}</button>
            <span class="tag-chip attack-badge">${escapeHtml(item.attack_type || 'General ciber / digital')}</span>
            <span class="tag-chip">${escapeHtml(item.label || 'Sin objetivo')}</span>
          </div>
          <h4>${escapeHtml(item.title)}</h4>
          <p>${escapeHtml((item.content_categories || []).join(' · ') || item.feed_name || item.source || 'Fuente no inferida')}</p>
        </div>
        <div class="incident-meta">
          <span>${escapeHtml(formatDate(item.published_at))}</span>
          <a class="button-link secondary-btn" href="${escapeAttribute(item.article_url)}" target="_blank" rel="noopener noreferrer">Abrir</a>
        </div>
      </article>
    `, selectedPayload?.error ? `Error al cargar el país: ${escapeHtml(selectedPayload.error)}` : 'Sin incidentes todavía.');
    brandsMapIncidents.insertAdjacentHTML('beforeend', `
      <div class="map-pagination">
        <button class="secondary-btn" ${currentPage <= 1 ? 'disabled' : ''} onclick="changeMapCountryPage(${currentPage - 1})">Anterior</button>
        <span>Página ${currentPage} / ${totalPages} · ${total} noticias</span>
        <button class="secondary-btn" ${currentPage >= totalPages ? 'disabled' : ''} onclick="changeMapCountryPage(${currentPage + 1})">Siguiente</button>
        <button class="secondary-btn" onclick="clearMapCountrySelection()">Quitar filtro país</button>
      </div>
    `);
    return;
  }

  renderList(brandsMapIncidents, previewRows, item => `
    <article class="incident-row" data-article-id="${escapeAttribute(String(item.id || ''))}">
      <div>
        <div class="incident-badges">
          <button class="tag-chip country-badge country-badge-button" onclick="selectMapCountry('${escapeAttribute(String(item.country || 'No inferido'))}'); event.stopPropagation();">${escapeHtml(item.country || 'No inferido')}</button>
          <span class="tag-chip attack-badge">${escapeHtml(item.attack_type || 'General ciber / digital')}</span>
          <span class="tag-chip">${escapeHtml(item.label || 'Sin objetivo')}</span>
        </div>
        <h4>${escapeHtml(item.title)}</h4>
        <p>${escapeHtml((item.content_categories || []).join(' · ') || item.feed_name || item.source || 'Fuente no inferida')}</p>
      </div>
      <div class="incident-meta">
        <span>${escapeHtml(formatDate(item.published_at))}</span>
        <a class="button-link secondary-btn" href="${escapeAttribute(item.article_url)}" target="_blank" rel="noopener noreferrer">Abrir</a>
      </div>
    </article>
  `, 'Sin incidentes todavía.');
}

function renderMapTopCountries(data) {
  renderList(brandsMapTopCountries, data.top_countries, item => `
    <button class="map-list-item map-country-item ${selectedMapCountry === item.country ? 'active' : ''}" onclick="selectMapCountry('${escapeAttribute(item.country)}')">
      <strong>${escapeHtml(item.country)}</strong>
      <span>${item.count} noticias</span>
      <small>${escapeHtml((item.content_categories || item.labels || []).join(', ') || 'Sin categorías inferidas')}</small>
    </button>
  `);
}

function buildMapMarkup(data) {
  const points = Array.isArray(data.points) ? data.points : [];
  const maxCount = Math.max(...points.map(point => point.count || 0), 1);
  const markers = points.map(point => {
    const size = mapPointSize(point.count, maxCount);
    const isActive = selectedMapCountry === point.country;
    return `
      <button class="map-marker ${isActive ? 'is-active' : ''}" style="left:${point.x_pct}%; top:${point.y_pct}%; width:${size}px; height:${size}px;" data-country="${escapeAttribute(point.country)}" data-article-ids="${escapeAttribute((point.article_ids || []).join(','))}" data-tooltip="${escapeAttribute(JSON.stringify(point))}" aria-label="${escapeAttribute(point.country)} ${point.count} noticias">
        <span>${point.count}</span>
      </button>
    `;
  }).join('');
  const empty = !Number((data.totals || {}).incidents || 0) ? '<div class="map-overlay-empty">No hay datos suficientes para pintar el mapa todavía.</div>' : '';
  return `
    <div class="map-backdrop clean-map">
      <div class="map-panzoom" id="mapPanzoom">
        <div class="map-surface" id="mapSurface">
          <img class="map-base-image" src="${escapeAttribute(data.map_base_image || MAP_BASE_IMAGE_URL)}" alt="Mapa mundial" draggable="false" loading="eager" decoding="async" />
          <div class="map-layer">${markers}</div>
        </div>
      </div>
      <div class="map-hint">Rueda para zoom · Arrastra para mover · Doble clic para centrar</div>
      <div id="mapTooltip" class="map-tooltip hidden"></div>
      ${empty}
    </div>
  `;
}

function attachMapInteractions() {
  currentMapInteractionController?.abort();
  currentMapInteractionController = new AbortController();
  const { signal } = currentMapInteractionController;

  const stage = brandsMapCanvas.querySelector('.map-backdrop');
  const panzoom = brandsMapCanvas.querySelector('#mapPanzoom');
  const surface = brandsMapCanvas.querySelector('#mapSurface');
  const tooltip = brandsMapCanvas.querySelector('#mapTooltip');
  if (!stage || !panzoom || !surface || !tooltip) return;

  const state = { scale: 1, x: 0, y: 0, pointerId: null, dragging: false, startX: 0, startY: 0, downX: 0, downY: 0, moved: false, raf: 0 };

  const clampPan = () => {
    const rect = panzoom.getBoundingClientRect();
    const scaledWidth = rect.width * state.scale;
    const scaledHeight = rect.height * state.scale;
    const minX = Math.min(0, rect.width - scaledWidth);
    const minY = Math.min(0, rect.height - scaledHeight);
    state.x = Math.min(0, Math.max(minX, state.x));
    state.y = Math.min(0, Math.max(minY, state.y));
  };

  const applyTransformNow = () => {
    clampPan();
    surface.style.transform = `translate3d(${state.x.toFixed(2)}px, ${state.y.toFixed(2)}px, 0) scale(${state.scale.toFixed(4)})`;
    const markerCompScale = Math.min(1, Math.max(0.3, 1 / Math.pow(state.scale, 1.18)));
    surface.style.setProperty('--marker-comp-scale', markerCompScale.toFixed(4));
    surface.classList.add('is-ready');
    state.raf = 0;
  };
  const applyTransform = () => {
    if (state.raf) return;
    state.raf = requestAnimationFrame(applyTransformNow);
  };
  const resetView = () => {
    state.scale = 1;
    state.x = 0;
    state.y = 0;
    applyTransform();
  };
  const zoomAt = (clientX, clientY, delta) => {
    const rect = panzoom.getBoundingClientRect();
    const nextScale = Math.min(4.2, Math.max(1, state.scale * delta));
    if (nextScale === state.scale) return;
    const originX = clientX - rect.left;
    const originY = clientY - rect.top;
    const worldX = (originX - state.x) / state.scale;
    const worldY = (originY - state.y) / state.scale;
    state.scale = nextScale;
    state.x = originX - worldX * state.scale;
    state.y = originY - worldY * state.scale;
    applyTransform();
  };
  const stopDrag = event => {
    if (event?.pointerId != null && state.pointerId != null && event.pointerId !== state.pointerId) return;
    if (state.pointerId != null) {
      try { panzoom.releasePointerCapture?.(state.pointerId); } catch (error) {}
    }
    state.pointerId = null;
    state.dragging = false;
    panzoom.classList.remove('is-dragging');
  };
  applyTransform();
  panzoom.onwheel = event => {
    event.preventDefault();
    const delta = event.deltaY < 0 ? 1.12 : 0.9;
    zoomAt(event.clientX, event.clientY, delta);
  };
  panzoom.onpointerdown = event => {
    if (event.button !== 0) return;
    event.preventDefault();
    state.pointerId = event.pointerId;
    state.dragging = true;
    state.moved = false;
    state.downX = event.clientX;
    state.downY = event.clientY;
    state.startX = event.clientX - state.x;
    state.startY = event.clientY - state.y;
    panzoom.setPointerCapture?.(event.pointerId);
    panzoom.classList.add('is-dragging');
    tooltip.classList.add('hidden');
  };
  panzoom.onpointermove = event => {
    if (!state.dragging || state.pointerId !== event.pointerId) return;
    state.x = event.clientX - state.startX;
    state.y = event.clientY - state.startY;
    const movedX = Math.abs(event.clientX - state.downX);
    const movedY = Math.abs(event.clientY - state.downY);
    state.moved = state.moved || movedX > 5 || movedY > 5;
    tooltip.classList.add('hidden');
    applyTransform();
  };
  panzoom.onpointerup = stopDrag;
  panzoom.onpointercancel = stopDrag;
  window.addEventListener('pointerup', stopDrag, { passive: true, signal });
  panzoom.ondblclick = event => { event.preventDefault(); resetView(); };

  const moveTooltip = (event, marker) => {
    const payload = JSON.parse(marker.dataset.tooltip || '{}');
    const labels = (payload.labels || []).slice(0, 4).join(', ') || payload.latest_label || 'Sin objetivo inferido';
    const attacks = (payload.attack_types || []).slice(0, 3).join(', ') || payload.latest_attack_type || 'General ciber / digital';
    const cats = (payload.content_categories || []).slice(0, 3).join(', ');
    tooltip.innerHTML = `
      <strong>${escapeHtml(payload.country || 'País no inferido')}</strong>
      <span>${payload.count || 0} noticias reales</span>
      <small>Objetivos: ${escapeHtml(labels)}</small>
      <small>Tipos: ${escapeHtml(attacks)}</small>
      ${cats ? `<small>Categorías: ${escapeHtml(cats)}</small>` : ''}
      <small>Última fecha: ${escapeHtml(formatDate(payload.latest_date || ''))}</small>
      <small>Fuente: ${escapeHtml(payload.latest_source || 'Fuente no inferida')}</small>
    `;
    tooltip.classList.remove('hidden');
    const bounds = stage.getBoundingClientRect();
    const ttRect = tooltip.getBoundingClientRect();
    const gap = 14;
    const localX = event.clientX - bounds.left;
    const localY = event.clientY - bounds.top;
    let left = localX + gap;
    let top = localY + gap;
    if (left + ttRect.width > bounds.width - 8) left = localX - ttRect.width - gap;
    if (top + ttRect.height > bounds.height - 8) top = localY - ttRect.height - gap;
    left = Math.max(8, Math.min(left, bounds.width - ttRect.width - 8));
    top = Math.max(8, Math.min(top, bounds.height - ttRect.height - 8));
    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
  };

  stage.querySelectorAll('.map-marker').forEach(marker => {
    marker.onmouseenter = event => moveTooltip(event, marker);
    marker.onmousemove = event => moveTooltip(event, marker);
    marker.onmouseleave = () => tooltip.classList.add('hidden');
    marker.onclick = event => {
      event.preventDefault();
      if (state.moved) return;
      selectMapCountry(marker.dataset.country || '');
    };
  });
}

function selectMapCountry(country) {
  selectedMapCountry = String(country || '').trim() || null;
  selectedMapCountryPage = 1;
  selectedCountryPayload = null;
  if (currentMapData) renderMap(currentMapData);
  if (selectedMapCountry) fetchSelectedCountryPage(selectedMapCountry, 1).catch(console.error);
  brandsMapIncidents.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
window.selectMapCountry = selectMapCountry;

function clearMapCountrySelection() {
  selectedMapCountry = null;
  selectedMapCountryPage = 1;
  selectedCountryPayload = null;
  selectedCountryLoading = false;
  countryFetchController?.abort();
  if (currentMapData) renderMap(currentMapData);
}
window.clearMapCountrySelection = clearMapCountrySelection;

function changeMapCountryPage(page) {
  selectedMapCountryPage = Math.max(1, Number(page || 1));
  selectedCountryPayload = null;
  if (currentMapData) renderMap(currentMapData);
  if (selectedMapCountry) fetchSelectedCountryPage(selectedMapCountry, selectedMapCountryPage).catch(console.error);
}
window.changeMapCountryPage = changeMapCountryPage;

async function renderMap(data) {
  const signature = JSON.stringify({
    type: data.map_type, year: data.year, mode: data.selected_mode,
    totals: data.totals,
    selectedCountry: selectedMapCountry || '',
    points: (data.points || []).map(point => [point.country, point.count, point.x_pct, point.y_pct]),
  });
  currentMapData = data;
  currentMapDataBySector[data.map_type || currentSector || 'general'] = data;
  if (selectedMapCountry && !(data.points || []).some(point => point.country === selectedMapCountry)) {
    selectedMapCountry = null;
    selectedMapCountryPage = 1;
  }
  if (mapSectionTitle) mapSectionTitle.textContent = data.title || 'Mapa anual';
  if (mapSectionDescription) mapSectionDescription.textContent = data.description || '';
  if (mapMethodology) mapMethodology.textContent = data.methodology || '';

  const selectedValue = String(data.year || CURRENT_MAP_YEAR);
  currentMapYear = selectedValue;
  mapYearBySector[data.map_type || currentSector || 'general'] = selectedValue;
  if (brandsMapYearSelect) {
    const count = Number((data.year_counts || {})[selectedValue] || (data.totals || {}).all_articles || 0);
    brandsMapYearSelect.innerHTML = `<option value="${escapeAttribute(selectedValue)}" selected>${escapeHtml(`${selectedValue}${count ? ` · ${count}` : ''}`)}</option>`;
    brandsMapYearSelect.disabled = true;
  }

  const yearLabel = `Año actual · ${data.year || selectedValue}`;
  renderMapStats(data.totals || {}, yearLabel);
  await preloadMapBaseImage();
  const minLoader = 220;
  const elapsedLoader = mapLoaderVisible ? (Date.now() - mapLoaderShownAt) : minLoader;
  if (mapLoaderVisible && elapsedLoader < minLoader) await wait(minLoader - elapsedLoader);
  if (signature !== lastRenderedMapSignature) {
    brandsMapCanvas.innerHTML = buildMapMarkup(data);
    lastRenderedMapSignature = signature;
  }
  hideMapLoader();
  renderMapTopCountries(data);
  renderList(brandsMapTopAttacks, data.top_attacks, item => `
    <div class="map-list-item compact">
      <strong>${escapeHtml(item.label)}</strong>
      <span>${item.count}</span>
    </div>
  `);
  renderMapCountrySelection(data);
  attachMapInteractions();
  if (selectedMapCountry && (!selectedCountryPayload || selectedCountryPayload.country !== selectedMapCountry || Number(selectedCountryPayload.page || 0) !== selectedMapCountryPage)) {
    fetchSelectedCountryPage(selectedMapCountry, selectedMapCountryPage).catch(console.error);
  }
}

boot().catch(error => {
  console.error(error);
  articlesContainer.innerHTML = `<div class="card empty-state">Error al cargar: ${escapeHtml(error.message)}</div>`;
  setPromptStatus(`Error al iniciar: ${error.message}`, 'error');
  setBusy(false);
});

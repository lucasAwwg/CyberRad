CyberRad V4.6 Marcas Clean

# CyberRad V4.5.4 — Icarus / Kali compatible

Esta versión adapta CyberRad para dos escenarios:

1. **Icarus / GitLab Runner / Linux Mint 22.2 (Ubuntu 24 compatible)**
2. **Prueba rápida en Kali Linux antes de desplegar en la máquina definitiva**

## Cambios principales

- `docker-compose.yml` endurecido para **Icarus**:
  - publica por defecto `127.0.0.1:3001 -> 3000`
  - evita el conflicto con Grafana en el puerto 3000
  - ejecuta el contenedor sin privilegios extra
  - corre con el UID/GID del usuario del runner (`grafana-dev` o similar)
- `docker-compose.kali.yml` para pruebas rápidas en **Kali**:
  - publica `127.0.0.1:3000 -> 3000`
- `.gitlab-ci.yml` incluido para despliegue **DEV automático** y **PROD manual**
- `requirements.txt` con versiones fijadas para builds deterministas
- `Dockerfile` endurecido con usuario no-root y `HEALTHCHECK`

## Prueba rápida en Kali (sin Docker)

```bash
cd ~/CyberRad/cyberrad_v4_5_4_icarus_kali_compatible
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 3000 --app-dir .
```

Abrir `http://127.0.0.1:3000`

## Prueba rápida en Kali (con Docker)

```bash
cd ~/CyberRad/cyberrad_v4_5_4_icarus_kali_compatible
export CYBERRAD_UID=$(id -u)
export CYBERRAD_GID=$(id -g)
docker rm -f cyberrad-web 2>/dev/null || true
docker compose -f docker-compose.kali.yml up -d --build
```

Abrir `http://127.0.0.1:3000`

## Despliegue Icarus / GitLab Runner

```bash
cd /ruta/del/proyecto
export CYBERRAD_UID=$(id -u)
export CYBERRAD_GID=$(id -g)
export CYBERRAD_BIND_IP=127.0.0.1
export CYBERRAD_HOST_PORT=3001
docker compose -f docker-compose.yml up -d --build
```

Abrir desde la red interna o mediante reverse proxy el puerto `3001` del host.

## Notas de integración con Icarus

- **No usa** `env_file: .env` en el compose principal.
- El puerto por defecto para Icarus es **3001** para no chocar con Grafana.
- Si vuestro runner usa tags, ajustad `.gitlab-ci.yml` antes de activarlo.
- Para mantener el principio de mínimo privilegio, el contenedor no se lanza en modo `privileged`.
- La base de datos SQLite persiste en `./data`.

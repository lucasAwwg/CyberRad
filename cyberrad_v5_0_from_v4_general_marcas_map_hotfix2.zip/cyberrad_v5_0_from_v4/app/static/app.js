const statsEl = document.getElementById('stats');
const feedsListEl = document.getElementById('feedsList');
const articlesContainer = document.getElementById('articlesContainer');
const dialog = document.getElementById('articleDialog');
const dialogContent = document.getElementById('articleDialogContent');
const promptInput = document.getElementById('promptInput');
const promptSaveStatusEl = document.getElementById('promptSaveStatus');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const intervalInput = document.getElementById('intervalInput');
const maxArticlesInput = document.getElementById('maxArticlesInput');
const autoRefreshInput = document.getElementById('autoRefreshInput');
const dateWindowInput = document.getElementById('dateWindowInput');
const relevanceModeInput = document.getElementById('relevanceModeInput');
const hideDuplicatesInput = document.getElementById('hideDuplicatesInput');
const mapSectionTitle = document.getElementById('mapSectionTitle');
const mapSectionDescription = document.getElementById('mapSectionDescription');
const mapMethodology = document.getElementById('mapMethodology');
const brandsMapYearSelect = document.getElementById('brandsMapYearSelect');
const brandsMapDownloadBtn = document.getElementById('brandsMapDownloadBtn');
const brandsMapStats = document.getElementById('brandsMapStats');
const brandsMapCanvas = document.getElementById('brandsMapCanvas');
const brandsMapTopCountries = document.getElementById('brandsMapTopCountries');
const brandsMapTopAttacks = document.getElementById('brandsMapTopAttacks');
const brandsMapIncidents = document.getElementById('brandsMapIncidents');
const mapIncidentsTitle = document.getElementById('mapIncidentsTitle');
const screenLoader = document.getElementById('screenLoader');
const screenLoaderText = document.getElementById('screenLoaderText');

const PROMPT_DRAFT_KEY = 'cyberrad_prompt_draft_v50';
let currentStatus = 'all';
let currentSector = 'general';
let knownArticleIds = new Set();
let lastServerPrompt = '';
let promptDirty = false;
let autosaveTimer = null;
let saveInFlight = false;
let currentMapData = null;
let currentMapYear = 'latest';
const AUTO_RELOAD_MS = 30000;
const STATE_POLL_MS = 10000;

async function api(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', headers: { 'Content-Type': 'application/json' }, ...options });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(detail || 'Error en la petición');
  }
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function escapeHtml(value = '') {
  return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}
function escapeAttribute(value = '') { return escapeHtml(value); }

function setBusy(active, message = 'Cargando…') {
  screenLoader.classList.toggle('hidden', !active);
  screenLoaderText.textContent = message;
}

function setPromptStatus(message, tone = 'muted') {
  promptSaveStatusEl.textContent = message;
  promptSaveStatusEl.className = `save-status ${tone}`;
}

function persistPromptDraft(value) {
  try {
    if (value && value !== lastServerPrompt) localStorage.setItem(PROMPT_DRAFT_KEY, value);
    else localStorage.removeItem(PROMPT_DRAFT_KEY);
  } catch (error) {}
}

function loadLocalPromptDraft() {
  try { return localStorage.getItem(PROMPT_DRAFT_KEY) || ''; } catch (error) { return ''; }
}

function formatDate(value) {
  if (!value) return 'Sin fecha';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('es-ES');
}

function renderStats(stats, feedback = {}) {
  statsEl.innerHTML = `
    <div class="stat-box"><span>Total</span><strong>${stats.total_articles}</strong></div>
    <div class="stat-box"><span>Feeds</span><strong>${stats.feed_count}</strong></div>
    <div class="stat-box"><span>Incluidas</span><strong>${stats.included_count}</strong></div>
    <div class="stat-box"><span>Pendientes</span><strong>${stats.pending_count}</strong></div>
    <div class="stat-box"><span>Excluidas</span><strong>${stats.excluded_count}</strong></div>
    <div class="stat-box"><span>Feedback</span><strong>${feedback.feedback_events || 0}</strong></div>
  `;
}

function applySettingsToForm(settings) {
  const focusedElement = document.activeElement;
  const serverPrompt = settings.prompt || '';
  if (!promptDirty && focusedElement !== promptInput) {
    promptInput.value = serverPrompt;
    lastServerPrompt = serverPrompt;
    persistPromptDraft('');
  }
  if (focusedElement !== intervalInput) intervalInput.value = Number(settings.poll_interval_seconds || 300);
  if (focusedElement !== maxArticlesInput) maxArticlesInput.value = Number(settings.max_articles_per_feed || 20);
  if (focusedElement !== dateWindowInput) dateWindowInput.value = settings.date_window || 'all';
  if (focusedElement !== relevanceModeInput) relevanceModeInput.value = settings.relevance_mode || 'balanced';
  autoRefreshInput.checked = Boolean(settings.auto_refresh_enabled);
  hideDuplicatesInput.checked = Boolean(settings.hide_duplicates);
}

function renderFeeds(feeds) {
  if (!feeds.length) {
    feedsListEl.innerHTML = '<p class="empty-state">Todavía no hay feeds.</p>';
    return;
  }
  feedsListEl.innerHTML = feeds.map(feed => `
    <div class="feed-row">
      <div>
        <strong>${escapeHtml(feed.name)}</strong>
        <div class="article-meta wrap-anywhere">${escapeHtml(feed.url)}</div>
      </div>
      <div class="feed-actions">
        <button class="secondary-btn" onclick="toggleFeed(${feed.id}, ${feed.is_enabled ? 'false' : 'true'})">${feed.is_enabled ? 'Pausar' : 'Activar'}</button>
        <button class="secondary-btn" onclick="removeFeed(${feed.id})">Borrar</button>
      </div>
    </div>
  `).join('');
}

function statusChip(status) {
  const labels = { included: 'Incluida', pending: 'Pendiente', excluded: 'Excluida' };
  return `<span class="status-chip status-${status}">${labels[status] || status}</span>`;
}

function renderTags(tags = []) {
  if (!Array.isArray(tags) || !tags.length) return '';
  return `<div class="tag-row">${tags.slice(0, 6).map(tag => `<span class="tag-chip">${escapeHtml(tag)}</span>`).join('')}</div>`;
}

function sectorMeta(article) {
  return article.display_sector === 'marcas_retail' ? '<span class="sector-chip">Marcas</span>' : '<span class="sector-chip general-chip">General</span>';
}

function renderArticles(articles) {
  if (!articles.length) {
    articlesContainer.innerHTML = '<div class="card empty-state">No hay noticias para este filtro.</div>';
    return;
  }
  const newIds = new Set(articles.map(a => a.id));
  articlesContainer.innerHTML = articles.map(article => {
    const isNew = !knownArticleIds.has(article.id);
    return `
      <article class="article-card ${isNew ? 'slide-in' : ''}">
        ${article.image_url ? `<img class="article-image" src="${escapeAttribute(article.image_url)}" alt="${escapeAttribute(article.title)}" />` : '<div class="article-image"></div>'}
        <div class="article-body">
          <div class="article-meta card-topline">
            <span>${escapeHtml(article.feed_name || 'Feed')}</span>
            ${sectorMeta(article)}
            <span>Híbrido ${Number(article.relevance_score || 0).toFixed(2)} · Sem ${Number(article.semantic_score || 0).toFixed(2)}</span>
          </div>
          <h3 class="article-title">${escapeHtml(article.title)}</h3>
          <p class="article-summary">${escapeHtml((article.summary || article.content || '').slice(0, 240))}</p>
          ${renderTags(article.match_tags)}
          <p class="article-rationale">${escapeHtml((article.rationale || 'Sin explicación').slice(0, 180))}</p>
          <div class="article-meta">
            <span>${formatDate(article.published_at || article.created_at)}</span>
            ${statusChip(article.status)}
          </div>
          <div class="status-actions">
            <button onclick="setArticleStatus(${article.id}, 'included')">Incluir</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'pending')">Pendiente</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'excluded')">Excluir</button>
            <button class="secondary-btn" onclick="showArticle(${article.id})">Ver</button>
          </div>
        </div>
      </article>
    `;
  }).join('');
  knownArticleIds = newIds;
}

function mapPointSize(count, maxCount) {
  return 18 + Math.round(24 * Math.sqrt((count || 1) / (maxCount || 1)));
}

function renderMapStats(totals = {}, yearLabel = 'Último con datos') {
  brandsMapStats.innerHTML = `
    <div class="stat-box"><span>Noticias</span><strong>${Number(totals.all_articles || 0)}</strong><small>Incl ${Number(totals.included || 0)} · Pend ${Number(totals.pending || 0)} · Excl ${Number(totals.excluded || 0)}</small></div>
    <div class="stat-box"><span>Países</span><strong>${Number(totals.countries || 0)}</strong><small>Con punto en mapa</small></div>
    <div class="stat-box"><span>En mapa</span><strong>${Number(totals.mapped_articles || 0)}</strong><small>Con país detectado</small></div>
    <div class="stat-box"><span>Ventana</span><strong>${escapeHtml(yearLabel)}</strong><small>Filtro actual</small></div>
  `;
}

function renderList(el, items, formatter, empty = 'Sin datos todavía.') {
  if (!items || !items.length) {
    el.innerHTML = `<div class="empty-mini wide">${escapeHtml(empty)}</div>`;
    return;
  }
  el.innerHTML = items.map(formatter).join('');
}

function renderMapLoading() {
  brandsMapCanvas.innerHTML = '<div class="map-overlay-empty">Cargando mapa…</div>';
}

function buildMapMarkup(data) {
  const points = Array.isArray(data.points) ? data.points : [];
  const maxCount = Math.max(...points.map(point => point.count || 0), 1);
  const markers = points.map(point => {
    const size = mapPointSize(point.count, maxCount);
    return `
      <button class="map-marker" style="left:${point.x_pct}%; top:${point.y_pct}%; width:${size}px; height:${size}px;" data-country="${escapeAttribute(point.country)}" data-article-ids="${escapeAttribute((point.article_ids || []).join(','))}" data-tooltip="${escapeAttribute(JSON.stringify(point))}" aria-label="${escapeAttribute(point.country)} ${point.count} incidentes">
        <span>${point.count}</span>
      </button>
    `;
  }).join('');
  const empty = !Number((data.totals || {}).incidents || 0) ? '<div class="map-overlay-empty">No hay datos suficientes para pintar el mapa todavía.</div>' : '';
  return `
    <div class="map-backdrop clean-map">
      <div class="map-panzoom" id="mapPanzoom">
        <div class="map-surface" id="mapSurface">
          <img class="map-base-image" src="${escapeAttribute(data.map_base_image || '/static/world-outline.png')}" alt="Mapa mundial" draggable="false" />
          <div class="map-layer">${markers}</div>
        </div>
      </div>
      <div class="map-hint">Rueda para zoom · Arrastra para mover · Doble clic para centrar</div>
      <div id="mapTooltip" class="map-tooltip hidden"></div>
      ${empty}
    </div>
  `;
}

function attachMapInteractions() {
  const stage = brandsMapCanvas.querySelector('.map-backdrop');
  const panzoom = brandsMapCanvas.querySelector('#mapPanzoom');
  const surface = brandsMapCanvas.querySelector('#mapSurface');
  const tooltip = brandsMapCanvas.querySelector('#mapTooltip');
  if (!stage || !panzoom || !surface || !tooltip) return;

  const state = { scale: 1, x: 0, y: 0, dragging: false, startX: 0, startY: 0, moved: false };

  const applyTransform = () => {
    surface.style.transform = `translate(${state.x}px, ${state.y}px) scale(${state.scale})`;
  };

  const resetView = () => {
    state.scale = 1;
    state.x = 0;
    state.y = 0;
    applyTransform();
  };

  const zoomAt = (clientX, clientY, delta) => {
    const rect = panzoom.getBoundingClientRect();
    const nextScale = Math.min(4.5, Math.max(0.85, state.scale * delta));
    if (nextScale === state.scale) return;
    const originX = clientX - rect.left;
    const originY = clientY - rect.top;
    const worldX = (originX - state.x) / state.scale;
    const worldY = (originY - state.y) / state.scale;
    state.scale = nextScale;
    state.x = originX - worldX * state.scale;
    state.y = originY - worldY * state.scale;
    applyTransform();
  };

  applyTransform();

  panzoom.addEventListener('wheel', event => {
    event.preventDefault();
    const delta = event.deltaY < 0 ? 1.12 : 0.9;
    zoomAt(event.clientX, event.clientY, delta);
  }, { passive: false });

  panzoom.addEventListener('mousedown', event => {
    if (event.button !== 0) return;
    state.dragging = true;
    state.moved = false;
    state.startX = event.clientX - state.x;
    state.startY = event.clientY - state.y;
    panzoom.classList.add('is-dragging');
  });

  window.addEventListener('mousemove', event => {
    if (!state.dragging) return;
    state.x = event.clientX - state.startX;
    state.y = event.clientY - state.startY;
    state.moved = true;
    tooltip.classList.add('hidden');
    applyTransform();
  });

  window.addEventListener('mouseup', () => {
    state.dragging = false;
    panzoom.classList.remove('is-dragging');
  });

  panzoom.addEventListener('dblclick', event => {
    event.preventDefault();
    resetView();
  });

  const moveTooltip = (event, marker) => {
    const payload = JSON.parse(marker.dataset.tooltip || '{}');
    const labels = (payload.labels || []).slice(0, 4).join(', ') || payload.latest_label || 'Sin objetivo inferido';
    const attacks = (payload.attack_types || []).slice(0, 3).join(', ') || payload.latest_attack_type || 'Incidente ciber';
    tooltip.innerHTML = `
      <strong>${escapeHtml(payload.country || 'País no inferido')}</strong>
      <span>${payload.count || 0} incidentes</span>
      <small>Objetivos: ${escapeHtml(labels)}</small>
      <small>Tipos: ${escapeHtml(attacks)}</small>
      <small>Última fecha: ${escapeHtml(formatDate(payload.latest_date || ''))}</small>
      <small>Fuente: ${escapeHtml(payload.latest_source || 'Fuente no inferida')}</small>
    `;
    tooltip.classList.remove('hidden');
    const bounds = stage.getBoundingClientRect();
    tooltip.style.left = `${Math.min(event.clientX - bounds.left + 14, bounds.width - 290)}px`;
    tooltip.style.top = `${Math.min(event.clientY - bounds.top + 14, bounds.height - 140)}px`;
  };

  stage.querySelectorAll('.map-marker').forEach(marker => {
    marker.addEventListener('mouseenter', event => moveTooltip(event, marker));
    marker.addEventListener('mousemove', event => moveTooltip(event, marker));
    marker.addEventListener('mouseleave', () => tooltip.classList.add('hidden'));
    marker.addEventListener('click', event => {
      event.preventDefault();
      if (state.moved) return;
      const articleId = (marker.dataset.articleIds || '').split(',').filter(Boolean)[0] || '';
      const row = brandsMapIncidents.querySelector(`[data-article-id="${CSS.escape(String(articleId))}"]`);
      if (row) row.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
  });
}

function renderMap(data) {
  currentMapData = data;
  mapSectionTitle.textContent = data.title || 'Mapa anual';
  mapSectionDescription.textContent = data.description || '';
  mapIncidentsTitle.textContent = data.map_type === 'marcas_retail' ? 'Últimos incidentes de Marcas' : 'Últimos incidentes generales';
  mapMethodology.textContent = data.methodology || '';

  const years = Array.isArray(data.available_years) && data.available_years.length ? data.available_years : ['latest', 'all'];
  const selectedMode = String(data.selected_mode || 'latest');
  const selectedValue = selectedMode === 'specific' ? String(data.year || 'latest') : selectedMode;
  currentMapYear = selectedValue;
  brandsMapYearSelect.innerHTML = years.map(year => {
    const value = String(year);
    const count = Number((data.year_counts || {})[value] || 0);
    let label = value;
    if (value === 'latest') label = `Último con datos${data.latest_populated_year ? ` · ${data.latest_populated_year}` : ''}`;
    else if (value === 'all') label = `Todos desde 2024${count ? ` · ${count}` : ''}`;
    else label = `${value}${count ? ` · ${count}` : ''}`;
    return `<option value="${escapeAttribute(value)}" ${value === selectedValue ? 'selected' : ''}>${escapeHtml(label)}</option>`;
  }).join('');

  const yearLabel = selectedValue === 'latest'
    ? `Último con datos · ${data.latest_populated_year || data.year || '—'}`
    : (selectedValue === 'all' ? '2024+' : String(data.year || selectedValue));
  renderMapStats(data.totals || {}, yearLabel);
  brandsMapCanvas.innerHTML = buildMapMarkup(data);
  renderList(brandsMapTopCountries, data.top_countries, item => `
    <div class="map-list-item">
      <strong>${escapeHtml(item.country)}</strong>
      <span>${item.count} incidentes</span>
      <small>${escapeHtml((item.labels || []).join(', ') || 'Sin objetivos inferidos')}</small>
    </div>
  `);
  renderList(brandsMapTopAttacks, data.top_attacks, item => `
    <div class="map-list-item compact">
      <strong>${escapeHtml(item.label)}</strong>
      <span>${item.count}</span>
    </div>
  `);
  renderList(brandsMapIncidents, data.incidents, item => `
    <article class="incident-row" data-article-id="${escapeAttribute(String(item.id || ''))}">
      <div>
        <div class="incident-badges">
          <span class="tag-chip country-badge">${escapeHtml(item.country || 'No inferido')}</span>
          <span class="tag-chip attack-badge">${escapeHtml(item.attack_type || 'Incidente ciber')}</span>
          <span class="tag-chip">${escapeHtml(item.label || 'Sin objetivo')}</span>
        </div>
        <h4>${escapeHtml(item.title)}</h4>
        <p>${escapeHtml(item.feed_name || item.source || 'Fuente no inferida')}</p>
      </div>
      <div class="incident-meta">
        <span>${escapeHtml(formatDate(item.published_at))}</span>
        <a class="button-link secondary-btn" href="${escapeAttribute(item.article_url)}" target="_blank" rel="noopener noreferrer">Abrir</a>
      </div>
    </article>
  `, 'Sin incidentes todavía.');
  attachMapInteractions();
}

async function loadState() {
  const state = await api('/api/state');
  renderStats(state.stats, state.feedback);
  renderFeeds(state.feeds);
  applySettingsToForm(state.settings || {});
  return state;
}

async function loadArticles() {
  const params = new URLSearchParams({ limit: '60', status: currentStatus, sector: currentSector });
  const payload = await api(`/api/articles?${params.toString()}`);
  renderArticles(payload.articles || []);
  return payload;
}

async function loadMap() {
  renderMapLoading();
  const params = new URLSearchParams({ sector: currentSector, status: currentStatus });
  if (currentMapYear && !['latest', 'all'].includes(String(currentMapYear))) params.set('year', String(currentMapYear));
  const data = await api(`/api/incidents-map?${params.toString()}`);
  renderMap(data);
  return data;
}

async function showArticle(articleId) {
  const article = await api(`/api/articles/${articleId}`);
  dialogContent.innerHTML = `
    <h2>${escapeHtml(article.title)}</h2>
    ${article.image_url ? `<img class="dialog-image" src="${escapeAttribute(article.image_url)}" alt="${escapeAttribute(article.title)}" />` : ''}
    <p><strong>Fuente:</strong> ${escapeHtml(article.feed_name || 'N/D')}</p>
    <p><strong>Fecha:</strong> ${escapeHtml(formatDate(article.published_at || article.created_at))}</p>
    <p><strong>Tags:</strong> ${(article.match_tags || []).map(escapeHtml).join(', ') || 'Sin tags'}</p>
    <p><strong>Score híbrido:</strong> ${Number(article.relevance_score || 0).toFixed(2)} · <strong>Semántico:</strong> ${Number(article.semantic_score || 0).toFixed(2)} · <strong>Feedback:</strong> ${Number(article.feedback_score || 0).toFixed(2)}</p>
    <p><strong>Explicación:</strong> ${escapeHtml(article.rationale || 'Sin explicación')}</p>
    <p>${escapeHtml(article.summary || '')}</p>
    <p>${escapeHtml(article.content || '')}</p>
    <p><strong>Artículo:</strong> <a href="${escapeAttribute(article.article_url)}" target="_blank" rel="noopener noreferrer">Abrir noticia</a></p>
  `;
  dialog.showModal();
}
window.showArticle = showArticle;

async function setArticleStatus(articleId, status) {
  await api(`/api/articles/${articleId}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  await Promise.all([loadState(), loadArticles(), loadMap()]);
}
window.setArticleStatus = setArticleStatus;

async function toggleFeed(feedId, is_enabled) {
  await api(`/api/feeds/${feedId}`, { method: 'PATCH', body: JSON.stringify({ is_enabled }) });
  await Promise.all([loadState(), loadArticles(), loadMap()]);
}
window.toggleFeed = toggleFeed;

async function removeFeed(feedId) {
  await api(`/api/feeds/${feedId}`, { method: 'DELETE' });
  await Promise.all([loadState(), loadArticles(), loadMap()]);
}
window.removeFeed = removeFeed;

function currentSettingsPayload(promptOnly = false) {
  if (promptOnly) return { prompt: promptInput.value };
  return {
    prompt: promptInput.value,
    poll_interval_seconds: Number(intervalInput.value),
    max_articles_per_feed: Number(maxArticlesInput.value),
    auto_refresh_enabled: autoRefreshInput.checked,
    date_window: dateWindowInput.value,
    relevance_mode: relevanceModeInput.value,
    hide_duplicates: hideDuplicatesInput.checked,
  };
}

async function saveSettings(promptOnly = false, source = 'manual') {
  if (saveInFlight) return;
  saveInFlight = true;
  saveSettingsBtn.disabled = true;
  const originalButtonText = saveSettingsBtn.textContent;
  saveSettingsBtn.textContent = source === 'manual' ? 'Guardando…' : 'Autoguardando…';
  setPromptStatus(source === 'manual' ? 'Guardando configuración…' : 'Autoguardando prompt…', 'progress');
  try {
    const result = await api('/api/settings', { method: 'PATCH', body: JSON.stringify(currentSettingsPayload(promptOnly)) });
    if (typeof currentSettingsPayload(promptOnly).prompt === 'string') {
      lastServerPrompt = promptInput.value;
      promptDirty = false;
      persistPromptDraft('');
    }
    applySettingsToForm(result.settings || {});
    setPromptStatus('Configuración guardada.', 'success');
    if (!promptOnly) await Promise.all([loadState(), loadArticles(), loadMap()]);
  } catch (error) {
    setPromptStatus(`Error al guardar: ${error.message}`, 'error');
    throw error;
  } finally {
    saveInFlight = false;
    saveSettingsBtn.disabled = false;
    saveSettingsBtn.textContent = originalButtonText;
  }
}

async function addFeed() {
  const payload = {
    name: document.getElementById('feedNameInput').value || null,
    url: document.getElementById('feedUrlInput').value,
  };
  await api('/api/feeds', { method: 'POST', body: JSON.stringify(payload) });
  document.getElementById('feedNameInput').value = '';
  document.getElementById('feedUrlInput').value = '';
  await Promise.all([loadState(), loadArticles(), loadMap()]);
}

async function refreshNow() {
  setBusy(true, 'Actualizando feeds y recalculando…');
  try {
    await api('/api/refresh', { method: 'POST' });
    await Promise.all([loadState(), loadArticles(), loadMap()]);
  } finally {
    setBusy(false);
  }
}

saveSettingsBtn.addEventListener('click', () => saveSettings(false, 'manual'));
document.getElementById('addFeedBtn').addEventListener('click', addFeed);
document.getElementById('refreshBtn').addEventListener('click', refreshNow);
brandsMapDownloadBtn.addEventListener('click', () => {
  if (!currentMapData) return;
  const blob = new Blob([JSON.stringify(currentMapData, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `cyberrad_${currentSector}_${currentMapYear || 'latest'}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 500);
});
brandsMapYearSelect.addEventListener('change', async () => {
  currentMapYear = brandsMapYearSelect.value || 'latest';
  await loadMap();
});

promptInput.addEventListener('input', () => {
  promptDirty = promptInput.value !== lastServerPrompt;
  persistPromptDraft(promptInput.value);
  setPromptStatus(promptDirty ? 'Borrador local guardado.' : 'Prompt sincronizado con el servidor.', promptDirty ? 'warning' : 'success');
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => {
    if (promptDirty) saveSettings(true, 'autosave').catch(console.error);
  }, 900);
});

promptInput.addEventListener('blur', () => {
  if (promptDirty) saveSettings(true, 'autosave').catch(console.error);
});

window.addEventListener('beforeunload', () => persistPromptDraft(promptInput.value));
window.addEventListener('keydown', event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
    event.preventDefault();
    saveSettings(false, 'manual').catch(console.error);
  }
});

document.querySelectorAll('.status-filter').forEach(button => {
  button.addEventListener('click', async () => {
    document.querySelectorAll('.status-filter').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    currentStatus = button.dataset.status;
    await Promise.all([loadArticles(), loadMap()]);
  });
});

document.querySelectorAll('.sector-filter').forEach(button => {
  button.addEventListener('click', async () => {
    document.querySelectorAll('.sector-filter').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    currentSector = button.dataset.sector || 'general';
    currentMapYear = 'latest';
    await Promise.all([loadArticles(), loadMap()]);
  });
});

async function boot() {
  setBusy(true, 'Cargando CyberRad…');
  try {
    const state = await loadState();
    lastServerPrompt = state.settings?.prompt || '';
    const localDraft = loadLocalPromptDraft();
    if (localDraft && localDraft !== lastServerPrompt) {
      promptInput.value = localDraft;
      promptDirty = true;
      setPromptStatus('Borrador local recuperado.', 'warning');
    } else {
      setPromptStatus('Prompt sincronizado con el servidor.', 'success');
    }
    await Promise.all([loadArticles(), loadMap()]);
  } finally {
    setBusy(false);
  }
  setInterval(() => Promise.all([loadState(), loadArticles(), loadMap()]).catch(console.error), AUTO_RELOAD_MS);
  setInterval(() => loadState().catch(console.error), STATE_POLL_MS);
}

boot().catch(error => {
  console.error(error);
  articlesContainer.innerHTML = `<div class="card empty-state">Error al cargar: ${escapeHtml(error.message)}</div>`;
  setPromptStatus(`Error al iniciar: ${error.message}`, 'error');
  setBusy(false);
});

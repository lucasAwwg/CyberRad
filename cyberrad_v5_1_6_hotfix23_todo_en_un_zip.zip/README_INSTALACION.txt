Este ZIP incluye el proyecto completo hotfix23 y el patch, todo junto en un solo archivo.
Descomprime y entra en la carpeta principal para ejecutar docker-compose.kali.yml.

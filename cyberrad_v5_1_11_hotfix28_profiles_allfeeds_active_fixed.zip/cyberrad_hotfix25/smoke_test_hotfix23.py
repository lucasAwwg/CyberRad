from app.rss import classify_article, duplicate_resolution_priority

PROMPT = 'ransomware OR malware OR phishing OR data breach OR cyberattack OR vulnerability OR exploit OR threat actor OR incident response OR credential stuffing OR account takeover'
FEEDLY_NAME = 'Feedly - BleepingComputer'
FEEDLY_URL = 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.bleepingcomputer.com%2Ffeed%2F'

NEGATIVE_CASES = [
    ('Edt drives identity driven storytelling in new campaign', ''),
    ('Russian missiles and drones bombard Ukraine overnight', ''),
    ('Woman dies after being attacked by dogs at house', ''),
    ('The fitness hack that changed my morning routine', ''),
]

POSITIVE_CASES = [
    ('Adidas warns customers after credential stuffing attack hits ecommerce accounts', 'The sportswear brand said attackers targeted customer accounts and forced password resets.'),
    ('CISA adds CVE-2026-12345 to KEV after active exploitation', 'The vulnerability is actively exploited in the wild and requires patching.'),
]

for title, summary in NEGATIVE_CASES:
    score, status, rationale, *_ = classify_article(PROMPT, title, summary, '', '2026-04-16T10:00:00+00:00', relevance_mode='balanced', feed_name=FEEDLY_NAME, feed_url=FEEDLY_URL, article_url='https://example.com/article')
    assert status == 'excluded', (title, status, score, rationale)

for title, summary in POSITIVE_CASES:
    score, status, rationale, *_ = classify_article(PROMPT, title, summary, '', '2026-04-16T10:00:00+00:00', relevance_mode='balanced', feed_name=FEEDLY_NAME, feed_url=FEEDLY_URL, article_url='https://example.com/article')
    assert status in {'included', 'pending'}, (title, status, score, rationale)

feedly_article = {
    'feed_name': FEEDLY_NAME,
    'feed_url': FEEDLY_URL,
    'article_url': 'https://www.bleepingcomputer.com/news/security/adidas-warning/',
    'hybrid_score': 0.61,
    'relevance_score': 0.61,
    'published_at': '2026-04-16T09:00:00+00:00',
    'image_url': 'https://img.example.com/a.jpg',
}
google_article = {
    'feed_name': 'Google News - Retail Cyber',
    'feed_url': 'https://news.google.com/rss/search?q=retail+cyber',
    'article_url': 'https://news.example.com/adidas-warning/',
    'hybrid_score': 0.64,
    'relevance_score': 0.64,
    'published_at': '2026-04-16T10:00:00+00:00',
    'image_url': 'https://img.example.com/b.jpg',
}
assert duplicate_resolution_priority(feedly_article) > duplicate_resolution_priority(google_article)
print('Hotfix23 smoke tests: OK')

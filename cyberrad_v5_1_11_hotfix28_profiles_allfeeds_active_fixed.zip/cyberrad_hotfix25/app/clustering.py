from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .entities import build_entity_text
from .rss import duplicate_resolution_priority, parse_datetime_to_dt


class UnionFind:
    def __init__(self, items: list[int]):
        self.parent = {item: item for item in items}

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra


def _doc_text(article: dict[str, Any]) -> str:
    entities = article.get('entities') or {}
    return ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
        ' '.join(article.get('match_tags') or []),
        build_entity_text(entities),
    ])


def _dominant_label(cluster_articles: list[dict[str, Any]]) -> str:
    cves = Counter()
    vendors = Counter()
    products = Counter()
    themes = Counter()
    for article in cluster_articles:
        entities = article.get('entities') or {}
        cves.update(entities.get('cves') or [])
        vendors.update(entities.get('vendors') or [])
        products.update(entities.get('products') or [])
        themes.update((entities.get('tags') or []) + (article.get('match_tags') or []))
    if cves:
        return cves.most_common(1)[0][0]
    if products and vendors:
        return f"{vendors.most_common(1)[0][0]} / {products.most_common(1)[0][0]}"
    if products:
        return products.most_common(1)[0][0]
    if vendors:
        return vendors.most_common(1)[0][0]
    if themes:
        return themes.most_common(1)[0][0]
    return 'Cobertura relacionada'


def _days_gap(a: dict[str, Any], b: dict[str, Any]) -> float:
    da = parse_datetime_to_dt(a.get('published_at')).astimezone(timezone.utc)
    db = parse_datetime_to_dt(b.get('published_at')).astimezone(timezone.utc)
    return abs((da - db).total_seconds()) / 86400


def _cluster_rank_key(article: dict[str, Any]) -> tuple[float, float, float]:
    published_ts = parse_datetime_to_dt(article.get('published_at')).astimezone(timezone.utc).timestamp()
    return (duplicate_resolution_priority(article), float(article.get('relevance_score') or 0.0), published_ts)


def assign_clusters(articles: list[dict[str, Any]]) -> dict[int, dict[str, Any]]:
    if not articles:
        return {}
    ids = [article['id'] for article in articles if article.get('id') is not None]
    if not ids:
        return {}
    docs = [_doc_text(article) for article in articles]
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True)
    matrix = vectorizer.fit_transform(docs)
    similarity = cosine_similarity(matrix)
    dup_uf = UnionFind(ids)
    campaign_uf = UnionFind(ids)
    id_to_index = {article['id']: idx for idx, article in enumerate(articles)}
    for i, article_a in enumerate(articles):
        ent_a = article_a.get('entities') or {}
        cves_a = set(ent_a.get('cves') or [])
        themes_a = set((ent_a.get('tags') or []) + (article_a.get('match_tags') or []))
        shared_a = set((ent_a.get('vendors') or []) + (ent_a.get('products') or []) + (ent_a.get('malware_families') or []) + (ent_a.get('actors') or []))
        for j in range(i + 1, len(articles)):
            article_b = articles[j]
            sim = float(similarity[i][j])
            ent_b = article_b.get('entities') or {}
            cves_b = set(ent_b.get('cves') or [])
            themes_b = set((ent_b.get('tags') or []) + (article_b.get('match_tags') or []))
            shared_b = set((ent_b.get('vendors') or []) + (ent_b.get('products') or []) + (ent_b.get('malware_families') or []) + (ent_b.get('actors') or []))
            shared_cves = cves_a & cves_b
            shared_entities = shared_a & shared_b
            shared_themes = themes_a & themes_b
            gap = _days_gap(article_a, article_b)
            if shared_cves and (sim >= 0.30 or gap <= 14):
                dup_uf.union(article_a['id'], article_b['id'])
            elif sim >= 0.80 and (shared_entities or shared_themes or gap <= 3):
                dup_uf.union(article_a['id'], article_b['id'])
            if sim >= 0.38 and (shared_cves or len(shared_entities) >= 1 or len(shared_themes) >= 2):
                campaign_uf.union(article_a['id'], article_b['id'])
            elif sim >= 0.52 and gap <= 10:
                campaign_uf.union(article_a['id'], article_b['id'])
    duplicate_groups = defaultdict(list)
    campaign_groups = defaultdict(list)
    for article in articles:
        duplicate_groups[dup_uf.find(article['id'])].append(article)
        campaign_groups[campaign_uf.find(article['id'])].append(article)
    results: dict[int, dict[str, Any]] = {}
    for _, cluster_articles in duplicate_groups.items():
        if len(cluster_articles) <= 1:
            continue
        label = _dominant_label(cluster_articles)
        group_id = f"dup:{label}"
        ordered = sorted(cluster_articles, key=_cluster_rank_key, reverse=True)
        for rank, article in enumerate(ordered, start=1):
            results.setdefault(article['id'], {})['duplicate_group'] = group_id
            results[article['id']]['duplicate_rank'] = rank
    for _, cluster_articles in campaign_groups.items():
        if len(cluster_articles) <= 1:
            continue
        label = _dominant_label(cluster_articles)
        cluster_id = f"campaign:{label}"
        for article in cluster_articles:
            results.setdefault(article['id'], {})['campaign_cluster'] = cluster_id
    return results

from app.rss import classify_article, duplicate_resolution_priority, extract_image_from_html_fragment, source_profile
from app.incident_map import article_relevance_profile
from app.main import _balanced_source_mix

PROMPT = 'ransomware OR malware OR phishing OR data breach OR cyberattack OR vulnerability OR exploit OR threat actor OR incident response OR credential stuffing OR account takeover'
FEEDLY_NAME = 'Feedly - BleepingComputer'
FEEDLY_URL = 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.bleepingcomputer.com%2Ffeed%2F'
GOOGLE_NAME = 'Google News - AP Retail Cyber'
GOOGLE_URL = 'https://news.google.com/rss/search?q=retail+cyber'

NEGATIVE_CASES = [
    ('Russian missiles and drones bombard Ukraine in hourslong attack', ''),
    ('Woman dies after being attacked by dogs at house', ''),
    ('Edt drives identity driven storytelling in new campaign', ''),
    ('The fitness hack that changed my morning routine', ''),
]

POSITIVE_CASES = [
    ('Nike warns customers after credential stuffing attack on ecommerce accounts', 'The retailer forced password resets after attackers targeted customer accounts.', True),
    ('CISA warns of actively exploited CVE in Fortinet appliances', 'A security advisory says attackers are exploiting the vulnerability in the wild.', False),
]

for title, summary in NEGATIVE_CASES:
    score, status, rationale, *_ = classify_article(
        PROMPT, title, summary, '', '2026-04-16T10:00:00+00:00',
        relevance_mode='balanced', feed_name=GOOGLE_NAME, feed_url=GOOGLE_URL, article_url='https://example.com/article'
    )
    profile = article_relevance_profile({
        'title': title, 'summary': summary, 'content': '', 'feed_name': GOOGLE_NAME, 'feed_url': GOOGLE_URL,
        'article_url': 'https://example.com/article', 'match_tags': [], 'sector_categories': [],
        'relevance_score': score, 'semantic_score': score,
    })
    assert status == 'excluded', (title, status, score, rationale)
    assert profile['general_relevant'] is False, (title, profile)

for title, summary, is_brand in POSITIVE_CASES:
    score, status, rationale, *_ = classify_article(
        PROMPT, title, summary, '', '2026-04-16T10:00:00+00:00',
        relevance_mode='balanced', feed_name=FEEDLY_NAME, feed_url=FEEDLY_URL, article_url='https://example.com/article'
    )
    profile = article_relevance_profile({
        'title': title, 'summary': summary, 'content': '', 'feed_name': FEEDLY_NAME, 'feed_url': FEEDLY_URL,
        'article_url': 'https://example.com/article', 'match_tags': [], 'sector_categories': [],
        'relevance_score': score, 'semantic_score': score,
    })
    assert status in {'included', 'pending'}, (title, status, score, rationale)
    assert profile['general_relevant'] is True, (title, profile)
    if is_brand:
        assert profile['marcas_relevant'] is True, (title, profile)

feedly_article = {
    'feed_name': FEEDLY_NAME,
    'feed_url': FEEDLY_URL,
    'article_url': 'https://www.bleepingcomputer.com/news/security/nike-warning/',
    'hybrid_score': 0.61,
    'relevance_score': 0.61,
    'published_at': '2026-04-16T09:00:00+00:00',
    'image_url': 'https://img.example.com/a.jpg',
}
google_article = {
    'feed_name': GOOGLE_NAME,
    'feed_url': GOOGLE_URL,
    'article_url': 'https://apnews.com/story/nike-warning/',
    'hybrid_score': 0.64,
    'relevance_score': 0.64,
    'published_at': '2026-04-16T10:00:00+00:00',
    'image_url': 'https://img.example.com/b.jpg',
}
assert duplicate_resolution_priority(feedly_article) > duplicate_resolution_priority(google_article)

sample = []
for i in range(5):
    sample.append({
        'id': i + 1,
        'feed_name': GOOGLE_NAME,
        'feed_url': GOOGLE_URL,
        'article_url': f'https://apnews.com/g{i}',
        'published_at': '2026-04-16T10:00:00+00:00',
        'relevance_score': 0.70 - i * 0.01,
        'semantic_score': 0.70 - i * 0.01,
        'hybrid_score': 0.70 - i * 0.01,
    })
for i in range(3):
    sample.append({
        'id': 100 + i,
        'feed_name': FEEDLY_NAME,
        'feed_url': FEEDLY_URL,
        'article_url': f'https://bleepingcomputer.com/f{i}',
        'published_at': '2026-04-16T11:00:00+00:00',
        'relevance_score': 0.62 - i * 0.01,
        'semantic_score': 0.62 - i * 0.01,
        'hybrid_score': 0.62 - i * 0.01,
    })
ordered = _balanced_source_mix(sorted(sample, key=lambda x: x['relevance_score'], reverse=True), sector='general')
families = [source_profile(a['feed_name'], a['feed_url'], a['article_url'])['source_family'] for a in ordered[:4]]
assert families.count('feedly') >= 2, families

fragment = '<meta property="og:image" content="https://cdn.example.com/images/story.jpg" /><img src="https://cdn.example.com/images/story.jpg" />'
assert extract_image_from_html_fragment(fragment, 'https://example.com/article') == 'https://cdn.example.com/images/story.jpg'
print('Hotfix24 smoke tests: OK')

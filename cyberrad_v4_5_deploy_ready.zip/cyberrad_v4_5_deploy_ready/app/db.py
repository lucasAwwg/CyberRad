from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import unquote, urlparse

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / 'cyberrad_v4.db'

DEFAULT_SETTINGS = {
    'prompt': '',
    'poll_interval_seconds': '300',
    'max_articles_per_feed': '20',
    'auto_refresh_enabled': '1',
    'date_window': 'all',
    'relevance_mode': 'balanced',
    'hide_duplicates': '1',
    'semantic_reranking': '1',
    'feedback_learning': '1',
}


DEFAULT_FEED_URLS = ['https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.bleepingcomputer.com%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fadvisories.feedly.com%2Fcisa%2FexploitedCve%2Ffeed.json', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fnvd.nist.gov%2Fdownload%2Fnvd-rss.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.us-cert.gov%2Fcurrent%2Findex.rdf', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.incibe.es%2Fincibe-cert%2Falerta-temprana%2Favisos%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.ninjaone.com%2Fblog%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fblogs.technet.com%2Fb%2Ftrustworthycomputing%2Frss.aspx', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.crowdstrike.com%2Fblog%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.cisecurity.org%2Ffeed%2Fadvisories', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fcybersecuritynews.es%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fwww.darkreading.com%2Frss%2Fall.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fstatus.duo.com%2Fhistory.rss', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fcommunity.fortinet.com%2Ftpykb84852%2Frss%2Fboard%3Fboard.id%3DTKB20', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fepvuln.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fir.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Foutbreakalert.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fthreatsignal.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fipsdatabase.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fisdb.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fotips.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Findsec.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffilestore.fortinet.com%2Ffortiguard%2Frss%2Fwebsecurity.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fsupport.fortinet.com%2Frss%2Ffirmware.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fadvisories.feedly.com%2Fgoogle%2Fchrome%2Ffeed.json', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fcloud.google.com%2Ffeeds%2Fgoogle-cloud-security-bulletins.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fgoogleonlinesecurity.blogspot.com%2Fatom.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fhackmanac.com%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.incibe.es%2Fincibe-cert%2Fblog%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Ffeedproxy.feedly.com%2Fe9051d2d-e920-4448-b985-c1e1ec259092', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fblogs.msdn.com%2Fsdl%2Frss.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fadvisories.feedly.com%2Fmicrosoft%2Ffeed.json', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.microsoft.com%2Fen-us%2Fsecurity%2Fblog%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fblogs.technet.com%2Fmmpc%2Frss.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.ninjaone.com%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fonapsis.com%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fblog.documentfoundation.org%2Fblog%2Fcategory%2Fpress-releases%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fgrafana.com%2Fsecurity%2Fsecurity-advisories%2Findex.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fgrafana.com%2Ftags%2Fsecurity%2Findex.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.synology.com%2Fapi%2Frssfeed%2Fsecurity%2Fen-global', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fblog.documentfoundation.org%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fstatus.teamviewer.com%2Fhistory.rss', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Ffeeds.feedburner.com%2Fduosecurity', 'https://feedly.com/i/subscription/content/feed%2Fhttp%3A%2F%2Fthehackernews.com%2Ffeeds%2Fposts%2Fdefault', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fwww.microsoft.com%2Fsecurity%2Fblog%2Ftag%2Fmicrosoft-security-intelligence%2Ffeed%2F', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fubuntu.com%2Fblog%2Ffeed', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fubuntu.com%2Fsecurity%2Fnotices%2Fatom.xml', 'https://feedly.com/i/subscription/content/feed%2Fhttps%3A%2F%2Fcommunity.qualys.com%2Fblogs%2Fsecuritylabs%2Ffeeds%2Fposts']
KNOWN_FEED_NAMES = {'www.bleepingcomputer.com/feed/': 'BleepingComputer', 'advisories.feedly.com/cisa/exploitedCve/feed.json': 'CISA Known Exploited Vulnerabilities', 'nvd.nist.gov/download/nvd-rss.xml': 'NVD RSS', 'www.us-cert.gov/current/index.rdf': 'US-CERT Current Activity', 'www.incibe.es/incibe-cert/alerta-temprana/avisos/feed': 'INCIBE Avisos', 'www.ninjaone.com/blog/feed/': 'NinjaOne Blog', 'blogs.technet.com/b/trustworthycomputing/rss.aspx': 'Microsoft Trustworthy Computing', 'www.crowdstrike.com/blog/feed': 'CrowdStrike Blog', 'www.cisecurity.org/feed/advisories': 'CIS Advisories', 'cybersecuritynews.es/feed/': 'CyberSecurityNews.es', 'www.darkreading.com/rss/all.xml': 'Dark Reading', 'status.duo.com/history.rss': 'Duo Status', 'community.fortinet.com/tpykb84852/rss/board?board.id=TKB20': 'Fortinet Community', 'filestore.fortinet.com/fortiguard/rss/epvuln.xml': 'FortiGuard EPVuln', 'filestore.fortinet.com/fortiguard/rss/ir.xml': 'FortiGuard IR', 'filestore.fortinet.com/fortiguard/rss/outbreakalert.xml': 'FortiGuard Outbreak Alert', 'filestore.fortinet.com/fortiguard/rss/threatsignal.xml': 'FortiGuard Threat Signal', 'filestore.fortinet.com/fortiguard/rss/ipsdatabase.xml': 'FortiGuard IPS Database', 'filestore.fortinet.com/fortiguard/rss/isdb.xml': 'FortiGuard ISDB', 'filestore.fortinet.com/fortiguard/rss/otips.xml': 'FortiGuard OTIPS', 'filestore.fortinet.com/fortiguard/rss/indsec.xml': 'FortiGuard Industrial Security', 'filestore.fortinet.com/fortiguard/rss/websecurity.xml': 'FortiGuard Web Security', 'support.fortinet.com/rss/firmware.xml': 'Fortinet Firmware', 'advisories.feedly.com/google/chrome/feed.json': 'Google Chrome Advisories', 'cloud.google.com/feeds/google-cloud-security-bulletins.xml': 'Google Cloud Security Bulletins', 'googleonlinesecurity.blogspot.com/atom.xml': 'Google Online Security Blog', 'hackmanac.com/feed': 'Hackmageddon / Hackmanac', 'www.incibe.es/incibe-cert/blog/feed': 'INCIBE Blog', 'feedproxy.feedly.com/e9051d2d-e920-4448-b985-c1e1ec259092': 'Feedly Proxy Feed', 'blogs.msdn.com/sdl/rss.xml': 'Microsoft SDL Blog', 'advisories.feedly.com/microsoft/feed.json': 'Microsoft Advisories', 'www.microsoft.com/en-us/security/blog/feed/': 'Microsoft Security Blog', 'blogs.technet.com/mmpc/rss.xml': 'Microsoft Malware Protection Center', 'www.ninjaone.com/feed/': 'NinjaOne Feed', 'onapsis.com/feed/': 'Onapsis', 'blog.documentfoundation.org/blog/category/press-releases/feed/': 'Document Foundation Press Releases', 'grafana.com/security/security-advisories/index.xml': 'Grafana Security Advisories', 'grafana.com/tags/security/index.xml': 'Grafana Security Tag', 'www.synology.com/api/rssfeed/security/en-global': 'Synology Security', 'blog.documentfoundation.org/feed/': 'Document Foundation Blog', 'status.teamviewer.com/history.rss': 'TeamViewer Status', 'feeds.feedburner.com/duosecurity': 'Duo Security Blog', 'thehackernews.com/feeds/posts/default': 'The Hacker News', 'www.microsoft.com/security/blog/tag/microsoft-security-intelligence/feed/': 'Microsoft Security Intelligence', 'ubuntu.com/blog/feed': 'Ubuntu Blog', 'ubuntu.com/security/notices/atom.xml': 'Ubuntu Security Notices', 'community.qualys.com/blogs/securitylabs/feeds/posts': 'Qualys Security Labs'}


def row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    data = {k: row[k] for k in row.keys()}
    tags = data.get('match_tags')
    if isinstance(tags, str) and tags:
        try:
            data['match_tags'] = json.loads(tags)
        except Exception:
            data['match_tags'] = [item.strip() for item in tags.split('|') if item.strip()]
    else:
        data['match_tags'] = []
    entities = data.get('entities_json')
    if isinstance(entities, str) and entities:
        try:
            data['entities'] = json.loads(entities)
        except Exception:
            data['entities'] = {}
    else:
        data['entities'] = {}
    return data


@contextmanager
def get_conn() -> Iterable[sqlite3.Connection]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


SCHEMA = '''
CREATE TABLE IF NOT EXISTS feeds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    url TEXT NOT NULL UNIQUE,
    is_enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unique_key TEXT NOT NULL UNIQUE,
    feed_id INTEGER,
    feed_name TEXT,
    feed_url TEXT,
    title TEXT NOT NULL,
    article_url TEXT NOT NULL,
    feedly_url TEXT,
    summary TEXT,
    content TEXT,
    published_at TEXT,
    image_url TEXT,
    video_url TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    status_origin TEXT NOT NULL DEFAULT 'auto',
    match_tags TEXT,
    cluster_key TEXT,
    duplicate_group TEXT,
    duplicate_rank INTEGER DEFAULT 1,
    campaign_cluster TEXT,
    entities_json TEXT,
    semantic_score REAL NOT NULL DEFAULT 0,
    feedback_score REAL NOT NULL DEFAULT 0,
    relevance_score REAL NOT NULL DEFAULT 0,
    rationale TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(feed_id) REFERENCES feeds(id)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS feedback_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL,
    previous_status TEXT,
    new_status TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(article_id) REFERENCES articles(id)
);

CREATE INDEX IF NOT EXISTS idx_articles_created_at ON articles(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_cluster_key ON articles(cluster_key);
'''


def normalize_feed_url(url: str) -> str:
    value = (url or '').strip()
    if not value:
        return ''
    parsed = urlparse(value)
    marker = '/i/subscription/content/feed%2F'
    if parsed.netloc.lower().endswith('feedly.com') and marker in parsed.path:
        raw = parsed.path.split(marker, 1)[1]
        return unquote(raw).strip()
    if parsed.netloc.lower().endswith('feedly.com') and '/i/subscription/content/' in parsed.path:
        tail = parsed.path.rsplit('/', 1)[-1]
        if tail.startswith('feed%2F'):
            return unquote(tail[len('feed%2F'):]).strip()
    return value


def derive_feed_name(url: str) -> str:
    normalized = normalize_feed_url(url)
    parsed = urlparse(normalized)
    key = f"{parsed.netloc}{parsed.path}"
    if parsed.query:
        key = f"{key}?{parsed.query}"
    if key in KNOWN_FEED_NAMES:
        return KNOWN_FEED_NAMES[key]
    host = parsed.netloc.replace('www.', '')
    if not host:
        return 'Feed RSS'
    path = parsed.path.strip('/').split('/')
    host_title = host.split(':', 1)[0].split('.')[0].replace('-', ' ').title()
    if path and path[0]:
        suffix = path[-1].replace('-', ' ').replace('_', ' ')
        suffix = suffix.replace('.xml', '').replace('.rss', '').replace('.rdf', '').replace('.json', '')
        suffix = suffix.replace('.aspx', '').strip().title()
        if suffix and suffix.lower() not in {'feed', 'atom', 'rss', 'index'}:
            return f'{host_title} - {suffix}'
    return host_title


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, definition: str) -> None:
    existing = {row['name'] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in existing:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        _ensure_column(conn, 'articles', 'status_origin', "TEXT NOT NULL DEFAULT 'auto'")
        _ensure_column(conn, 'articles', 'match_tags', 'TEXT')
        _ensure_column(conn, 'articles', 'cluster_key', 'TEXT')
        _ensure_column(conn, 'articles', 'duplicate_group', 'TEXT')
        _ensure_column(conn, 'articles', 'duplicate_rank', 'INTEGER DEFAULT 1')
        _ensure_column(conn, 'articles', 'campaign_cluster', 'TEXT')
        _ensure_column(conn, 'articles', 'entities_json', 'TEXT')
        _ensure_column(conn, 'articles', 'semantic_score', 'REAL NOT NULL DEFAULT 0')
        _ensure_column(conn, 'articles', 'feedback_score', 'REAL NOT NULL DEFAULT 0')
        conn.execute("CREATE TABLE IF NOT EXISTS feedback_events (id INTEGER PRIMARY KEY AUTOINCREMENT, article_id INTEGER NOT NULL, previous_status TEXT, new_status TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(article_id) REFERENCES articles(id))")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_duplicate_group ON articles(duplicate_group)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_campaign_cluster ON articles(campaign_cluster)")
        for key, value in DEFAULT_SETTINGS.items():
            conn.execute('INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)', (key, value))


def list_feeds() -> list[dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute('SELECT * FROM feeds ORDER BY is_enabled DESC, name COLLATE NOCASE ASC').fetchall()
    return [row_to_dict(row) for row in rows]


def add_feed(name: str | None, url: str) -> dict[str, Any]:
    normalized_url = normalize_feed_url(url)
    final_name = (name or '').strip() or derive_feed_name(normalized_url)
    with get_conn() as conn:
        conn.execute('INSERT OR IGNORE INTO feeds(name, url, is_enabled) VALUES(?, ?, 1)', (final_name, normalized_url))
        row = conn.execute('SELECT * FROM feeds WHERE url = ?', (normalized_url,)).fetchone()
    return row_to_dict(row) or {}


def toggle_feed(feed_id: int, is_enabled: bool) -> dict[str, Any] | None:
    with get_conn() as conn:
        conn.execute('UPDATE feeds SET is_enabled = ? WHERE id = ?', (1 if is_enabled else 0, feed_id))
        row = conn.execute('SELECT * FROM feeds WHERE id = ?', (feed_id,)).fetchone()
    return row_to_dict(row)


def delete_feed(feed_id: int) -> None:
    with get_conn() as conn:
        conn.execute('DELETE FROM feeds WHERE id = ?', (feed_id,))


def get_settings() -> dict[str, Any]:
    with get_conn() as conn:
        rows = conn.execute('SELECT key, value FROM settings').fetchall()
    settings = {row['key']: row['value'] for row in rows}
    merged = DEFAULT_SETTINGS | settings
    merged['poll_interval_seconds'] = int(merged['poll_interval_seconds'])
    merged['max_articles_per_feed'] = int(merged['max_articles_per_feed'])
    merged['auto_refresh_enabled'] = str(merged['auto_refresh_enabled']) == '1'
    merged['hide_duplicates'] = str(merged['hide_duplicates']) == '1'
    merged['semantic_reranking'] = str(merged.get('semantic_reranking', '1')) == '1'
    merged['feedback_learning'] = str(merged.get('feedback_learning', '1')) == '1'
    return merged


def update_settings(changes: dict[str, Any]) -> dict[str, Any]:
    allowed = {'prompt', 'poll_interval_seconds', 'max_articles_per_feed', 'auto_refresh_enabled', 'date_window', 'relevance_mode', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'}
    with get_conn() as conn:
        for key, value in changes.items():
            if key not in allowed or value is None:
                continue
            if key in {'auto_refresh_enabled', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'}:
                value = '1' if bool(value) else '0'
            else:
                value = str(value)
            conn.execute('''
                INSERT INTO settings(key, value) VALUES(?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
            ''', (key, value))
    return get_settings()


def upsert_articles(articles: list[dict[str, Any]]) -> int:
    inserted = 0
    with get_conn() as conn:
        for article in articles:
            exists = conn.execute("SELECT id, status, COALESCE(status_origin, 'auto') AS status_origin FROM articles WHERE unique_key = ?", (article['unique_key'],)).fetchone()
            if exists:
                if exists['status_origin'] == 'manual':
                    conn.execute('''
                        UPDATE articles
                        SET feed_id = ?, feed_name = ?, feed_url = ?, title = ?, article_url = ?, feedly_url = ?,
                            summary = ?, content = ?, published_at = ?, image_url = ?, video_url = ?,
                            match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?, entities_json = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE unique_key = ?
                    ''', (
                        article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'),
                        article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'),
                        article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''), article['unique_key'],
                    ))
                else:
                    conn.execute('''
                        UPDATE articles
                        SET feed_id = ?, feed_name = ?, feed_url = ?, title = ?, article_url = ?, feedly_url = ?,
                            summary = ?, content = ?, published_at = ?, image_url = ?, video_url = ?, status = ?, status_origin = ?,
                            match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?, entities_json = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE unique_key = ?
                    ''', (
                        article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'),
                        article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'),
                        article.get('status', 'pending'), article.get('status_origin', 'auto'), article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''), article['unique_key'],
                    ))
                continue
            conn.execute('''
                INSERT INTO articles(
                    unique_key, feed_id, feed_name, feed_url, title, article_url, feedly_url,
                    summary, content, published_at, image_url, video_url, status,
                    status_origin, match_tags, cluster_key, duplicate_group, duplicate_rank, campaign_cluster, entities_json, semantic_score, feedback_score, relevance_score, rationale
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                article['unique_key'], article.get('feed_id'), article.get('feed_name'), article.get('feed_url'), article.get('title'), article.get('article_url'), article.get('feedly_url'), article.get('summary'), article.get('content'), article.get('published_at'), article.get('image_url'), article.get('video_url'), article.get('status', 'pending'), article.get('status_origin', 'auto'), article.get('match_tags', '[]'), article.get('cluster_key'), article.get('duplicate_group'), article.get('duplicate_rank', 1), article.get('campaign_cluster'), article.get('entities_json'), article.get('semantic_score', 0), article.get('feedback_score', 0), article.get('relevance_score', 0), article.get('rationale', ''),
            ))
            inserted += 1
    return inserted


def _dedupe_rows(rows: list[sqlite3.Row]) -> list[sqlite3.Row]:
    settings = get_settings()
    if not settings.get('hide_duplicates', True):
        return rows
    seen: set[str] = set()
    output: list[sqlite3.Row] = []
    for row in rows:
        key = row['duplicate_group'] or row['cluster_key'] or row['title']
        if key in seen:
            continue
        seen.add(key)
        output.append(row)
    return output


def list_articles(limit: int = 100, status: str = 'all') -> list[dict[str, Any]]:
    query = 'SELECT * FROM articles'
    params: list[Any] = []
    if status != 'all':
        query += ' WHERE status = ?'
        params.append(status)
    query += '''
        ORDER BY
            COALESCE(NULLIF(published_at, ''), created_at) DESC,
            relevance_score DESC,
            id DESC
        LIMIT ?
    '''
    params.append(max(limit * 4, 200))
    with get_conn() as conn:
        rows = conn.execute(query, params).fetchall()
    rows = _dedupe_rows(rows)[:limit]
    return [row_to_dict(row) for row in rows]


def get_article(article_id: int) -> dict[str, Any] | None:
    with get_conn() as conn:
        row = conn.execute('SELECT * FROM articles WHERE id = ?', (article_id,)).fetchone()
    return row_to_dict(row)


def update_article_status(article_id: int, status: str) -> dict[str, Any] | None:
    with get_conn() as conn:
        before = conn.execute('SELECT status FROM articles WHERE id = ?', (article_id,)).fetchone()
        previous_status = before['status'] if before else None
        conn.execute("UPDATE articles SET status = ?, status_origin = 'manual', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (status, article_id))
        conn.execute('INSERT INTO feedback_events(article_id, previous_status, new_status) VALUES(?, ?, ?)', (article_id, previous_status, status))
        row = conn.execute('SELECT * FROM articles WHERE id = ?', (article_id,)).fetchone()
    return row_to_dict(row)


def rescore_articles(prompt: str, date_window: str = 'all', relevance_mode: str = 'balanced') -> int:
    from .intelligence import analyze_articles
    with get_conn() as conn:
        rows = [row_to_dict(row) for row in conn.execute('SELECT * FROM articles').fetchall()]
        analyzed = analyze_articles([row or {} for row in rows], prompt, date_window=date_window, relevance_mode=relevance_mode)
        for row in analyzed:
            if row.get('status_origin') == 'manual':
                conn.execute('''
                    UPDATE articles
                    SET match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?,
                        entities_json = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (json.dumps(row.get('match_tags') or [], ensure_ascii=False), row.get('cluster_key'), row.get('duplicate_group'), row.get('duplicate_rank', 1), row.get('campaign_cluster'), json.dumps(row.get('entities') or {}, ensure_ascii=False), row.get('semantic_score', 0), row.get('feedback_score', 0), row.get('hybrid_score', row.get('relevance_score', 0)), row.get('rationale', ''), row['id']))
            else:
                conn.execute('''
                    UPDATE articles
                    SET status = ?, status_origin = 'auto', match_tags = ?, cluster_key = ?, duplicate_group = ?, duplicate_rank = ?, campaign_cluster = ?,
                        entities_json = ?, semantic_score = ?, feedback_score = ?, relevance_score = ?, rationale = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (row.get('computed_status', row.get('status', 'pending')), json.dumps(row.get('match_tags') or [], ensure_ascii=False), row.get('cluster_key'), row.get('duplicate_group'), row.get('duplicate_rank', 1), row.get('campaign_cluster'), json.dumps(row.get('entities') or {}, ensure_ascii=False), row.get('semantic_score', 0), row.get('feedback_score', 0), row.get('hybrid_score', row.get('relevance_score', 0)), row.get('rationale', ''), row['id']))
    return len(analyzed)


def stats() -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute('''
            SELECT COUNT(*) AS total_articles,
                SUM(CASE WHEN status = 'included' THEN 1 ELSE 0 END) AS included_count,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_count,
                SUM(CASE WHEN status = 'excluded' THEN 1 ELSE 0 END) AS excluded_count
            FROM articles
        ''').fetchone()
        feed_count = conn.execute('SELECT COUNT(*) AS c FROM feeds').fetchone()['c']
    return {'total_articles': row['total_articles'] or 0, 'included_count': row['included_count'] or 0, 'pending_count': row['pending_count'] or 0, 'excluded_count': row['excluded_count'] or 0, 'feed_count': feed_count}



def feedback_summary() -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute("SELECT COUNT(*) AS total, SUM(CASE WHEN new_status = 'included' THEN 1 ELSE 0 END) AS included, SUM(CASE WHEN new_status = 'excluded' THEN 1 ELSE 0 END) AS excluded FROM feedback_events").fetchone()
    return {'feedback_events': row['total'] or 0, 'feedback_included': row['included'] or 0, 'feedback_excluded': row['excluded'] or 0}

def seed_default_feeds() -> None:
    for url in DEFAULT_FEED_URLS:
        add_feed(name=derive_feed_name(url), url=url)
    seed = os.getenv('CYBERRAD_SEED_FEEDS', '').strip()
    if not seed:
        return
    entries = [item.strip() for item in seed.split(',') if item.strip()]
    for entry in entries:
        if '|' in entry:
            name, url = entry.split('|', 1)
        else:
            name, url = '', entry
        add_feed(name=name.strip(), url=url.strip())

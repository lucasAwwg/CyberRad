from __future__ import annotations

import asyncio
import contextlib
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, HttpUrl
from starlette.requests import Request

from .db import add_feed, delete_feed, feedback_summary, get_article, get_settings, init_db, list_articles, list_feeds, rescore_articles, seed_default_feeds, stats, toggle_feed, update_article_status, update_settings, upsert_articles
from .exporter import export_articles_to_docx
from .rss import parse_feed

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = Jinja2Templates(directory=str(BASE_DIR / 'templates'))

class FeedCreate(BaseModel):
    name: str | None = Field(default=None, min_length=0, max_length=120)
    url: HttpUrl

class FeedToggle(BaseModel):
    is_enabled: bool

class SettingsUpdate(BaseModel):
    prompt: str | None = None
    poll_interval_seconds: int | None = Field(default=None, ge=30, le=86400)
    max_articles_per_feed: int | None = Field(default=None, ge=1, le=100)
    auto_refresh_enabled: bool | None = None
    date_window: Literal['all', 'today', 'yesterday', '3', '7', '15', '30', '90', '120'] | None = None
    relevance_mode: Literal['flexible', 'balanced', 'strict'] | None = None
    hide_duplicates: bool | None = None
    semantic_reranking: bool | None = None
    feedback_learning: bool | None = None

class ArticleStatusUpdate(BaseModel):
    status: Literal['included', 'pending', 'excluded']

async def refresh_all_feeds() -> dict[str, object]:
    settings = get_settings()
    feeds = [feed for feed in list_feeds() if feed['is_enabled']]
    total_inserted = 0
    total_scanned = 0
    failed_feeds = []
    for feed in feeds:
        try:
            articles = await asyncio.to_thread(parse_feed, feed, settings['prompt'], settings['max_articles_per_feed'], settings['date_window'], settings['relevance_mode'])
            total_scanned += len(articles)
            total_inserted += await asyncio.to_thread(upsert_articles, articles)
        except Exception as exc:
            failed_feeds.append({'id': feed.get('id'), 'name': feed.get('name'), 'error': str(exc)})
    await asyncio.to_thread(rescore_articles, settings['prompt'], settings['date_window'], settings['relevance_mode'])
    return {'feeds': len(feeds), 'scanned': total_scanned, 'inserted': total_inserted, 'failed_feeds': failed_feeds}

async def refresh_loop(stop_event: asyncio.Event) -> None:
    while not stop_event.is_set():
        settings = get_settings()
        try:
            if settings['auto_refresh_enabled']:
                await refresh_all_feeds()
        except Exception as exc:
            print(f'[CyberRad V4.4] refresh error: {exc}')
        wait_seconds = max(30, int(settings['poll_interval_seconds']))
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=wait_seconds)
        except asyncio.TimeoutError:
            continue

@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    seed_default_feeds()
    stop_event = asyncio.Event()
    app.state.stop_event = stop_event
    app.state.refresh_task = asyncio.create_task(refresh_loop(stop_event))
    app.state.initial_refresh_task = asyncio.create_task(refresh_all_feeds())
    try:
        yield
    finally:
        stop_event.set()
        for task_name in ('refresh_task', 'initial_refresh_task'):
            task = getattr(app.state, task_name, None)
            if task:
                task.cancel()
                with contextlib.suppress(BaseException):
                    await task

app = FastAPI(title='CyberRad V4.5', lifespan=lifespan)
app.mount('/static', StaticFiles(directory=str(BASE_DIR / 'static')), name='static')

@app.get('/', response_class=HTMLResponse)
async def index(request: Request):
    return TEMPLATES.TemplateResponse(request=request, name='index.html', context={'request': request, 'settings': get_settings(), 'stats': stats(), 'feedback': feedback_summary()})

@app.get('/api/state')
async def api_state():
    return {'settings': get_settings(), 'stats': stats(), 'feedback': feedback_summary(), 'feeds': list_feeds()}

@app.get('/api/articles')
async def api_articles(limit: int = 50, status: str = 'all'):
    return {'articles': list_articles(limit=min(limit, 200), status=status)}

@app.get('/api/articles/{article_id}')
async def api_article(article_id: int):
    article = get_article(article_id)
    if not article:
        raise HTTPException(status_code=404, detail='Noticia no encontrada')
    return article

@app.post('/api/feeds')
async def api_create_feed(payload: FeedCreate):
    feed = add_feed(payload.name, str(payload.url))
    await refresh_all_feeds()
    return feed

@app.patch('/api/feeds/{feed_id}')
async def api_toggle_feed(feed_id: int, payload: FeedToggle):
    feed = toggle_feed(feed_id, payload.is_enabled)
    if not feed:
        raise HTTPException(status_code=404, detail='Feed no encontrado')
    return feed

@app.delete('/api/feeds/{feed_id}')
async def api_delete_feed(feed_id: int):
    delete_feed(feed_id)
    return {'ok': True}

@app.patch('/api/settings')
async def api_update_settings(payload: SettingsUpdate):
    changes = payload.model_dump(exclude_none=True)
    updated = update_settings(changes)
    if {'prompt', 'date_window', 'relevance_mode', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'} & changes.keys():
        await asyncio.to_thread(rescore_articles, updated['prompt'], updated['date_window'], updated['relevance_mode'])
    return updated

@app.post('/api/refresh')
async def api_refresh():
    return await refresh_all_feeds()

@app.patch('/api/articles/{article_id}/status')
async def api_article_status(article_id: int, payload: ArticleStatusUpdate):
    article = update_article_status(article_id, payload.status)
    if not article:
        raise HTTPException(status_code=404, detail='Noticia no encontrada')
    settings = get_settings()
    await asyncio.to_thread(rescore_articles, settings['prompt'], settings['date_window'], settings['relevance_mode'])
    return get_article(article_id)

@app.get('/export/docx')
async def export_docx(status: str = 'included'):
    articles = list_articles(limit=500, status=status)
    if not articles:
        raise HTTPException(status_code=400, detail='No hay noticias para exportar con ese estado.')
    path = await asyncio.to_thread(export_articles_to_docx, articles)
    return FileResponse(path, filename=path.name, media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')

const statsEl = document.getElementById('stats');
const feedsListEl = document.getElementById('feedsList');
const articlesContainer = document.getElementById('articlesContainer');
const dialog = document.getElementById('articleDialog');
const dialogContent = document.getElementById('articleDialogContent');

let currentStatus = 'all';
let knownArticleIds = new Set();

async function api(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(detail || 'Error en la petición');
  }
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function renderStats(stats, feedback = {}) {
  statsEl.innerHTML = `
    <div class="stat-box"><span>Total</span><strong>${stats.total_articles}</strong></div>
    <div class="stat-box"><span>Feeds</span><strong>${stats.feed_count}</strong></div>
    <div class="stat-box"><span>Incluidas</span><strong>${stats.included_count}</strong></div>
    <div class="stat-box"><span>Pendientes</span><strong>${stats.pending_count}</strong></div>
    <div class="stat-box"><span>Excluidas</span><strong>${stats.excluded_count}</strong></div>
    <div class="stat-box"><span>Feedback</span><strong>${feedback.feedback_events || 0}</strong></div>
  `;
}

function applySettingsToForm(settings) {
  document.getElementById('promptInput').value = settings.prompt || '';
  document.getElementById('intervalInput').value = Number(settings.poll_interval_seconds || 300);
  document.getElementById('maxArticlesInput').value = Number(settings.max_articles_per_feed || 20);
  document.getElementById('autoRefreshInput').checked = Boolean(settings.auto_refresh_enabled);
  document.getElementById('dateWindowInput').value = settings.date_window || 'all';
  document.getElementById('relevanceModeInput').value = settings.relevance_mode || 'balanced';
  document.getElementById('hideDuplicatesInput').checked = Boolean(settings.hide_duplicates);
}

function renderFeeds(feeds) {
  if (!feeds.length) {
    feedsListEl.innerHTML = '<p class="empty-state">Todavía no hay feeds.</p>';
    return;
  }
  feedsListEl.innerHTML = feeds.map(feed => `
    <div class="feed-row">
      <div>
        <strong>${escapeHtml(feed.name)}</strong>
        <div class="article-meta wrap-anywhere">${escapeHtml(feed.url)}</div>
      </div>
      <div class="feed-actions">
        <button class="secondary-btn" onclick="toggleFeed(${feed.id}, ${feed.is_enabled ? 'false' : 'true'})">${feed.is_enabled ? 'Pausar' : 'Activar'}</button>
        <button class="secondary-btn" onclick="removeFeed(${feed.id})">Borrar</button>
      </div>
    </div>
  `).join('');
}

function statusChip(status) {
  const labels = { included: 'Incluida', pending: 'Pendiente', excluded: 'Excluida' };
  return `<span class="status-chip status-${status}">${labels[status] || status}</span>`;
}

function formatDate(value) {
  if (!value) return 'Sin fecha';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('es-ES');
}

function renderTags(tags = []) {
  if (!Array.isArray(tags) || !tags.length) return '';
  return `<div class="tag-row">${tags.slice(0, 6).map(tag => `<span class="tag-chip">${escapeHtml(tag)}</span>`).join('')}</div>`;
}

function renderArticles(articles) {
  if (!articles.length) {
    articlesContainer.innerHTML = '<div class="card empty-state">No hay noticias para este filtro.</div>';
    return;
  }
  const newIds = new Set(articles.map(a => a.id));
  articlesContainer.innerHTML = articles.map(article => {
    const isNew = !knownArticleIds.has(article.id);
    return `
      <article class="article-card ${isNew ? 'slide-in' : ''}">
        ${article.image_url ? `<img class="article-image" src="${escapeAttribute(article.image_url)}" alt="${escapeAttribute(article.title)}" />` : '<div class="article-image"></div>'}
        <div class="article-body">
          <div class="article-meta">
            <span>${escapeHtml(article.feed_name || 'Feed')}</span>
            <span>Híbrido ${Number(article.relevance_score || 0).toFixed(2)} · Sem ${Number(article.semantic_score || 0).toFixed(2)}</span>
          </div>
          <h3 class="article-title">${escapeHtml(article.title)}</h3>
          <p class="article-summary">${escapeHtml((article.summary || article.content || '').slice(0, 220))}</p>
          ${renderTags(article.match_tags)}
          ${article.campaign_cluster ? `<div class="article-meta"><span>Campaña: ${escapeHtml(article.campaign_cluster.replace('campaign:', ''))}</span></div>` : ''}
          <p class="article-rationale">${escapeHtml((article.rationale || 'Sin explicación').slice(0, 180))}</p>
          <div class="article-meta">
            <span>${formatDate(article.published_at || article.created_at)}</span>
            ${statusChip(article.status)}
          </div>
          <div class="status-actions">
            <button onclick="setArticleStatus(${article.id}, 'included')">Incluir</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'pending')">Pendiente</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'excluded')">Excluir</button>
          </div>
          <div class="article-actions">
            <button class="secondary-btn" onclick="showArticle(${article.id})">VER</button>
            <a class="button-link secondary-btn" href="${escapeAttribute(article.article_url)}" target="_blank" rel="noopener noreferrer">WEB</a>
          </div>
        </div>
      </article>
    `;
  }).join('');
  knownArticleIds = newIds;
}

async function loadState() {
  const state = await api('/api/state');
  renderStats(state.stats, state.feedback || {});
  renderFeeds(state.feeds);
  applySettingsToForm(state.settings);
}

async function loadArticles() {
  const payload = await api(`/api/articles?limit=60&status=${currentStatus}`);
  renderArticles(payload.articles);
}

async function showArticle(articleId) {
  const article = await api(`/api/articles/${articleId}`);
  dialogContent.innerHTML = `
    <h2>${escapeHtml(article.title)}</h2>
    ${article.image_url ? `<img class="dialog-image" src="${escapeAttribute(article.image_url)}" alt="${escapeAttribute(article.title)}" />` : ''}
    <p><strong>Fuente:</strong> ${escapeHtml(article.feed_name || 'N/D')}</p>
    <p><strong>Fecha:</strong> ${escapeHtml(formatDate(article.published_at || article.created_at))}</p>
    <p><strong>Tags:</strong> ${(article.match_tags || []).map(escapeHtml).join(', ') || 'Sin tags'}</p>
    <p><strong>Score híbrido:</strong> ${Number(article.relevance_score || 0).toFixed(2)} · <strong>Semántico:</strong> ${Number(article.semantic_score || 0).toFixed(2)} · <strong>Feedback:</strong> ${Number(article.feedback_score || 0).toFixed(2)}</p>
    ${article.campaign_cluster ? `<p><strong>Cluster temático:</strong> ${escapeHtml(article.campaign_cluster.replace('campaign:', ''))}</p>` : ''}
    ${article.duplicate_group ? `<p><strong>Grupo duplicado:</strong> ${escapeHtml(article.duplicate_group.replace('dup:', ''))}</p>` : ''}
    <p><strong>Explicación:</strong> ${escapeHtml(article.rationale || 'Sin explicación')}</p>
    <p>${escapeHtml(article.summary || '')}</p>
    <p>${escapeHtml(article.content || '')}</p>
    ${article.video_url ? `<p><strong>Vídeo:</strong> <a href="${escapeAttribute(article.video_url)}" target="_blank" rel="noopener noreferrer">Abrir vídeo</a></p>` : ''}
    <p><strong>Artículo:</strong> <a href="${escapeAttribute(article.article_url)}" target="_blank" rel="noopener noreferrer">Abrir noticia</a></p>
  `;
  dialog.showModal();
}
window.showArticle = showArticle;

async function setArticleStatus(articleId, status) {
  await api(`/api/articles/${articleId}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  await Promise.all([loadState(), loadArticles()]);
}
window.setArticleStatus = setArticleStatus;

async function toggleFeed(feedId, is_enabled) {
  await api(`/api/feeds/${feedId}`, { method: 'PATCH', body: JSON.stringify({ is_enabled }) });
  await Promise.all([loadState(), loadArticles()]);
}
window.toggleFeed = toggleFeed;

async function removeFeed(feedId) {
  await api(`/api/feeds/${feedId}`, { method: 'DELETE' });
  await Promise.all([loadState(), loadArticles()]);
}
window.removeFeed = removeFeed;

function escapeHtml(value = '') {
  return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}
function escapeAttribute(value = '') { return escapeHtml(value); }

async function saveSettings() {
  const payload = {
    prompt: document.getElementById('promptInput').value,
    poll_interval_seconds: Number(document.getElementById('intervalInput').value),
    max_articles_per_feed: Number(document.getElementById('maxArticlesInput').value),
    auto_refresh_enabled: document.getElementById('autoRefreshInput').checked,
    date_window: document.getElementById('dateWindowInput').value,
    relevance_mode: document.getElementById('relevanceModeInput').value,
    hide_duplicates: document.getElementById('hideDuplicatesInput').checked,
  };
  await api('/api/settings', { method: 'PATCH', body: JSON.stringify(payload) });
  await Promise.all([loadState(), loadArticles()]);
}

async function addFeed() {
  const payload = { name: document.getElementById('feedNameInput').value || null, url: document.getElementById('feedUrlInput').value };
  await api('/api/feeds', { method: 'POST', body: JSON.stringify(payload) });
  document.getElementById('feedNameInput').value = '';
  document.getElementById('feedUrlInput').value = '';
  await Promise.all([loadState(), loadArticles()]);
}

async function refreshNow() {
  await api('/api/refresh', { method: 'POST' });
  await Promise.all([loadState(), loadArticles()]);
}

document.getElementById('saveSettingsBtn').addEventListener('click', saveSettings);
document.getElementById('addFeedBtn').addEventListener('click', addFeed);
document.getElementById('refreshBtn').addEventListener('click', refreshNow);

document.querySelectorAll('.status-filter').forEach(button => {
  button.addEventListener('click', async () => {
    document.querySelectorAll('.status-filter').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    currentStatus = button.dataset.status;
    await loadArticles();
  });
});

async function boot() {
  await loadState();
  await loadArticles();
  setInterval(loadArticles, 15000);
  setInterval(loadState, 30000);
}

boot().catch(error => {
  console.error(error);
  articlesContainer.innerHTML = `<div class="card empty-state">Error al cargar: ${escapeHtml(error.message)}</div>`;
});

Este paquete fusiona CyberRad V4.5 con Docker y GitHub Actions para despliegue.
Pasos locales en Kali/Ubuntu:
  cp .env.example .env
  docker-compose up -d --build
Luego abre http://127.0.0.1:3000

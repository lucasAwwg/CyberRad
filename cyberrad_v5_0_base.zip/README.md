CyberRad V5.0 Base

Esta base mantiene el mismo estilo visual de CyberRad y sirve como punto de partida para la rama 5.0.

Incluye:
- filtro ciber real para prensa y Google News
- categoría Marcas orientada a retail/fashion/ecommerce
- mapa de Marcas enlazado a noticias por país
- compatibilidad con Docker, Kali e Icarus/GitLab Runner

Objetivo de la 5.0:
- arranque rápido
- totales estables
- prompt robusto
- módulo Marcas más preciso
- mapa geográfico sólido
- mejor observabilidad y menos bugs

Archivos clave:
- app/main.py
- app/rss.py
- app/intelligence.py
- app/brands_map.py
- docker-compose.kali.yml
- docker-compose.yml

Arranque local:
    python3 -m venv .venv
    source .venv/bin/activate
    python3 -m pip install -r requirements.txt
    python3 -m uvicorn app.main:app --host 127.0.0.1 --port 3000 --app-dir .

Docker en Kali:
    docker compose -f docker-compose.kali.yml up -d --build

Este zip es la base de trabajo 5.0.

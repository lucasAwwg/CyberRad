const statsEl = document.getElementById('stats');
const feedsListEl = document.getElementById('feedsList');
const articlesContainer = document.getElementById('articlesContainer');
const dialog = document.getElementById('articleDialog');
const dialogContent = document.getElementById('articleDialogContent');
const promptInput = document.getElementById('promptInput');
const promptSaveStatusEl = document.getElementById('promptSaveStatus');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const intervalInput = document.getElementById('intervalInput');
const maxArticlesInput = document.getElementById('maxArticlesInput');
const autoRefreshInput = document.getElementById('autoRefreshInput');
const dateWindowInput = document.getElementById('dateWindowInput');
const relevanceModeInput = document.getElementById('relevanceModeInput');
const hideDuplicatesInput = document.getElementById('hideDuplicatesInput');
const brandsMapSection = document.getElementById('brandsMapSection');
const brandsMapYearSelect = document.getElementById('brandsMapYearSelect');
const brandsMapPdfBtn = document.getElementById('brandsMapPdfBtn');
const brandsMapStats = document.getElementById('brandsMapStats');
const brandsMapCanvas = document.getElementById('brandsMapCanvas');
const brandsMapTopCountries = document.getElementById('brandsMapTopCountries');
const brandsMapTopAttacks = document.getElementById('brandsMapTopAttacks');
const brandsMapIncidents = document.getElementById('brandsMapIncidents');

const PROMPT_DRAFT_KEY = 'cyberrad_prompt_draft_v451';
let currentStatus = 'all';
let currentSector = 'all';
let knownArticleIds = new Set();
let lastServerPrompt = '';
let promptDirty = false;
let autosaveTimer = null;
let saveInFlight = false;
let queuedPromptAutosave = false;
let isBootstrapped = false;
let lastRescoreInProgress = false;
let brandsMapData = null;
let brandsMapYear = 'all';
let brandsMapRequestSeq = 0;
let brandsMapKickStarted = false;
let brandsMapUserSelectedYear = false;
let brandsMapHydrationTimer = null;
let brandsMapHydrationAttempts = 0;
let lastBootstrapFinishedAt = null;
const AUTO_RELOAD_MS = 30000;
const STATE_POLL_MS = 10000;

async function api(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', headers: { 'Content-Type': 'application/json' }, ...options });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(detail || 'Error en la petición');
  }
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function setPromptStatus(message, tone = 'muted') {
  promptSaveStatusEl.textContent = message;
  promptSaveStatusEl.className = `save-status ${tone}`;
}

function persistPromptDraft(value) {
  try {
    if (value && value !== lastServerPrompt) {
      localStorage.setItem(PROMPT_DRAFT_KEY, value);
    } else {
      localStorage.removeItem(PROMPT_DRAFT_KEY);
    }
  } catch (error) {
    console.warn('No se pudo guardar el borrador local del prompt', error);
  }
}

function loadLocalPromptDraft() {
  try {
    return localStorage.getItem(PROMPT_DRAFT_KEY) || '';
  } catch (error) {
    return '';
  }
}

function markPromptDirty() {
  promptDirty = promptInput.value !== lastServerPrompt;
  persistPromptDraft(promptInput.value);
  if (promptDirty) {
    setPromptStatus('Borrador local guardado. Esperando para autoguardar…', 'warning');
  } else {
    setPromptStatus('Prompt sincronizado con el servidor.', 'success');
  }
}

function schedulePromptAutosave() {
  clearTimeout(autosaveTimer);
  if (!promptDirty) return;
  autosaveTimer = setTimeout(() => {
    saveSettings({ promptOnly: true, source: 'autosave' }).catch(console.error);
  }, 900);
}

function renderStats(stats, feedback = {}) {
  statsEl.innerHTML = `
    <div class="stat-box"><span>Total</span><strong>${stats.total_articles}</strong></div>
    <div class="stat-box"><span>Feeds</span><strong>${stats.feed_count}</strong></div>
    <div class="stat-box"><span>Incluidas</span><strong>${stats.included_count}</strong></div>
    <div class="stat-box"><span>Pendientes</span><strong>${stats.pending_count}</strong></div>
    <div class="stat-box"><span>Excluidas</span><strong>${stats.excluded_count}</strong></div>
    <div class="stat-box"><span>Feedback</span><strong>${feedback.feedback_events || 0}</strong></div>
  `;
}

function applySettingsToForm(settings) {
  const focusedElement = document.activeElement;
  const serverPrompt = settings.prompt || '';
  const canOverwritePrompt = !promptDirty && focusedElement !== promptInput;
  if (canOverwritePrompt) {
    promptInput.value = serverPrompt;
    lastServerPrompt = serverPrompt;
    persistPromptDraft('');
    if (isBootstrapped) {
      setPromptStatus('Prompt sincronizado con el servidor.', 'success');
    }
  }
  if (focusedElement !== intervalInput) intervalInput.value = Number(settings.poll_interval_seconds || 300);
  if (focusedElement !== maxArticlesInput) maxArticlesInput.value = Number(settings.max_articles_per_feed || 20);
  if (focusedElement !== dateWindowInput) dateWindowInput.value = settings.date_window || 'all';
  if (focusedElement !== relevanceModeInput) relevanceModeInput.value = settings.relevance_mode || 'balanced';
  autoRefreshInput.checked = Boolean(settings.auto_refresh_enabled);
  hideDuplicatesInput.checked = Boolean(settings.hide_duplicates);
}

function renderFeeds(feeds) {
  if (!feeds.length) {
    feedsListEl.innerHTML = '<p class="empty-state">Todavía no hay feeds.</p>';
    return;
  }
  feedsListEl.innerHTML = feeds.map(feed => `
    <div class="feed-row">
      <div>
        <strong>${escapeHtml(feed.name)}</strong>
        <div class="article-meta wrap-anywhere">${escapeHtml(feed.url)}</div>
      </div>
      <div class="feed-actions">
        <button class="secondary-btn" onclick="toggleFeed(${feed.id}, ${feed.is_enabled ? 'false' : 'true'})">${feed.is_enabled ? 'Pausar' : 'Activar'}</button>
        <button class="secondary-btn" onclick="removeFeed(${feed.id})">Borrar</button>
      </div>
    </div>
  `).join('');
}

function statusChip(status) {
  const labels = { included: 'Incluida', pending: 'Pendiente', excluded: 'Excluida' };
  return `<span class="status-chip status-${status}">${labels[status] || status}</span>`;
}

function formatDate(value) {
  if (!value) return 'Sin fecha';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('es-ES');
}

function renderTags(tags = []) {
  if (!Array.isArray(tags) || !tags.length) return '';
  return `<div class="tag-row">${tags.slice(0, 6).map(tag => `<span class="tag-chip">${escapeHtml(tag)}</span>`).join('')}</div>`;
}

function sectorMeta(article) {
  return Array.isArray(article.sector_categories) && article.sector_categories.includes('marcas_retail')
    ? '<span class="sector-chip">Marcas</span>'
    : '';
}

function toggleBrandsMapVisibility() {
  const active = currentSector === 'marcas_retail';
  brandsMapSection.classList.toggle('hidden', !active);
}

function renderBrandsMapStats(totals = {}, extra = {}) {
  const activeYearLabel = extra.yearLabel || '2024+';
  const allArticles = Number(totals.all_articles ?? totals.incidents ?? 0);
  const mappedArticles = Number(totals.mapped_articles ?? totals.visible_articles ?? 0);
  brandsMapStats.innerHTML = `
    <div class="stat-box"><span>Noticias Marcas</span><strong>${allArticles}</strong><small>Incl ${Number(totals.included || 0)} · Pend ${Number(totals.pending || 0)} · Excl ${Number(totals.excluded || 0)}</small></div>
    <div class="stat-box"><span>Países</span><strong>${Number(totals.countries || 0)}</strong><small>Con punto en mapa</small></div>
    <div class="stat-box"><span>En mapa</span><strong>${mappedArticles}</strong><small>Con país inferido</small></div>
    <div class="stat-box"><span>Ventana</span><strong>${escapeHtml(activeYearLabel)}</strong><small>Totales estables</small></div>
  `;
}


function normalizeCountryKey(value) {
  const raw = String(value || '').trim().toLowerCase();
  const cleaned = raw.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w\s-]/g, '').replace(/\s+/g, ' ').trim();
  const aliases = {
    us: 'united_states',
    usa: 'united_states',
    'united states': 'united_states',
    'united states of america': 'united_states',
    uk: 'united_kingdom',
    britain: 'united_kingdom',
    'great britain': 'united_kingdom',
    england: 'united_kingdom',
    'united kingdom': 'united_kingdom',
    espana: 'spain',
    españa: 'spain',
    deutschland: 'germany',
  };
  return aliases[cleaned] || cleaned.replace(/\s+/g, '_');
}

function renderMapList(el, items, formatter) {
  if (!items || !items.length) {
    el.innerHTML = '<div class="empty-mini">Sin datos todavía.</div>';
    return;
  }
  el.innerHTML = items.map(formatter).join('');
}

function brandPointRadius(point, maxCount) {
  return 8 + Math.round(18 * Math.sqrt((point.count || 1) / (maxCount || 1)));
}

function deriveBrandsMapFallback(data) {
  const incidents = Array.isArray(data.incidents) ? data.incidents : [];
  const points = Array.isArray(data.points) ? data.points : [];
  const topCountries = (data.top_countries && data.top_countries.length)
    ? data.top_countries
    : Object.values(incidents.reduce((acc, item) => {
        const key = item.country || 'No inferido';
        acc[key] = acc[key] || { country: key, count: 0, brands: [] };
        acc[key].count += 1;
        if (item.brand && !acc[key].brands.includes(item.brand)) acc[key].brands.push(item.brand);
        return acc;
      }, {})).sort((a, b) => b.count - a.count).slice(0, 8);
  const topAttacks = (data.top_attacks && data.top_attacks.length)
    ? data.top_attacks
    : Object.entries(incidents.reduce((acc, item) => {
        const key = item.attack_type || 'Incidente ciber';
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {})).map(([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count).slice(0, 8);
  const totals = {
    all_articles: (data.totals && data.totals.all_articles) ?? incidents.length,
    visible_articles: (data.totals && data.totals.visible_articles) ?? incidents.length,
    mapped_articles: (data.totals && data.totals.mapped_articles) ?? incidents.filter(item => item.country && item.country !== 'No inferido').length,
    incidents: (data.totals && data.totals.incidents) ?? incidents.length,
    countries: (data.totals && data.totals.countries) || topCountries.filter(item => item.country !== 'No inferido').length,
    brands: (data.totals && data.totals.brands) || new Set(incidents.map(item => item.brand).filter(Boolean)).size,
    unresolved: (data.totals && data.totals.unresolved) || incidents.filter(item => !item.country || item.country === 'No inferido').length,
    included: (data.totals && data.totals.included) || 0,
    pending: (data.totals && data.totals.pending) || 0,
    excluded: (data.totals && data.totals.excluded) || 0,
  };
  return { ...data, incidents, points, top_countries: topCountries, top_attacks: topAttacks, totals };
}

function buildMapStage(data) {
  const maxCount = Math.max(...(data.points || []).map(point => point.count || 0), 1);
  const dots = (data.points || []).map(point => {
    const radius = brandPointRadius(point, maxCount);
    const tooltipPayload = escapeAttribute(JSON.stringify({
      country: point.country,
      brands: point.brands || [],
      attackTypes: point.attack_types || [],
      latestDate: point.latest_date || '',
      latestBrand: point.latest_brand || '',
      latestAttackType: point.latest_attack_type || '',
      latestSource: point.latest_source || '',
      count: point.count || 0,
    }));
    const ids = escapeAttribute((point.article_ids || []).join(','));
    return `
      <g class="map-point" data-country="${escapeAttribute(point.country)}" data-country-key="${escapeAttribute(point.country_key || normalizeCountryKey(point.country))}" data-article-ids="${ids}" data-tooltip="${tooltipPayload}" transform="translate(${point.x}, ${point.y})" tabindex="0" role="button" aria-label="${escapeAttribute(point.country)} ${point.count} incidentes">
        <circle r="${radius * 1.9}" class="dot-glow"></circle>
        <circle r="${radius}" class="dot-core"></circle>
        <text x="0" y="4" text-anchor="middle" class="dot-count">${point.count}</text>
        <text x="${radius + 8}" y="${-radius - 6}" class="dot-label">${escapeHtml(point.country)}</text>
      </g>
    `;
  }).join('');

  const mapSvg = (data.map_svg || '').replace('<g id="map-dots"></g>', `<g id="map-dots">${dots}</g>`);
  const emptyMessage = !(data.totals || {}).incidents ? '<div class="map-overlay-empty">Cargando o sin incidentes clasificados todavía. El mapa base sigue visible.</div>' : '';
  return `
    <div class="map-backdrop">
      <img class="map-base-image" src="${escapeAttribute(data.map_base_image || '/static/world-outline.png')}" alt="Mapa mundi cibernético" />
      ${mapSvg}
      <div id="mapTooltip" class="map-tooltip hidden"></div>
      ${emptyMessage}
    </div>
  `;
}

function focusIncidentRow(articleId, country = '') {
  if (!articleId && country) {
    const firstByCountry = brandsMapIncidents.querySelector(`[data-country-key="${CSS.escape(normalizeCountryKey(country))}"]`) || brandsMapIncidents.querySelector(`[data-country="${CSS.escape(country)}"]`);
    if (firstByCountry) articleId = firstByCountry.dataset.articleId;
  }
  document.querySelectorAll('.incident-row').forEach(row => row.classList.remove('highlighted'));
  if (!articleId) return;
  const row = brandsMapIncidents.querySelector(`[data-article-id="${CSS.escape(String(articleId))}"]`);
  if (row) {
    row.classList.add('highlighted');
    row.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

function focusMapPoint(articleId = '', country = '') {
  document.querySelectorAll('.map-point').forEach(point => point.classList.remove('is-focused'));
  let target = null;
  if (articleId) {
    target = Array.from(document.querySelectorAll('.map-point')).find(point => (point.dataset.articleIds || '').split(',').includes(String(articleId)));
  }
  if (!target && country) {
    const key = normalizeCountryKey(country);
    target = document.querySelector(`.map-point[data-country-key="${CSS.escape(key)}"]`) || document.querySelector(`.map-point[data-country="${CSS.escape(country)}"]`);
  }
  if (target) target.classList.add('is-focused');
}

function attachMapInteractions() {
  const stage = brandsMapCanvas.querySelector('.map-backdrop');
  const tooltip = brandsMapCanvas.querySelector('#mapTooltip');
  if (!stage || !tooltip) return;

  const moveTooltip = (event, point) => {
    const raw = point.dataset.tooltip || '{}';
    const payload = JSON.parse(raw);
    const brands = (payload.brands || []).slice(0, 4).join(', ') || payload.latestBrand || 'Marca no inferida';
    const attacks = (payload.attackTypes || []).slice(0, 3).join(', ') || payload.latestAttackType || 'Incidente ciber';
    tooltip.innerHTML = `
      <strong>${escapeHtml(payload.country || 'País no inferido')}</strong>
      <span>${payload.count || 0} incidentes</span>
      <small>Marca: ${escapeHtml(brands)}</small>
      <small>Tipo: ${escapeHtml(attacks)}</small>
      <small>Fecha: ${escapeHtml(formatDate(payload.latestDate || ''))}</small>
      <small>Fuente: ${escapeHtml(payload.latestSource || 'Fuente no inferida')}</small>
    `;
    tooltip.classList.remove('hidden');
    const bounds = stage.getBoundingClientRect();
    tooltip.style.left = `${event.clientX - bounds.left + 14}px`;
    tooltip.style.top = `${event.clientY - bounds.top + 14}px`;
  };

  stage.querySelectorAll('.map-point').forEach(point => {
    point.addEventListener('mousemove', event => moveTooltip(event, point));
    point.addEventListener('mouseenter', event => moveTooltip(event, point));
    point.addEventListener('mouseleave', () => tooltip.classList.add('hidden'));
    point.addEventListener('focus', event => moveTooltip(event, point));
    point.addEventListener('blur', () => tooltip.classList.add('hidden'));
    point.addEventListener('click', () => {
      const articleId = (point.dataset.articleIds || '').split(',').filter(Boolean)[0] || '';
      const country = point.dataset.countryKey || point.dataset.country || '';
      focusMapPoint(articleId, country);
      focusIncidentRow(articleId, country);
    });
  });

  brandsMapIncidents.querySelectorAll('.incident-row').forEach(row => {
    row.addEventListener('click', event => {
      if (event.target.closest('a')) return;
      const country = row.dataset.countryKey || row.dataset.country || '';
      focusIncidentRow(row.dataset.articleId || '', country);
      focusMapPoint(row.dataset.articleId || '', country);
    });
  });
}

function renderBrandsMap(data) {
  const resolved = deriveBrandsMapFallback(data || {});
  brandsMapData = resolved;
  const years = Array.isArray(resolved.available_years) && resolved.available_years.length ? resolved.available_years : ['latest', 'all'];
  const selectedMode = String(resolved.selected_mode || 'latest');
  const resolvedYear = String(resolved.year || resolved.latest_populated_year || '');
  const selectedValue = selectedMode === 'specific' ? resolvedYear : selectedMode;
  const yearCounts = resolved.year_counts || {};
  brandsMapYearSelect.innerHTML = years.map(year => {
    const value = String(year);
    const count = Number(yearCounts[value] || 0);
    let label = value;
    if (value === 'latest') label = `Último con datos${resolved.latest_populated_year ? ` · ${resolved.latest_populated_year}` : ''}`;
    else if (value === 'all') label = `Todos desde 2024${count ? ` · ${count}` : ''}`;
    else label = `${value}${count ? ` · ${count}` : ''}`;
    return `<option value="${escapeAttribute(value)}" ${value === selectedValue ? 'selected' : ''}>${escapeHtml(label)}</option>`;
  }).join('');
  brandsMapYear = selectedValue || 'latest';
  brandsMapPdfBtn.href = `/export/marcas-map.pdf?year=${encodeURIComponent(brandsMapYear)}`;
  const effectiveLabel = selectedValue === 'latest' ? `Último con datos · ${resolved.latest_populated_year || resolvedYear || '—'}` : (selectedValue === 'all' ? '2024+' : resolvedYear || selectedValue);
  renderBrandsMapStats(resolved.totals || {}, { yearLabel: effectiveLabel });
  brandsMapCanvas.innerHTML = buildMapStage(resolved);
  renderMapList(brandsMapTopCountries, resolved.top_countries, item => `
    <div class="map-list-item">
      <strong>${escapeHtml(item.country)}</strong>
      <span>${item.count} incidentes</span>
      <small>${escapeHtml((item.brands || []).join(', ') || 'Sin marcas inferidas')}</small>
    </div>
  `);
  renderMapList(brandsMapTopAttacks, resolved.top_attacks, item => `
    <div class="map-list-item compact">
      <strong>${escapeHtml(item.label)}</strong>
      <span>${item.count}</span>
    </div>
  `);
  renderMapList(brandsMapIncidents, resolved.incidents, item => `
    <article class="incident-row" data-article-id="${escapeAttribute(String(item.id || ''))}" data-country="${escapeAttribute(item.country || '')}" data-country-key="${escapeAttribute(item.country_key || normalizeCountryKey(item.country || ''))}">
      <div>
        <div class="incident-badges">
          <span class="tag-chip country-badge">${escapeHtml(item.country || 'No inferido')}</span>
          <span class="tag-chip attack-badge">${escapeHtml(item.attack_type || 'Incidente ciber')}</span>
          <span class="tag-chip">${escapeHtml(item.status || 'pending')}</span>
        </div>
        <h4>${escapeHtml(item.title)}</h4>
        <p>${escapeHtml(item.brand || 'Marca no inferida')} · ${escapeHtml(item.feed_name || item.source || 'Fuente no inferida')}</p>
      </div>
      <div class="incident-meta">
        <span>${escapeHtml(formatDate(item.published_at))}</span>
        <a class="button-link secondary-btn" href="${escapeAttribute(item.article_url)}" target="_blank" rel="noopener noreferrer">Abrir</a>
      </div>
    </article>
  `);
  attachMapInteractions();
}

async function loadBrandsMap(forceYear = null, { autoFallback = true, keepLastSuccessful = true } = {}) {
  if (brandsMapHydrationTimer) { clearTimeout(brandsMapHydrationTimer); brandsMapHydrationTimer = null; }
  toggleBrandsMapVisibility();
  if (currentSector !== 'marcas_retail') return;
  const requestSeq = ++brandsMapRequestSeq;
  const params = new URLSearchParams();
  const year = forceYear ?? (brandsMapUserSelectedYear ? brandsMapYear : 'all');
  if (year && !['latest', 'all'].includes(String(year))) params.set('year', String(year));
  params.set('_ts', String(Date.now()));
  if (!keepLastSuccessful || !brandsMapData) {
    brandsMapCanvas.innerHTML = buildMapStage({ map_base_image: '/static/world-outline.png', map_svg: '<svg viewBox="0 0 1140 744" class="world-svg" xmlns="http://www.w3.org/2000/svg"><g id="map-dots"></g></svg>', points: [], totals: {} });
  }
  const data = await api(`/api/marcas-map?${params.toString()}`);
  if (requestSeq !== brandsMapRequestSeq) return;
  const latestPopulatedYear = String(data.latest_populated_year || '');
  const currentYear = String(data.year || year || 'latest');
  const totals = data.totals || {};
  const hasIncidents = Number(totals.all_articles || 0) > 0;
  if (!hasIncidents && autoFallback && latestPopulatedYear && latestPopulatedYear !== currentYear) {
    brandsMapYear = 'all';
    brandsMapUserSelectedYear = false;
    return loadBrandsMap('all', { autoFallback: false, keepLastSuccessful });
  }
  if (!hasIncidents && currentSector === 'marcas_retail') {
    const bootstrap = window.__brandsBootstrap || {};
    const bootstrapRunning = !!(bootstrap.started_at && !bootstrap.finished_at && !bootstrap.error);
    if (!brandsMapKickStarted) {
      brandsMapKickStarted = true;
      Promise.all([loadState(), loadArticles()])
        .then(() => loadBrandsMap('all', { autoFallback: true, keepLastSuccessful: true }))
        .catch(console.error)
        .finally(() => { brandsMapKickStarted = false; });
    }
    if ((bootstrapRunning || brandsMapHydrationAttempts < 8) && !brandsMapUserSelectedYear) {
      brandsMapHydrationAttempts += 1;
      brandsMapHydrationTimer = setTimeout(() => {
        loadBrandsMap('all', { autoFallback: true, keepLastSuccessful: true }).catch(console.error);
      }, bootstrapRunning ? 1500 : 1000);
    }
  } else {
    brandsMapHydrationAttempts = 0;
  }
  renderBrandsMap(data);
}

function renderArticles(articles) {
  if (!articles.length) {
    articlesContainer.innerHTML = '<div class="card empty-state">No hay noticias para este filtro.</div>';
    return;
  }
  const newIds = new Set(articles.map(a => a.id));
  articlesContainer.innerHTML = articles.map(article => {
    const isNew = !knownArticleIds.has(article.id);
    return `
      <article class="article-card ${isNew ? 'slide-in' : ''}">
        ${article.image_url ? `<img class="article-image" src="${escapeAttribute(article.image_url)}" alt="${escapeAttribute(article.title)}" />` : '<div class="article-image"></div>'}
        <div class="article-body">
          <div class="article-meta">
            <span>${escapeHtml(article.feed_name || 'Feed')}</span>${sectorMeta(article)}
            <span>Híbrido ${Number(article.relevance_score || 0).toFixed(2)} · Sem ${Number(article.semantic_score || 0).toFixed(2)}</span>
          </div>
          <h3 class="article-title">${escapeHtml(article.title)}</h3>
          <p class="article-summary">${escapeHtml((article.summary || article.content || '').slice(0, 220))}</p>
          ${renderTags(article.match_tags)}
          ${article.campaign_cluster ? `<div class="article-meta"><span>Campaña: ${escapeHtml(article.campaign_cluster.replace('campaign:', ''))}</span></div>` : ''}
          <p class="article-rationale">${escapeHtml((article.rationale || 'Sin explicación').slice(0, 180))}</p>
          <div class="article-meta">
            <span>${formatDate(article.published_at || article.created_at)}</span>
            ${statusChip(article.status)}
          </div>
          <div class="status-actions">
            <button onclick="setArticleStatus(${article.id}, 'included')">Incluir</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'pending')">Pendiente</button>
            <button class="secondary-btn" onclick="setArticleStatus(${article.id}, 'excluded')">Excluir</button>
          </div>
          <div class="article-actions">
            <button class="secondary-btn" onclick="showArticle(${article.id})">VER</button>
            <a class="button-link secondary-btn" href="${escapeAttribute(article.article_url)}" target="_blank" rel="noopener noreferrer">WEB</a>
          </div>
        </div>
      </article>
    `;
  }).join('');
  knownArticleIds = newIds;
}

function handleJobs(jobs = {}) {
  const inProgress = Boolean(jobs.rescore_in_progress);
  if (inProgress) {
    setPromptStatus('Guardado. Recalculando noticias en segundo plano…', 'progress');
  } else if (lastRescoreInProgress && !inProgress && !promptDirty) {
    setPromptStatus('Cambios aplicados. Noticias recalculadas.', 'success');
    if (currentSector === 'marcas_retail') {
      Promise.all([loadArticles(), loadBrandsMap(brandsMapYear, { autoFallback: true, keepLastSuccessful: true })]).catch(console.error);
    } else {
      loadArticles().catch(console.error);
    }
  }
  if (jobs.rescore_last_error) {
    setPromptStatus(`Guardado con aviso: ${jobs.rescore_last_error}`, 'error');
  }
  lastRescoreInProgress = inProgress;
}

async function loadState() {
  const state = await api('/api/state');
  renderStats(state.stats, state.feedback || {});
  renderFeeds(state.feeds);
  applySettingsToForm(state.settings);
  handleJobs(state.jobs || {});
  const bootstrap = state.bootstrap || {};
  const previousFinishedAt = lastBootstrapFinishedAt;
  const previousTotal = window.__lastTotalArticles || 0;
  const currentTotal = Number((state.stats || {}).total_articles || 0);
  window.__lastTotalArticles = currentTotal;
  window.__brandsBootstrap = bootstrap;
  lastBootstrapFinishedAt = bootstrap.finished_at || null;
  if (currentSector === 'marcas_retail' && ((lastBootstrapFinishedAt && lastBootstrapFinishedAt !== previousFinishedAt) || (previousTotal === 0 && currentTotal > 0))) {
    Promise.all([
      loadArticles(),
      loadBrandsMap('all', { autoFallback: true, keepLastSuccessful: true }),
    ]).catch(console.error);
  }
  return state;
}

async function loadArticles() {
  const params = new URLSearchParams({ limit: '60', status: currentStatus, sector: currentSector });
  const payload = await api(`/api/articles?${params.toString()}`);
  renderArticles(payload.articles);
  toggleBrandsMapVisibility();
  if (
    currentSector === 'marcas_retail' &&
    !brandsMapUserSelectedYear &&
    Array.isArray(payload.articles) &&
    payload.articles.length > 0
  ) {
    queueMicrotask(() => loadBrandsMap('all', { autoFallback: true, keepLastSuccessful: true }).catch(console.error));
  }
  return payload;
}

async function showArticle(articleId) {
  const article = await api(`/api/articles/${articleId}`);
  dialogContent.innerHTML = `
    <h2>${escapeHtml(article.title)}</h2>
    ${article.image_url ? `<img class="dialog-image" src="${escapeAttribute(article.image_url)}" alt="${escapeAttribute(article.title)}" />` : ''}
    <p><strong>Fuente:</strong> ${escapeHtml(article.feed_name || 'N/D')}</p>
    <p><strong>Fecha:</strong> ${escapeHtml(formatDate(article.published_at || article.created_at))}</p>
    <p><strong>Tags:</strong> ${(article.match_tags || []).map(escapeHtml).join(', ') || 'Sin tags'}</p>
    ${Array.isArray(article.sector_categories) && article.sector_categories.includes('marcas_retail') ? '<p><strong>Categoría interna:</strong> marcas_retail · <strong>Etiqueta:</strong> Marcas</p>' : ''}
    <p><strong>Score híbrido:</strong> ${Number(article.relevance_score || 0).toFixed(2)} · <strong>Semántico:</strong> ${Number(article.semantic_score || 0).toFixed(2)} · <strong>Feedback:</strong> ${Number(article.feedback_score || 0).toFixed(2)}</p>
    ${article.campaign_cluster ? `<p><strong>Cluster temático:</strong> ${escapeHtml(article.campaign_cluster.replace('campaign:', ''))}</p>` : ''}
    ${article.duplicate_group ? `<p><strong>Grupo duplicado:</strong> ${escapeHtml(article.duplicate_group.replace('dup:', ''))}</p>` : ''}
    <p><strong>Explicación:</strong> ${escapeHtml(article.rationale || 'Sin explicación')}</p>
    <p>${escapeHtml(article.summary || '')}</p>
    <p>${escapeHtml(article.content || '')}</p>
    ${article.video_url ? `<p><strong>Vídeo:</strong> <a href="${escapeAttribute(article.video_url)}" target="_blank" rel="noopener noreferrer">Abrir vídeo</a></p>` : ''}
    <p><strong>Artículo:</strong> <a href="${escapeAttribute(article.article_url)}" target="_blank" rel="noopener noreferrer">Abrir noticia</a></p>
  `;
  dialog.showModal();
}
window.showArticle = showArticle;

async function setArticleStatus(articleId, status) {
  const result = await api(`/api/articles/${articleId}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  handleJobs(result.jobs || {});
  await Promise.all([loadState(), loadArticles()]);
  if (currentSector === 'marcas_retail') {
    await loadBrandsMap(brandsMapYear, { autoFallback: true, keepLastSuccessful: true });
  }
}
window.setArticleStatus = setArticleStatus;

async function toggleFeed(feedId, is_enabled) {
  await api(`/api/feeds/${feedId}`, { method: 'PATCH', body: JSON.stringify({ is_enabled }) });
  await Promise.all([loadState(), loadArticles()]);
}
window.toggleFeed = toggleFeed;

async function removeFeed(feedId) {
  await api(`/api/feeds/${feedId}`, { method: 'DELETE' });
  await Promise.all([loadState(), loadArticles()]);
}
window.removeFeed = removeFeed;

function escapeHtml(value = '') {
  return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}
function escapeAttribute(value = '') { return escapeHtml(value); }

function currentSettingsPayload({ promptOnly = false } = {}) {
  if (promptOnly) return { prompt: promptInput.value };
  return {
    prompt: promptInput.value,
    poll_interval_seconds: Number(intervalInput.value),
    max_articles_per_feed: Number(maxArticlesInput.value),
    auto_refresh_enabled: autoRefreshInput.checked,
    date_window: dateWindowInput.value,
    relevance_mode: relevanceModeInput.value,
    hide_duplicates: hideDuplicatesInput.checked,
  };
}

async function saveSettings({ promptOnly = false, source = 'manual' } = {}) {
  if (saveInFlight) {
    if (promptOnly) queuedPromptAutosave = true;
    return;
  }
  saveInFlight = true;
  saveSettingsBtn.disabled = true;
  const originalButtonText = saveSettingsBtn.textContent;
  saveSettingsBtn.textContent = source === 'manual' ? 'Guardando…' : 'Autoguardando…';
  const payload = currentSettingsPayload({ promptOnly });
  const savingPromptValue = payload.prompt ?? promptInput.value;
  setPromptStatus(source === 'manual' ? 'Guardando configuración…' : 'Autoguardando prompt…', 'progress');
  try {
    const result = await api('/api/settings', { method: 'PATCH', body: JSON.stringify(payload) });
    if (typeof payload.prompt === 'string') {
      lastServerPrompt = savingPromptValue;
      promptDirty = promptInput.value !== lastServerPrompt;
      persistPromptDraft(promptDirty ? promptInput.value : '');
    }
    if (!promptOnly) {
      applySettingsToForm(result.settings || {});
    }
    handleJobs(result.jobs || {});
    if (!promptDirty && !(result.jobs || {}).rescore_in_progress) {
      setPromptStatus('Configuración guardada.', 'success');
    }
    if (!promptOnly) {
      await Promise.all([loadState(), loadArticles()]);
    }
  } catch (error) {
    setPromptStatus(`Error al guardar: ${error.message}`, 'error');
    throw error;
  } finally {
    saveInFlight = false;
    saveSettingsBtn.disabled = false;
    saveSettingsBtn.textContent = originalButtonText;
    if (queuedPromptAutosave) {
      queuedPromptAutosave = false;
      if (promptDirty) {
        schedulePromptAutosave();
      }
    }
  }
}

async function addFeed() {
  const payload = { name: document.getElementById('feedNameInput').value || null, url: document.getElementById('feedUrlInput').value };
  await api('/api/feeds', { method: 'POST', body: JSON.stringify(payload) });
  document.getElementById('feedNameInput').value = '';
  document.getElementById('feedUrlInput').value = '';
  await Promise.all([loadState(), loadArticles()]);
}

async function refreshNow() {
  setPromptStatus('Actualizando feeds…', 'progress');
  await api('/api/refresh', { method: 'POST' });
  if (currentSector === 'marcas_retail') {
    await Promise.all([loadState(), loadArticles(), loadBrandsMap(brandsMapYear, { autoFallback: true, keepLastSuccessful: true })]);
  } else {
    await Promise.all([loadState(), loadArticles()]);
  }
}

saveSettingsBtn.addEventListener('click', () => saveSettings({ promptOnly: false, source: 'manual' }));
document.getElementById('addFeedBtn').addEventListener('click', addFeed);
document.getElementById('refreshBtn').addEventListener('click', refreshNow);

promptInput.addEventListener('input', () => {
  markPromptDirty();
  schedulePromptAutosave();
});

promptInput.addEventListener('blur', () => {
  if (promptDirty) {
    saveSettings({ promptOnly: true, source: 'autosave' }).catch(console.error);
  }
});

window.addEventListener('beforeunload', () => {
  persistPromptDraft(promptInput.value);
});

window.addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
    event.preventDefault();
    saveSettings({ promptOnly: false, source: 'manual' }).catch(console.error);
  }
});

document.querySelectorAll('.status-filter').forEach(button => {
  button.addEventListener('click', async () => {
    document.querySelectorAll('.status-filter').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    currentStatus = button.dataset.status;
    await loadArticles();
  });
});

document.querySelectorAll('.sector-filter').forEach(button => {
  button.addEventListener('click', async () => {
    const willActivate = !button.classList.contains('active');
    document.querySelectorAll('.sector-filter').forEach(btn => btn.classList.remove('active'));
    if (willActivate) {
      button.classList.add('active');
      currentSector = button.dataset.sector || 'all';
    } else {
      currentSector = 'all';
    }
    toggleBrandsMapVisibility();
    if (currentSector === 'marcas_retail') {
      brandsMapYear = 'all';
      brandsMapUserSelectedYear = false;
      await Promise.all([loadArticles(), loadBrandsMap('all', { autoFallback: true, keepLastSuccessful: true })]);
    } else {
      await loadArticles();
    }
  });
});

brandsMapYearSelect.addEventListener('change', async () => {
  brandsMapYear = brandsMapYearSelect.value || 'all';
  brandsMapUserSelectedYear = true;
  await loadBrandsMap(brandsMapYear, { autoFallback: false, keepLastSuccessful: true });
});

async function boot() {
  const state = await loadState();
  isBootstrapped = true;
  const localDraft = loadLocalPromptDraft();
  if (localDraft && localDraft !== (state.settings?.prompt || '')) {
    promptInput.value = localDraft;
    promptDirty = true;
    setPromptStatus('Borrador local recuperado. Se guardará solo.', 'warning');
    schedulePromptAutosave();
  }
  await loadArticles();
  toggleBrandsMapVisibility();
  const activeSectorButton = document.querySelector('.sector-filter.active');
  if (activeSectorButton && activeSectorButton.dataset.sector === 'marcas_retail') {
    brandsMapYear = 'all';
    brandsMapUserSelectedYear = false;
    await loadBrandsMap('all', { autoFallback: true, keepLastSuccessful: true });
  }
  setInterval(async () => {
    if (currentSector !== 'marcas_retail') {
      await loadArticles();
    }
  }, AUTO_RELOAD_MS);
  setInterval(loadState, STATE_POLL_MS);
}

boot().catch(error => {
  console.error(error);
  articlesContainer.innerHTML = `<div class="card empty-state">Error al cargar: ${escapeHtml(error.message)}</div>`;
  setPromptStatus(`Error al iniciar: ${error.message}`, 'error');
});

# CyberRad 5.0.1 Marcas Patch Fixed

Parche corregido para el filtro **Marcas** con enfoque en marcas textiles, retail, moda y ecommerce afectadas por incidentes de ciberseguridad.

## Arreglos de esta revisión

- Ya responde en `/` y no devuelve 404 al abrir la base URL.
- Añade un visor web básico para consultar `/scan/marcas` y `/scan/map` desde navegador.
- Devuelve `204` en `/favicon.ico` para evitar el error visual.
- Usa **puerto 3001** fuera y dentro del contenedor.
- Incluye `docker-compose.kali.yml` además de `docker-compose.yml`.
- El contenedor vuelve a llamarse `cyberrad-web` para encajar con comandos anteriores.

## Levantar en Kali

```bash
cd ~/CyberRad/cyberrad_v5_marcas_patch_fixed
docker compose -f docker-compose.kali.yml up -d --build
```

Abrir en navegador:

```text
http://127.0.0.1:3001
```

## Endpoints

- `/`
- `/health`
- `/scan/marcas?limit=50`
- `/scan/map?limit=50`
- `/scan/summary?limit=50`
- `/docs`

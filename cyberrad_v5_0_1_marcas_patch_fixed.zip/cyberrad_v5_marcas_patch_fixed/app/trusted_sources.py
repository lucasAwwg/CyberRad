from __future__ import annotations

# Nota: esto reduce riesgo, pero NO garantiza riesgo cero.
# La idea es aceptar solo HTTPS y dominios reputados / esperados.
TRUSTED_PUBLISHER_DOMAINS = {
    # Cyber / infosec
    "bleepingcomputer.com",
    "securityweek.com",
    "therecord.media",
    "recordedfuture.com",
    "cybernews.com",
    "thehackernews.com",
    "krebsonsecurity.com",
    "theregister.com",
    "cisa.gov",
    # Retail / moda
    "fashionnetwork.com",
    "fashionunited.com",
    "fashionunited.es",
    "fashionunited.uk",
    "retailgazette.co.uk",
    "retaildive.com",
    "economictimes.indiatimes.com",
    "retail.economictimes.indiatimes.com",
    # Prensa general / negocio
    "reuters.com",
    "theguardian.com",
    "elpais.com",
    "cincodias.elpais.com",
    "expansion.com",
    "ft.com",
    "bbc.com",
    "cnn.com",
    "cnbc.com",
    "bloomberg.com",
    "wsj.com",
    "forbes.com",
    "fortune.com",
    "lemonde.fr",
    "handelsblatt.com",
    "nikkei.com",
    "scmp.com",
    "businessinsider.com",
    # Buscadores/aggregators solo para descubrimiento; la noticia final se valida aparte
    "news.google.com",
}

VENDOR_BLOG_DOMAINS = {
    "microsoft.com",
    "security.microsoft.com",
    "microsoftsecurityinsights.com",
    "paloaltonetworks.com",
    "crowdstrike.com",
    "picussecurity.com",
    "fortinet.com",
    "cisco.com",
    "checkpoint.com",
    "trendmicro.com",
    "malwarebytes.com",
    "proofpoint.com",
    "sentinelone.com",
    "akamai.com",
    "cloudflare.com",
    "talosintelligence.com",
}

DIRECT_SOURCE_FEEDS = [
    {
        "name": "BleepingComputer",
        "kind": "rss",
        "url": "https://www.bleepingcomputer.com/feed/",
        "discovery_only": False,
    },
    {
        "name": "SecurityWeek Data Breaches",
        "kind": "rss",
        "url": "https://www.securityweek.com/category/data-breaches/feed/",
        "discovery_only": False,
    },
    {
        "name": "The Record",
        "kind": "rss",
        "url": "https://therecord.media/feed",
        "discovery_only": False,
    },
    {
        "name": "FashionNetwork Retail",
        "kind": "rss",
        "url": "https://ww.fashionnetwork.com/rss/feed/ww%2C1%2C15.xml",
        "discovery_only": False,
    },
    {
        "name": "FashionNetwork Business",
        "kind": "rss",
        "url": "https://ww.fashionnetwork.com/rss/feed/ww%2C1%2C112.xml",
        "discovery_only": False,
    },
    {
        "name": "FashionNetwork Industry",
        "kind": "rss",
        "url": "https://ww.fashionnetwork.com/rss/feed/ww%2C1%2C5.xml",
        "discovery_only": False,
    },
    {
        "name": "ET Retail Apparel & Fashion",
        "kind": "rss",
        "url": "https://retail.economictimes.indiatimes.com/rss/apparel-fashion",
        "discovery_only": False,
    },
    {
        "name": "ET Retail Apparel",
        "kind": "rss",
        "url": "https://retail.economictimes.indiatimes.com/rss/apparel-fashion/apparel",
        "discovery_only": False,
    },
    {
        "name": "ET Retail Sportswear",
        "kind": "rss",
        "url": "https://retail.economictimes.indiatimes.com/rss/apparel-fashion/sportswear",
        "discovery_only": False,
    },
    {
        "name": "ET Retail Footwear",
        "kind": "rss",
        "url": "https://retail.economictimes.indiatimes.com/rss/apparel-fashion/footwear",
        "discovery_only": False,
    },
    {
        "name": "The Guardian Fashion",
        "kind": "rss",
        "url": "https://www.theguardian.com/fashion/rss",
        "discovery_only": False,
    },
    {
        "name": "The Guardian Retail",
        "kind": "rss",
        "url": "https://www.theguardian.com/business/retail/rss",
        "discovery_only": False,
    },
    {
        "name": "The Guardian Cybercrime",
        "kind": "rss",
        "url": "https://www.theguardian.com/technology/cybercrime/rss",
        "discovery_only": False,
    },
]

from __future__ import annotations

import json
import re
from collections import OrderedDict
from datetime import datetime, timezone
from typing import Any
from urllib.parse import parse_qs, urlparse

import feedparser
from bs4 import BeautifulSoup
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse, JSONResponse, Response

from app.feed_builder import build_google_news_brand_queries
from app.filters import MarcasFilter
from app.map_builder import build_map_payload
from app.trusted_sources import DIRECT_SOURCE_FEEDS

USER_AGENT = "CyberRad/5.0 Marcas Textil Patch (+https://localhost)"
TIMEOUT = 20
APP_PORT = 3001

api = FastAPI(title="CyberRad Marcas 5.0 Patch Fixed", version="5.0.1")
filter_engine = MarcasFilter()


@api.get("/", response_class=HTMLResponse)
def home() -> str:
    return """
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CyberRad Marcas 5.0.1</title>
  <style>
    :root{color-scheme:dark}
    body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#071018;color:#e7fff3}
    .wrap{max-width:1100px;margin:0 auto;padding:24px}
    .card{background:#0d1823;border:1px solid #163e32;border-radius:16px;padding:18px;margin-bottom:18px;box-shadow:0 0 0 1px rgba(0,255,120,.04) inset}
    h1{margin:0 0 8px 0;color:#92ffbd}
    h2{margin:0 0 12px 0;color:#92ffbd;font-size:20px}
    p{line-height:1.5;margin:8px 0}
    .row{display:flex;gap:12px;flex-wrap:wrap}
    button,a.btn{background:#16c25f;border:none;color:#08110d;padding:12px 16px;border-radius:12px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-block}
    button.secondary,a.secondary{background:#1b2635;color:#d6e6ff;border:1px solid #2b4157}
    input{background:#09131b;border:1px solid #294051;color:#fff;border-radius:10px;padding:10px 12px;width:110px}
    pre{white-space:pre-wrap;word-break:break-word;background:#051018;border-radius:12px;padding:14px;border:1px solid #173041;max-height:65vh;overflow:auto}
    .ok{color:#79ffa7;font-weight:700}
    small{color:#95aab8}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>CyberRad Marcas 5.0.1</h1>
      <p class="ok">Parche arreglado: ya responde en la raíz, usa el puerto 3001 y trae visor web básico.</p>
      <p>Filtro orientado a marcas del sector textil, retail, moda y ecommerce afectadas por incidentes de ciberseguridad.</p>
      <div class="row">
        <a class="btn" href="/health" target="_blank">Health</a>
        <a class="btn secondary" href="/docs" target="_blank">Docs</a>
      </div>
    </div>

    <div class="card">
      <h2>Escaneo rápido</h2>
      <div class="row">
        <label>Límite <input id="limit" type="number" min="1" max="500" value="50"></label>
        <button onclick="loadData('marcas')">Ver Marcas</button>
        <button class="secondary" onclick="loadData('map')">Ver Mapa</button>
      </div>
      <p><small>La primera carga puede tardar un poco porque consulta feeds y noticias.</small></p>
    </div>

    <div class="card">
      <h2>Resultado</h2>
      <pre id="out">Pulsa un botón para cargar datos.</pre>
    </div>
  </div>
  <script>
    async function loadData(kind){
      const limit = document.getElementById('limit').value || '50';
      const out = document.getElementById('out');
      out.textContent = 'Cargando...';
      try {
        const r = await fetch(`/scan/${kind}?limit=${encodeURIComponent(limit)}`);
        const data = await r.json();
        out.textContent = JSON.stringify(data, null, 2);
      } catch (e) {
        out.textContent = 'Error: ' + e;
      }
    }
  </script>
</body>
</html>
    """.strip()


@api.get("/favicon.ico")
def favicon() -> Response:
    return Response(status_code=204)


@api.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "cyberrad-marcas", "version": "5.0.1", "port": str(APP_PORT)}


@api.get("/scan/marcas")
def scan_marcas(limit: int = Query(default=200, ge=1, le=500)) -> JSONResponse:
    items = run_scan(limit=limit)
    return JSONResponse(items)


@api.get("/scan/map")
def scan_map(limit: int = Query(default=200, ge=1, le=500)) -> JSONResponse:
    items = run_scan(limit=limit)
    return JSONResponse(build_map_payload(items))


@api.get("/scan/summary")
def scan_summary(limit: int = Query(default=200, ge=1, le=500)) -> JSONResponse:
    items = run_scan(limit=limit)
    included = [i for i in items if i.get("include")]
    summary = {
        "total": len(items),
        "included": len(included),
        "top_brands": top_counts(included, "brand"),
        "top_countries": top_counts(included, "map_country_label"),
        "top_sources": top_counts(included, "source"),
    }
    return JSONResponse(summary)


def top_counts(items: list[dict[str, Any]], key: str, limit: int = 15) -> list[dict[str, Any]]:
    counts: OrderedDict[str, int] = OrderedDict()
    for item in items:
        value = (item.get(key) or "").strip()
        if not value:
            continue
        counts[value] = counts.get(value, 0) + 1
    ordered = sorted(counts.items(), key=lambda x: (-x[1], x[0]))
    return [{"name": name, "count": count} for name, count in ordered[:limit]]


def run_scan(limit: int = 200) -> list[dict[str, Any]]:
    raw_items: list[dict[str, Any]] = []
    for feed in DIRECT_SOURCE_FEEDS + build_google_news_brand_queries():
        raw_items.extend(fetch_feed(feed))

    deduped = dedupe_items(raw_items)
    decisions = [filter_engine.classify(item).to_dict() | {"published": item.get("published")} for item in deduped]
    decisions.sort(key=lambda item: (item["include"], item["score"], item.get("published") or ""), reverse=True)
    return decisions[:limit]


def fetch_feed(feed: dict[str, Any]) -> list[dict[str, Any]]:
    try:
        parsed = feedparser.parse(feed["url"])
    except Exception:
        return []

    items: list[dict[str, Any]] = []
    for entry in parsed.entries:
        article_url = extract_article_url(entry.get("link", ""))
        title = clean_html(entry.get("title", ""))
        summary = clean_html(entry.get("summary", ""))
        content = ""
        if entry.get("content"):
            first = entry["content"][0]
            content = clean_html(first.get("value", ""))
        source = feed.get("name")
        if entry.get("source") and isinstance(entry["source"], dict):
            source = entry["source"].get("title") or source
        published = normalize_published(entry)
        items.append(
            {
                "title": title,
                "summary": summary,
                "content": content,
                "url": entry.get("link", ""),
                "article_url": article_url,
                "source": source,
                "publisher_domain": urlparse(article_url if article_url else feed["url"]).netloc,
                "published": published,
                "discovery_only_source": bool(feed.get("discovery_only")),
            }
        )
    return items


def dedupe_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: OrderedDict[str, dict[str, Any]] = OrderedDict()
    for item in items:
        key = make_key(item)
        if key not in seen:
            seen[key] = item
    return list(seen.values())


def make_key(item: dict[str, Any]) -> str:
    title = re.sub(r"\s+", " ", (item.get("title") or "").lower()).strip()
    article_url = (item.get("article_url") or "").strip().lower()
    return article_url or title


def extract_article_url(url: str) -> str:
    if not url:
        return ""
    parsed = urlparse(url)
    if "news.google.com" not in parsed.netloc:
        return url
    qs = parse_qs(parsed.query)
    direct = qs.get("url")
    if direct:
        return direct[0]
    return url


def clean_html(value: str) -> str:
    if not value:
        return ""
    soup = BeautifulSoup(value, "html.parser")
    text = soup.get_text(" ", strip=True)
    return re.sub(r"\s+", " ", text).strip()


def normalize_published(entry: Any) -> str:
    if getattr(entry, "published_parsed", None):
        dt = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
        return dt.isoformat()
    if entry.get("published"):
        return str(entry.get("published"))
    return ""


if __name__ == "__main__":
    output = run_scan(limit=200)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = f"/app/out/marcas_scan_{ts}.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(output, fh, ensure_ascii=False, indent=2)
    print(path)

from __future__ import annotations

from collections import defaultdict
from typing import Any

from app.country_anchors import resolve_country_anchor


def build_map_payload(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = {}

    for item in items:
        if not item.get("include"):
            continue

        iso2 = (item.get("map_country_iso2") or "").upper().strip()
        label = item.get("map_country_label") or iso2
        if not iso2:
            continue

        if iso2 not in grouped:
            grouped[iso2] = {
                "country_iso2": iso2,
                "country_label": label,
                "count": 0,
                "brands": set(),
                "incident_terms": set(),
                "articles": [],
                "max_score": 0.0,
            }

        bucket = grouped[iso2]
        bucket["count"] += 1
        if item.get("brand"):
            bucket["brands"].add(item["brand"])
        for term in item.get("incident_terms") or []:
            bucket["incident_terms"].add(term)
        bucket["max_score"] = max(bucket["max_score"], float(item.get("score") or 0.0))
        bucket["articles"].append(
            {
                "title": item.get("title"),
                "brand": item.get("brand"),
                "source": item.get("source"),
                "article_url": item.get("article_url"),
                "score": item.get("score"),
                "published": item.get("published"),
            }
        )

    markers: list[dict[str, Any]] = []
    for iso2, bucket in grouped.items():
        anchor = resolve_country_anchor(iso2, bucket["country_label"])
        article_list = sorted(
            bucket["articles"],
            key=lambda entry: (float(entry.get("score") or 0.0), entry.get("published") or ""),
            reverse=True,
        )

        marker = {
            "country_iso2": bucket["country_iso2"],
            "country_label": bucket["country_label"],
            "count": bucket["count"],
            "brands": sorted(bucket["brands"]),
            "incident_terms": sorted(bucket["incident_terms"]),
            "top_articles": article_list[:10],
            "max_score": round(bucket["max_score"], 2),
            "anchor_mode": "country_visual_center",
        }

        if anchor:
            marker |= {
                "lat": anchor.lat,
                "lng": anchor.lng,
                "x_pct": anchor.x_pct,
                "y_pct": anchor.y_pct,
                "anchor_source": anchor.source,
            }
        else:
            marker |= {
                "lat": None,
                "lng": None,
                "x_pct": None,
                "y_pct": None,
                "anchor_source": "missing_anchor",
            }
        markers.append(marker)

    markers.sort(key=lambda entry: (entry["count"], entry["max_score"], entry["country_label"]), reverse=True)
    return markers

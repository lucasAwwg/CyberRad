from __future__ import annotations

from urllib.parse import quote

from app.brand_catalog import TEXTILE_BRANDS

INCIDENT_QUERY = '("data breach" OR breach OR hacked OR hack OR cyberattack OR "cyber attack" OR ransomware OR leak OR phishing OR skimming OR Magecart OR compromise OR exfiltration)'


def build_google_news_brand_queries() -> list[dict]:
    """Feeds de descubrimiento para encontrar prensa nacional/internacional.

    OJO: estos feeds solo descubren candidatos.
    La URL final del artículo debe pasar validación HTTPS + allowlist.
    """
    feeds: list[dict] = []
    seen: set[str] = set()

    for brand in TEXTILE_BRANDS:
        primary = brand["name"]
        query = f'"{primary}" {INCIDENT_QUERY}'
        if query in seen:
            continue
        seen.add(query)
        feeds.append(
            {
                "name": f"Google News {primary}",
                "kind": "rss",
                "url": _build_google_news_rss(query),
                "discovery_only": True,
            }
        )

    broad_queries = [
        '((fashion OR apparel OR textile OR clothing OR footwear OR luxury OR ecommerce OR retailer) AND (data breach OR cyberattack OR ransomware OR hacked OR leak))',
        '((Mango OR Nike OR Adidas OR Zara OR H&M OR Primark OR Uniqlo OR ASOS OR Zalando OR Decathlon) AND (data breach OR cyberattack OR ransomware OR hacked OR leak))',
        '((retail OR fashion brand OR apparel brand) AND (customer data exposed OR exfiltration OR phishing OR skimming OR Magecart))',
    ]
    for idx, query in enumerate(broad_queries, start=1):
        feeds.append(
            {
                "name": f"Google News Broad {idx}",
                "kind": "rss",
                "url": _build_google_news_rss(query),
                "discovery_only": True,
            }
        )

    return feeds


def _build_google_news_rss(query: str) -> str:
    encoded = quote(query)
    return f"https://news.google.com/rss/search?q={encoded}&hl=en-US&gl=US&ceid=US:en"

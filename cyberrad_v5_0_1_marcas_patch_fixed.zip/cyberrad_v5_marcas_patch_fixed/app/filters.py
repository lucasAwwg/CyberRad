from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Any
from urllib.parse import urlparse

import tldextract

from app.brand_catalog import COUNTRY_TO_LABEL, TEXTILE_BRANDS
from app.trusted_sources import TRUSTED_PUBLISHER_DOMAINS, VENDOR_BLOG_DOMAINS

STRONG_INCIDENT_TERMS = {
    "data breach",
    "breach",
    "hacked",
    "hack",
    "cyberattack",
    "cyber attack",
    "ransomware",
    "leak",
    "leaked",
    "compromise",
    "compromised",
    "exfiltration",
    "stolen customer data",
    "customer data exposed",
    "intrusion",
    "skimming",
    "magecart",
}

MEDIUM_INCIDENT_TERMS = {
    "phishing",
    "credential theft",
    "account takeover",
    "malware",
    "outage",
    "security incident",
    "security breach",
    "security event",
    "ddos",
}

TEXTILE_CONTEXT_TERMS = {
    "fashion",
    "apparel",
    "textile",
    "clothing",
    "garment",
    "footwear",
    "sportswear",
    "luxury",
    "retail",
    "ecommerce",
    "online store",
    "department store",
    "beauty retailer",
}

NEGATIVE_ADVISORY_TERMS = {
    "practical advice",
    "guide",
    "fundamentals",
    "analysis",
    "research",
    "read actionable advice",
    "how to",
    "inside an ai-enabled",
    "why your automated pentesting tool",
    "threat to critical infrastructure",
    "leaders need to act",
    "predictions",
    "best practices",
}

VICTIM_HINTS = {
    "customer",
    "customers",
    "shopper",
    "shoppers",
    "store",
    "stores",
    "retailer",
    "retailer's",
    "ecommerce",
    "online shop",
}


@dataclass
class BrandHit:
    canonical: str
    alias: str
    country_iso2: str
    country_label: str
    sector: str


@dataclass
class MarcasDecision:
    include: bool
    score: float
    title: str
    source: str
    publisher_domain: str
    article_url: str
    brand: str | None
    brand_country_iso2: str | None
    brand_country_label: str | None
    sector: str | None
    incident_terms: list[str]
    rationale: list[str]
    discovery_only_source: bool
    map_country_iso2: str | None
    map_country_label: str | None
    status: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class MarcasFilter:
    def __init__(self) -> None:
        self.brand_patterns: list[tuple[re.Pattern[str], BrandHit]] = []
        for brand in TEXTILE_BRANDS:
            for alias in brand["aliases"]:
                pattern = re.compile(rf"(?<!\w){re.escape(alias.lower())}(?!\w)")
                hit = BrandHit(
                    canonical=brand["name"],
                    alias=alias,
                    country_iso2=brand["country"],
                    country_label=COUNTRY_TO_LABEL.get(brand["country"], brand["country"]),
                    sector=brand["sector"],
                )
                self.brand_patterns.append((pattern, hit))

    def classify(self, item: dict[str, Any]) -> MarcasDecision:
        title = (item.get("title") or "").strip()
        summary = (item.get("summary") or "").strip()
        content = (item.get("content") or "").strip()
        combined = f"{title}\n{summary}\n{content}".lower()
        publisher_domain = _normalize_domain(item.get("publisher_domain") or item.get("source") or item.get("article_url") or "")
        article_url = item.get("article_url") or item.get("url") or ""
        article_domain = _normalize_domain(article_url)
        effective_domain = article_domain or publisher_domain
        discovery_only_source = bool(item.get("discovery_only_source"))

        score = 0.0
        rationale: list[str] = []

        https_ok = article_url.startswith("https://")
        if https_ok:
            score += 1
            rationale.append("URL HTTPS válida")
        else:
            rationale.append("URL no HTTPS o ausente")

        trusted_domain = self._is_trusted_domain(effective_domain)
        if trusted_domain:
            score += 2
            rationale.append("Dominio de noticia en allowlist de confianza")
        else:
            rationale.append("Dominio fuera de allowlist")

        if self._is_vendor_domain(effective_domain) or self._is_vendor_domain(publisher_domain):
            score -= 12
            rationale.append("Dominio vendor/blog de ciberseguridad")

        negative_hits = sorted(term for term in NEGATIVE_ADVISORY_TERMS if term in combined)
        if negative_hits:
            score -= 10
            rationale.append(f"Pinta a post educativo/advisory: {', '.join(negative_hits[:3])}")

        brand_hit = self._best_brand_hit(title, summary, content)
        if brand_hit:
            score += 8
            rationale.append(f"Marca víctima detectada: {brand_hit.canonical}")
        else:
            score -= 8
            rationale.append("No hay marca textil/retail víctima clara")

        incident_hits = self._incident_hits(combined)
        if incident_hits:
            score += 6
            rationale.append(f"Incidente detectado: {', '.join(incident_hits[:3])}")
        else:
            score -= 8
            rationale.append("No hay incidente ciber claro")

        textile_hits = sorted(term for term in TEXTILE_CONTEXT_TERMS if term in combined)
        if textile_hits:
            score += 2
            rationale.append(f"Contexto retail/moda: {', '.join(textile_hits[:3])}")

        victim_hits = sorted(term for term in VICTIM_HINTS if term in combined)
        if victim_hits:
            score += 1
            rationale.append("Hay señales de víctima/cliente/tienda")

        if brand_hit and brand_hit.canonical.lower() in (item.get("source") or "").lower() and not incident_hits:
            score -= 8
            rationale.append("Parece nota corporativa de la propia marca sin incidente")

        mandatory_ok = all(
            [
                bool(brand_hit),
                bool(incident_hits),
                https_ok,
                trusted_domain,
            ]
        )
        include = mandatory_ok and score >= 10
        status = "incluida" if include else ("pendiente" if score >= 6 else "excluida")

        return MarcasDecision(
            include=include,
            score=round(score, 2),
            title=title,
            source=item.get("source") or "",
            publisher_domain=effective_domain,
            article_url=article_url,
            brand=brand_hit.canonical if brand_hit else None,
            brand_country_iso2=brand_hit.country_iso2 if brand_hit else None,
            brand_country_label=brand_hit.country_label if brand_hit else None,
            sector=brand_hit.sector if brand_hit else None,
            incident_terms=incident_hits,
            rationale=rationale,
            discovery_only_source=discovery_only_source,
            map_country_iso2=brand_hit.country_iso2 if brand_hit else None,
            map_country_label=brand_hit.country_label if brand_hit else None,
            status=status,
        )

    def _best_brand_hit(self, title: str, summary: str, content: str) -> BrandHit | None:
        candidates: list[tuple[int, BrandHit]] = []
        title_lower = title.lower()
        summary_lower = summary.lower()
        content_lower = content.lower()

        for pattern, hit in self.brand_patterns:
            weight = 0
            if pattern.search(title_lower):
                weight += 6
            if pattern.search(summary_lower):
                weight += 3
            if pattern.search(content_lower):
                weight += 1
            if weight:
                candidates.append((weight, hit))

        if not candidates:
            return None
        candidates.sort(key=lambda pair: pair[0], reverse=True)
        return candidates[0][1]

    def _incident_hits(self, combined: str) -> list[str]:
        hits = [term for term in sorted(STRONG_INCIDENT_TERMS) if term in combined]
        hits.extend([term for term in sorted(MEDIUM_INCIDENT_TERMS) if term in combined])
        deduped: list[str] = []
        for hit in hits:
            if hit not in deduped:
                deduped.append(hit)
        return deduped

    @staticmethod
    def _is_trusted_domain(domain: str) -> bool:
        return _domain_in_set(domain, TRUSTED_PUBLISHER_DOMAINS)

    @staticmethod
    def _is_vendor_domain(domain: str) -> bool:
        return _domain_in_set(domain, VENDOR_BLOG_DOMAINS)


def _normalize_domain(value: str) -> str:
    if not value:
        return ""
    parsed = urlparse(value if "://" in value else f"https://{value}")
    host = parsed.netloc or parsed.path
    ext = tldextract.extract(host)
    if not ext.domain:
        return host.lower().strip()
    return f"{ext.domain}.{ext.suffix}".lower().strip(".")


def _domain_in_set(domain: str, allowed: set[str]) -> bool:
    if not domain:
        return False
    for entry in allowed:
        if domain == entry or domain.endswith(f".{entry}"):
            return True
    return False

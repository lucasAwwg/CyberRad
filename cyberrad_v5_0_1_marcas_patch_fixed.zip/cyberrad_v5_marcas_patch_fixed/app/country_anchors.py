from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

LAT_TOP = 84.0
LAT_BOTTOM = -60.0
LON_LEFT = -180.0
LON_RIGHT = 180.0


@dataclass(frozen=True)
class CountryAnchor:
    iso2: str
    label: str
    lat: float
    lng: float
    x_pct: float
    y_pct: float
    source: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# Centros visuales calibrados para un mapa mundi negro con fronteras blancas,
# pensados para colocar el marcador en el medio útil del país y no en una costa
# o en un punto raro de geocoder.
MANUAL_VISUAL_ANCHORS: dict[str, CountryAnchor] = {
    "AR": CountryAnchor("AR", "Argentina", -38.4, -63.6, 0.343, 0.748, "manual_visual_center"),
    "AU": CountryAnchor("AU", "Australia", -25.5, 134.5, 0.904, 0.762, "manual_visual_center"),
    "BD": CountryAnchor("BD", "Bangladés", 23.8, 90.3, 0.762, 0.455, "manual_visual_center"),
    "BE": CountryAnchor("BE", "Bélgica", 50.8, 4.5, 0.513, 0.246, "manual_visual_center"),
    "BH": CountryAnchor("BH", "Baréin", 26.1, 50.6, 0.649, 0.453, "manual_visual_center"),
    "BR": CountryAnchor("BR", "Brasil", -14.2, -52.9, 0.353, 0.621, "manual_visual_center"),
    "CA": CountryAnchor("CA", "Canadá", 57.0, -106.0, 0.207, 0.228, "manual_visual_center"),
    "CH": CountryAnchor("CH", "Suiza", 46.8, 8.2, 0.525, 0.294, "manual_visual_center"),
    "CN": CountryAnchor("CN", "China", 35.5, 103.8, 0.810, 0.348, "manual_visual_center"),
    "CR": CountryAnchor("CR", "Costa Rica", 9.9, -84.2, 0.274, 0.515, "manual_visual_center"),
    "CU": CountryAnchor("CU", "Cuba", 21.8, -79.5, 0.287, 0.434, "manual_visual_center"),
    "DE": CountryAnchor("DE", "Alemania", 51.0, 10.5, 0.535, 0.258, "manual_visual_center"),
    "DK": CountryAnchor("DK", "Dinamarca", 56.1, 10.0, 0.531, 0.215, "manual_visual_center"),
    "ES": CountryAnchor("ES", "España", 40.2, -3.5, 0.486, 0.312, "manual_visual_center"),
    "FR": CountryAnchor("FR", "Francia", 46.3, 2.5, 0.505, 0.286, "manual_visual_center"),
    "GB": CountryAnchor("GB", "Reino Unido", 54.4, -2.8, 0.496, 0.236, "manual_visual_center"),
    "IE": CountryAnchor("IE", "Irlanda", 53.3, -8.0, 0.470, 0.235, "manual_visual_center"),
    "IL": CountryAnchor("IL", "Israel", 31.2, 35.0, 0.603, 0.397, "manual_visual_center"),
    "IN": CountryAnchor("IN", "India", 22.8, 79.0, 0.732, 0.494, "manual_visual_center"),
    "IT": CountryAnchor("IT", "Italia", 42.8, 12.6, 0.551, 0.316, "manual_visual_center"),
    "JP": CountryAnchor("JP", "Japón", 36.0, 138.5, 0.884, 0.355, "manual_visual_center"),
    "KW": CountryAnchor("KW", "Kuwait", 29.3, 47.7, 0.639, 0.407, "manual_visual_center"),
    "LT": CountryAnchor("LT", "Lituania", 55.2, 23.9, 0.573, 0.236, "manual_visual_center"),
    "MX": CountryAnchor("MX", "México", 23.6, -102.5, 0.214, 0.461, "manual_visual_center"),
    "NL": CountryAnchor("NL", "Países Bajos", 52.3, 5.3, 0.519, 0.245, "manual_visual_center"),
    "NO": CountryAnchor("NO", "Noruega", 61.0, 8.5, 0.528, 0.178, "manual_visual_center"),
    "PA": CountryAnchor("PA", "Panamá", 8.8, -80.7, 0.282, 0.529, "manual_visual_center"),
    "PK": CountryAnchor("PK", "Pakistán", 29.8, 69.2, 0.713, 0.416, "manual_visual_center"),
    "PL": CountryAnchor("PL", "Polonia", 52.0, 19.1, 0.558, 0.257, "manual_visual_center"),
    "PT": CountryAnchor("PT", "Portugal", 39.6, -8.1, 0.474, 0.317, "manual_visual_center"),
    "PY": CountryAnchor("PY", "Paraguay", -23.3, -58.3, 0.348, 0.646, "manual_visual_center"),
    "SA": CountryAnchor("SA", "Arabia Saudí", 23.9, 45.1, 0.631, 0.470, "manual_visual_center"),
    "SE": CountryAnchor("SE", "Suecia", 62.0, 16.5, 0.551, 0.166, "manual_visual_center"),
    "SG": CountryAnchor("SG", "Singapur", 1.35, 103.8, 0.788, 0.579, "manual_visual_center"),
    "SY": CountryAnchor("SY", "Siria", 35.0, 38.5, 0.612, 0.372, "manual_visual_center"),
    "TR": CountryAnchor("TR", "Turquía", 39.0, 35.2, 0.602, 0.343, "manual_visual_center"),
    "US": CountryAnchor("US", "Estados Unidos", 39.8, -98.6, 0.231, 0.312, "manual_visual_center"),
    "AE": CountryAnchor("AE", "Emiratos Árabes Unidos", 24.3, 54.3, 0.661, 0.431, "manual_visual_center"),
}

# Fallback geográfico si aparece un país que no tenga centro visual calibrado.
# Se usa para sacar porcentaje X/Y estable sobre un mapa equirectangular simple.
FALLBACK_GEO_CENTERS: dict[str, tuple[float, float]] = {
    "AT": (47.6, 14.2),
    "CL": (-35.7, -71.5),
    "CO": (4.2, -73.0),
    "EG": (26.8, 30.8),
    "FI": (64.2, 26.0),
    "GR": (39.0, 22.0),
    "HU": (47.1, 19.3),
    "ID": (-2.2, 118.0),
    "KR": (36.4, 127.8),
    "MA": (31.8, -7.1),
    "MY": (4.2, 102.0),
    "NZ": (-41.2, 174.8),
    "PH": (12.8, 121.8),
    "RO": (45.9, 24.9),
    "RU": (61.5, 96.0),
    "TH": (15.9, 101.0),
    "TN": (34.0, 9.0),
    "UA": (49.0, 31.0),
    "UY": (-32.8, -56.0),
    "VN": (16.3, 107.6),
    "ZA": (-29.0, 24.0),
}


COUNTRY_LABELS = {anchor.iso2: anchor.label for anchor in MANUAL_VISUAL_ANCHORS.values()}


def resolve_country_anchor(iso2: str | None, label: str | None = None) -> CountryAnchor | None:
    if not iso2:
        return None
    iso2 = iso2.upper().strip()

    manual = MANUAL_VISUAL_ANCHORS.get(iso2)
    if manual:
        if label and label != manual.label:
            return CountryAnchor(
                iso2=manual.iso2,
                label=label,
                lat=manual.lat,
                lng=manual.lng,
                x_pct=manual.x_pct,
                y_pct=manual.y_pct,
                source=manual.source,
            )
        return manual

    geo = FALLBACK_GEO_CENTERS.get(iso2)
    if not geo:
        return None
    lat, lng = geo
    x_pct, y_pct = _project_to_world_map(lat=lat, lng=lng)
    return CountryAnchor(
        iso2=iso2,
        label=label or COUNTRY_LABELS.get(iso2, iso2),
        lat=lat,
        lng=lng,
        x_pct=x_pct,
        y_pct=y_pct,
        source="geo_fallback_projection",
    )


def _project_to_world_map(lat: float, lng: float) -> tuple[float, float]:
    x_pct = (lng - LON_LEFT) / (LON_RIGHT - LON_LEFT)
    y_pct = (LAT_TOP - lat) / (LAT_TOP - LAT_BOTTOM)
    return round(_clamp(x_pct), 4), round(_clamp(y_pct), 4)


def _clamp(value: float) -> float:
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value

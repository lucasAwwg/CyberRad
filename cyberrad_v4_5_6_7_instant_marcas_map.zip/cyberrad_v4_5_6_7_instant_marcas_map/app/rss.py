from __future__ import annotations

import hashlib
import html
import json
import re
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from typing import Any
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

STOPWORDS = {
    'para', 'como', 'sobre', 'entre', 'desde', 'hasta', 'that', 'this', 'with', 'from',
    'have', 'will', 'would', 'there', 'their', 'them', 'about', 'https', 'http', 'www',
    'security', 'cyber', 'news', 'and', 'the', 'una', 'unos', 'unas', 'por', 'porque',
    'pero', 'also', 'into', 'your', 'what', 'where', 'when', 'been', 'they', 'them',
    'los', 'las', 'del', 'con', 'sin', 'que', 'or', 'o', 'de', 'el', 'la', 'un', 'una',
    'latest', 'report', 'reports', 'analysis', 'blog', 'update', 'updates', 'new',
}

HEADERS = {'User-Agent': 'CyberRadV4.5/1.0 (+https://localhost:3000)'}

CONCEPT_LEXICON: dict[str, dict[str, Any]] = {
    'active_directory': {
        'label': 'Active Directory',
        'aliases': ['active directory', 'ad', 'domain controller', 'domain controllers', 'ldap', 'kerberos', 'ntlm', 'group policy', 'gpo', 'windows domain', 'directory services', 'azure ad', 'entra id', 'microsoft entra id', 'aad'],
        'context': ['microsoft', 'windows', 'domain', 'directory', 'identity', 'authentication', 'ldap', 'kerberos', 'gpo'],
        'ambiguous_aliases': {'ad'},
        'tags': ['Identity', 'Microsoft'],
    },
    'cve': {
        'label': 'CVE / Vulnerabilidades',
        'aliases': ['cve', 'vulnerability', 'vulnerabilities', 'security advisory', 'security advisories', 'advisory', 'advisories', 'flaw', 'security flaw', 'patch', 'exploit', 'exploited cve', 'zero-day', '0day', '0-day', 'actively exploited'],
        'tags': ['Vulnerability'],
    },
    'malware': {
        'label': 'Malware',
        'aliases': ['malware', 'ransomware', 'trojan', 'loader', 'backdoor', 'stealer', 'rat', 'wiper', 'botnet', 'infostealer', 'worm', 'dropper'],
        'tags': ['Malware'],
    },
    'ransomware': {
        'label': 'Ransomware',
        'aliases': ['ransomware', 'encryptor', 'double extortion', 'extortion group'],
        'tags': ['Malware', 'Ransomware'],
    },
    'phishing': {
        'label': 'Phishing',
        'aliases': ['phishing', 'smishing', 'vishing', 'credential theft', 'credential phishing', 'email lure'],
        'tags': ['Phishing'],
    },
    'edr': {
        'label': 'EDR / XDR',
        'aliases': ['edr', 'xdr', 'endpoint detection and response', 'extended detection and response'],
        'tags': ['Endpoint'],
    },
    'iam': {
        'label': 'Identity / IAM',
        'aliases': ['iam', 'identity', 'identity management', 'identity and access management', 'authentication', 'mfa', '2fa', 'sso'],
        'tags': ['Identity'],
    },
    'windows': {
        'label': 'Windows',
        'aliases': ['windows', 'windows server', 'microsoft windows', 'powershell'],
        'tags': ['Windows'],
    },
    'linux': {
        'label': 'Linux',
        'aliases': ['linux', 'ubuntu', 'debian', 'red hat', 'rhel', 'kernel', 'linux kernel'],
        'tags': ['Linux'],
    },
    'cloud': {
        'label': 'Cloud',
        'aliases': ['cloud', 'aws', 'azure', 'gcp', 'google cloud', 'kubernetes', 'container', 'docker'],
        'tags': ['Cloud'],
    },
    'incident': {
        'label': 'Incidentes',
        'aliases': ['incident', 'incident response', 'breach', 'outage', 'compromise', 'intrusion', 'attack', 'cyberattack'],
        'tags': ['Incident'],
    },
    'threat_intel': {
        'label': 'Threat Intel',
        'aliases': ['threat intelligence', 'threat intel', 'ioc', 'ttps', 'campaign', 'apt', 'actor'],
        'tags': ['ThreatIntel'],
    },
}

ALIAS_TO_CANONICAL: dict[str, str] = {}
for canonical, meta in CONCEPT_LEXICON.items():
    for alias in meta['aliases']:
        ALIAS_TO_CANONICAL[alias.lower()] = canonical
    ALIAS_TO_CANONICAL[meta['label'].lower()] = canonical

SOURCE_PRIORITY = {
    'cisa.gov': 0.14, 'nist.gov': 0.13, 'nvd.nist.gov': 0.13, 'us-cert.gov': 0.13,
    'microsoft.com': 0.12, 'crowdstrike.com': 0.12, 'google.com': 0.10, 'googleblog.com': 0.09,
    'fortinet.com': 0.10, 'incibe.es': 0.10, 'cisecurity.org': 0.10, 'ubuntu.com': 0.09,
    'qualys.com': 0.09, 'bleepingcomputer.com': 0.07, 'darkreading.com': 0.07, 'thehackernews.com': 0.06,
}

VENDORS = ['Microsoft', 'Google', 'Fortinet', 'Cisco', 'VMware', 'Palo Alto', 'Ivanti', 'FortiOS', 'Ubuntu', 'Linux', 'Windows', 'Synology', 'Grafana', 'Chrome', 'Duo', 'TeamViewer', 'FortiManager', 'Exchange', 'Entra', 'Active Directory']
SEVERITY_TERMS = {'critical': 0.12, 'high severity': 0.08, 'actively exploited': 0.14, 'zero-day': 0.14, '0day': 0.14, '0-day': 0.14, 'remote code execution': 0.12, 'rce': 0.12, 'privilege escalation': 0.10, 'auth bypass': 0.10, 'authentication bypass': 0.10, 'bypass': 0.05}
NOISE_PATTERNS = ['top 10', 'predictions for', 'market report', 'stock', 'streaming', 'music', 'royalty fraud', 'newsletter', 'press release', 'sponsored', 'webinar', 'podcast']
CVE_RE = re.compile(r'\bCVE-\d{4}-\d{4,7}\b', re.IGNORECASE)


MARCAS_RETAIL_TERMS = [
    'fashion', 'fashion retail', 'fashion retailer', 'apparel', 'clothing', 'textile', 'textiles',
    'luxury brand', 'luxury brands', 'fashion brand', 'fashion brands', 'clothing brand',
    'online store', 'online stores', 'fashion ecommerce', 'fashion e-commerce', 'ecommerce fashion',
    'fashion store', 'fashion stores', 'boutique', 'boutiques', 'department store', 'department stores',
    'ecommerce', 'e-commerce', 'moda', 'textil', 'textiles', 'tiendas de ropa', 'ropa', 'lujo',
    'tienda online', 'tiendas online', 'cadena textil', 'cadenas textiles', 'retail de moda',
    'empresa textil', 'empresas textiles', 'sector fashion', 'sector apparel', 'sector textile',
    'fashion house', 'fashion houses', 'luxury house', 'luxury retail', 'online fashion retailer',
    'fashion marketplace', 'luxury fashion', 'apparel retailer', 'textile company'
]

MARCAS_RETAIL_GENERIC_TERMS = [
    'retail', 'retailer', 'retailers', 'brand', 'brands', 'marca', 'marcas', 'shop', 'shops',
    'webshop', 'online shop', 'shopping cart', 'checkout', 'point of sale', 'pos terminal',
    'mall retailer', 'b2b', 'b2c'
]

MARCAS_RETAIL_STRONG_TERMS = [
    'fashion', 'apparel', 'clothing', 'textile', 'luxury brand', 'fashion brand', 'fashion retailer',
    'fashion ecommerce', 'fashion store', 'boutique', 'moda', 'textil', 'tiendas de ropa', 'lujo',
    'cadena textil', 'retail de moda', 'empresa textil', 'fashion house', 'luxury retail'
]

MARCAS_RETAIL_COMPANY_HINTS = [
    'zara', 'inditex', 'h&m', 'hm', 'shein', 'uniqlo', 'primark', 'mango', 'gap', 'nike',
    'adidas', 'lululemon', 'under armour', 'pvh', 'tommy hilfiger', 'calvin klein', 'puma',
    'burberry', 'gucci', 'prada', 'louis vuitton', 'dior', 'hermes', 'chanel', 'armani',
    'balenciaga', 'saks', 'macys', "macy's", 'nordstrom', 'asos', 'boohoo', 'zalando',
    'farfetch', 'yoox', 'net-a-porter', "victoria's secret", 'abercrombie', 'hollister',
    'tapestry', 'coach', 'kate spade', 'michael kors', 'ralph lauren', 'decathlon', 'hm group', 'fast retailing', 'levi strauss', 'levis', 'guess', 'superdry', 'moncler', 'burberry group', 'next plc', 'marks and spencer', 'm&s', 'river island', 'sephora', 'lvmh', 'kering', 'otb group'
]

MARCAS_RETAIL_CYBER_TERMS = [
    'cyberattack', 'cyber attack', 'cyber incident', 'security incident', 'data breach',
    'breach', 'breached', 'leaked data', 'leak', 'leakage', 'ransomware', 'malware',
    'phishing', 'credential theft', 'stolen credentials', 'account takeover', 'payment breach',
    'payment skimmer', 'magecart', 'e-skimming', 'skimmer', 'fraud', 'digital fraud', 'hack',
    'hacked', 'hacking', 'compromise', 'compromised', 'attacked', 'attack', 'intrusion',
    'ddos', 'botnet', 'web skimmer', 'supply chain attack', 'security flaw', 'vulnerability',
    'vulnerabilities', 'exploit', 'exploited', 'payment card', 'carding', 'checkout compromise',
    'customer data', 'customer records', 'customer account', 'account breach', 'store outage',
    'robo de credenciales', 'brecha de datos',
    'ataque cibernético', 'ciberataque', 'ciberincidente', 'incidente de ciberseguridad',
    'filtración', 'filtracion', 'fraude digital', 'malware', 'ransomware', 'compromiso de pagos'
]

MARCAS_RETAIL_STRONG_TERMS_EXT = [
    'brand', 'brands', 'retail', 'retailer', 'fashion', 'apparel', 'clothing', 'luxury', 'footwear',
    'shop', 'store', 'online store', 'ecommerce', 'e-commerce', 'webshop', 'marketplace', 'b2b', 'b2c',
    'direct-to-consumer', 'dtc', 'boutique', 'fashion retailer', 'clothing retailer', 'fashion ecommerce',
    'online fashion', 'luxury brand', 'textile retail', 'online fashion retailer', 'online clothing store',
    'digital fashion marketplace', 'ecommerce apparel platform', 'luxury ecommerce platform', 'fashion webshop',
    'streetwear ecommerce', 'sneaker marketplace', 'marketplace fashion', 'apparel platform', 'fashion marketplace'
]

MARCAS_RETAIL_COMPANY_HINTS_EXT = [
    'zalando', 'asos', 'shein', 'boohoo', 'prettylittlething', 'farfetch', 'yoox', 'net-a-porter', 'about you',
    'revolve', 'ssense', 'mytheresa', 'vinted', 'stockx', 'goat', 'fashion nova', 'urban outfitters', 'uniqlo',
    'h&m', 'zara', 'mango', 'nike', 'adidas', 'puma', 'primark', 'decathlon', 'matchesfashion', 'the outnet',
    'namshi', 'cider', 'boohoo man', 'pretty little thing', 'stockx', 'goat', 'vinted', 'about you', 'mytheresa', 'revolve', 'ssense', 'zalando', 'asos', 'shein', 'boohoo', 'prettylittlething', 'farfetch', 'yoox', 'net-a-porter', 'urban outfitters', 'mango', 'zara', 'h&m', 'nike', 'adidas', 'puma', 'primark', 'decathlon', 'uniqlo'
]

MARCAS_RETAIL_EXCLUSION_TERMS = [
    'telecom', 'telco', 'bank', 'banking', 'hospital', 'healthcare', 'government', 'ministries', 'ministry',
    'cryptocurrency', 'crypto exchange', 'blockchain', 'telegram', 'messaging app', 'infrastructure', 'pipeline',
    'utility company', 'software vendor', 'enterprise software', 'saas platform', 'database vendor', 'erp',
    'adobe', 'oracle', 'sap', 'salesforce', 'servicenow', 'vmware', 'atlassian', 'microsoft exchange', 'jira'
]


def clean_html(value: str | None) -> str:
    if not value:
        return ''
    soup = BeautifulSoup(value, 'html.parser')
    return html.unescape(soup.get_text(' ', strip=True))


def normalize_spaces(text: str | None) -> str:
    return re.sub(r'\s+', ' ', (text or '').strip().lower())


def normalize_tokens(text: str) -> list[str]:
    tokens = re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9\-]{2,}", text.lower())
    return [token for token in tokens if token not in STOPWORDS]


def token_set(text: str) -> set[str]:
    return set(normalize_tokens(text))


def unique(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        key = normalize_spaces(item)
        if key and key not in seen:
            seen.add(key)
            out.append(item)
    return out


def phrase_pattern(phrase: str) -> str:
    pieces = [re.escape(piece) for piece in normalize_spaces(phrase).split() if piece]
    if not pieces:
        return ''
    return r'(?<!\w)' + r'\s+'.join(pieces) + r'(?!\w)'


def phrase_in_text(text: str, phrase: str) -> bool:
    pattern = phrase_pattern(phrase)
    if not pattern:
        return False
    return re.search(pattern, normalize_spaces(text), flags=re.IGNORECASE) is not None


def parse_datetime_to_dt(value: str | None) -> datetime:
    if not value:
        return datetime.now(tz=timezone.utc)
    value = value.strip()
    try:
        return parsedate_to_datetime(value).astimezone(timezone.utc)
    except Exception:
        pass
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(timezone.utc)
    except Exception:
        return datetime.now(tz=timezone.utc)


def parse_datetime(value: str | None) -> str:
    return parse_datetime_to_dt(value).isoformat()


def article_matches_date_window(published_at: str | None, date_window: str) -> bool:
    date_window = (date_window or 'all').strip().lower()
    if date_window == 'all':
        return True
    article_dt = parse_datetime_to_dt(published_at)
    now = datetime.now(tz=timezone.utc)
    now_date = now.date()
    article_date = article_dt.date()
    if date_window == 'today':
        return article_date == now_date
    if date_window == 'yesterday':
        return article_date == (now_date - timedelta(days=1))
    try:
        days = int(date_window)
    except Exception:
        return True
    return article_dt >= (now - timedelta(days=days))


def split_prompt_terms(prompt: str) -> tuple[list[str], list[str]]:
    quoted = re.findall(r'"([^"]+)"', prompt)
    prompt_wo_quotes = re.sub(r'"[^"]+"', ' ', prompt)
    pieces = re.split(r'\n|,|;|\||\b(?:or|o)\b', prompt_wo_quotes, flags=re.IGNORECASE)
    include_terms: list[str] = []
    exclude_terms: list[str] = []
    for piece in pieces + quoted:
        item = piece.strip().strip("'“”‘’")
        if not item:
            continue
        if item.startswith('-'):
            exclude_terms.append(item[1:].strip())
        else:
            include_terms.append(item)
    return unique(include_terms), unique(exclude_terms)


def canonical_for_term(term: str) -> str | None:
    norm = normalize_spaces(term)
    if norm in ALIAS_TO_CANONICAL:
        return ALIAS_TO_CANONICAL[norm]
    for alias, canonical in ALIAS_TO_CANONICAL.items():
        if alias == norm or phrase_in_text(norm, alias) or phrase_in_text(alias, norm):
            return canonical
    return None


def variants_for_term(term: str) -> list[str]:
    canonical = canonical_for_term(term)
    if canonical:
        meta = CONCEPT_LEXICON[canonical]
        return unique([meta['label'], *meta['aliases'], term])
    parts = normalize_tokens(term)
    acronym = ''.join(p[0] for p in parts) if len(parts) > 1 else ''
    variants = [term]
    if 2 <= len(acronym) <= 6:
        variants.append(acronym)
    return unique(variants)


def unique_concepts(concepts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for concept in concepts:
        key = concept['canonical'] or normalize_spaces(concept['label'])
        if key in seen:
            continue
        seen.add(key)
        out.append(concept)
    return out


def parse_prompt(prompt: str) -> dict[str, Any]:
    prompt = (prompt or '').strip()
    include_terms, exclude_terms = split_prompt_terms(prompt)
    inferred_terms: list[str] = []
    if prompt and len(include_terms) <= 1:
        lower_prompt = normalize_spaces(prompt)
        for alias in sorted(ALIAS_TO_CANONICAL.keys(), key=len, reverse=True):
            if phrase_in_text(lower_prompt, alias):
                inferred_terms.append(CONCEPT_LEXICON[ALIAS_TO_CANONICAL[alias]]['label'])
    all_include = unique(include_terms + inferred_terms)
    concepts = []
    for term in all_include:
        canonical = canonical_for_term(term)
        label = CONCEPT_LEXICON[canonical]['label'] if canonical else term
        concepts.append({'term': term, 'canonical': canonical, 'label': label, 'variants': variants_for_term(term)})
    severity_filters = [term for term in ['critical', 'high severity', 'actively exploited', 'zero-day', 'rce', 'privilege escalation'] if phrase_in_text(prompt, term)]
    return {'raw': prompt, 'concepts': unique_concepts(concepts), 'exclude_terms': exclude_terms, 'severity_filters': severity_filters}


def get_domain_score(url: str | None) -> float:
    if not url:
        return 0.0
    netloc = urlparse(url).netloc.lower().replace('www.', '')
    best = 0.0
    for domain, score in SOURCE_PRIORITY.items():
        if netloc == domain or netloc.endswith('.' + domain) or domain in netloc:
            best = max(best, score)
    return best


def extract_tags_from_text(article_blob: str) -> list[str]:
    tags: list[str] = []
    for canonical, meta in CONCEPT_LEXICON.items():
        if any(phrase_in_text(article_blob, alias) for alias in meta['aliases'] if len(alias) > 2):
            tags.extend(meta.get('tags', []))
    for cve in CVE_RE.findall(article_blob):
        tags.append(cve.upper())
    for vendor in VENDORS:
        if phrase_in_text(article_blob, vendor):
            tags.append(vendor)
    return unique(tags)

def detect_sector_categories(title: str, summary: str, content: str, feed_name: str = '', feed_url: str = '', existing_tags: list[str] | None = None) -> tuple[list[str], list[str], list[str]]:
    blob = normalize_spaces(' '.join([title or '', summary or '', content or '', feed_name or '', feed_url or '']))
    title_summary_blob = normalize_spaces(' '.join([title or '', summary or '', feed_name or '']))

    sector_terms = unique(MARCAS_RETAIL_TERMS + MARCAS_RETAIL_STRONG_TERMS_EXT)
    company_terms = unique(MARCAS_RETAIL_COMPANY_HINTS + MARCAS_RETAIL_COMPANY_HINTS_EXT)
    sector_hits = [term for term in sector_terms if phrase_in_text(blob, term)]
    strong_sector_hits = [term for term in unique(MARCAS_RETAIL_STRONG_TERMS + MARCAS_RETAIL_STRONG_TERMS_EXT) if phrase_in_text(blob, term)]
    generic_sector_hits = [term for term in unique(MARCAS_RETAIL_GENERIC_TERMS + ['brand', 'brands', 'shop', 'store', 'retail', 'b2b', 'b2c']) if phrase_in_text(blob, term)]
    company_hits = [term for term in company_terms if phrase_in_text(blob, term)]
    cyber_hits = [term for term in MARCAS_RETAIL_CYBER_TERMS if phrase_in_text(blob, term)]
    exclusion_hits = [term for term in MARCAS_RETAIL_EXCLUSION_TERMS if phrase_in_text(blob, term)]

    tags_norm = {normalize_spaces(tag) for tag in (existing_tags or [])}
    cyber_tag_support = bool(tags_norm & {'malware', 'ransomware', 'phishing', 'incident', 'threatintel', 'vulnerability'})

    strong_sector_score = min(len(unique(strong_sector_hits)) * 0.42, 2.8)
    generic_sector_score = min(len(unique(generic_sector_hits)) * 0.34, 2.1)
    company_score = min(len(unique(company_hits)) * 1.18, 4.8)
    cyber_score = min(len(unique(cyber_hits)) * 0.36, 2.2) + (0.26 if cyber_tag_support else 0.0)
    exclusion_penalty = min(len(unique(exclusion_hits)) * 0.55, 1.8)

    feed_bias = 0.0
    if any(phrase_in_text(blob, term) for term in ('fashion cyber', 'moda ciber', 'fashion ecommerce cyber', 'retail payment fraud', 'magecart', 'payment skimmer', 'streetwear ecommerce', 'digital fashion marketplace', 'online fashion retailer', 'online clothing store', 'fashion webshop', 'sneaker marketplace')):
        feed_bias = 0.22
    if company_hits and cyber_hits:
        feed_bias += 0.12

    title_sector_bonus = 0.0
    if any(phrase_in_text(title_summary_blob, term) for term in ('fashion', 'apparel', 'clothing', 'textile', 'luxury', 'footwear', 'retail', 'brand', 'store', 'marketplace', 'ecommerce', 'webshop')):
        title_sector_bonus += 0.20
    if company_hits and any(phrase_in_text(title_summary_blob, term) for term in company_hits[:4]):
        title_sector_bonus += 0.26
    if any(phrase_in_text(title_summary_blob, term) for term in ('breach', 'ransomware', 'cyberattack', 'hack', 'phishing', 'malware', 'ciberataque', 'brecha de datos', 'filtración', 'payment breach', 'credential theft', 'magecart', 'compromise')):
        title_sector_bonus += 0.14

    brand_bonus = 0.42 if company_hits else 0.0
    discovery_bias = 0.0
    if any(phrase_in_text(blob, term) for term in ('google news -', 'fashion cyber', 'moda ciber', 'retail cyber', 'mode cyber', 'retail payments and magecart')):
        discovery_bias += 0.18
    if any(phrase_in_text(blob, term) for term in ('reuters retail cyber', 'nyt retail cyber', 'washington post retail cyber', 'bbc fashion cyber', 'guardian fashion cyber', 'la vanguardia moda ciber', 'el pais moda ciber', 'faz retail cyber', 'le monde mode cyber', 'arab news retail cyber', 'economic times retail cyber', 'south china morning post retail cyber')):
        discovery_bias += 0.14
    retail_context = strong_sector_score + generic_sector_score + company_score + title_sector_bonus + feed_bias + brand_bonus + discovery_bias
    total_score = retail_context + cyber_score - exclusion_penalty

    has_brand_or_retail_context = bool(company_hits) or len(unique(strong_sector_hits)) >= 1 or len(unique(generic_sector_hits)) >= 2 or any(phrase_in_text(blob, term) for term in ('online fashion retailer', 'online clothing store', 'digital fashion marketplace', 'ecommerce apparel platform', 'luxury ecommerce platform', 'fashion webshop', 'streetwear ecommerce', 'sneaker marketplace', 'fashion ecommerce', 'marketplace fashion'))
    has_real_cyber_context = len(unique(cyber_hits)) >= 1 or cyber_tag_support

    categories: list[str] = []
    extra_tags: list[str] = []
    reasons: list[str] = []

    if company_hits:
        reasons.append(f"Marca/retailer detectado: {', '.join(unique(company_hits)[:4])}")
    if strong_sector_hits or generic_sector_hits:
        reasons.append(f"Contexto retail/fashion: {', '.join(unique((strong_sector_hits + generic_sector_hits))[:5])}")
    if cyber_hits:
        reasons.append(f"Contexto ciber: {', '.join(unique(cyber_hits)[:4])}")
    elif cyber_tag_support:
        reasons.append('Contexto ciber inferido por tags técnicas')
    if exclusion_hits:
        reasons.append(f"Penalización sector ajeno: {', '.join(unique(exclusion_hits)[:4])}")

    include_marcas = False
    if has_brand_or_retail_context and has_real_cyber_context:
        if total_score >= 0.60:
            include_marcas = True
        elif company_hits and total_score >= 0.40:
            include_marcas = True
        elif len(unique(strong_sector_hits)) >= 1 and len(unique(cyber_hits)) >= 1 and total_score >= 0.52:
            include_marcas = True
        elif any(phrase_in_text(blob, term) for term in ('online fashion retailer', 'online clothing store', 'digital fashion marketplace', 'ecommerce apparel platform', 'luxury ecommerce platform', 'fashion webshop', 'streetwear ecommerce', 'sneaker marketplace', 'fashion ecommerce', 'marketplace', 'webshop', 'online store')) and total_score >= 0.46:
            include_marcas = True

    if include_marcas:
        categories.append('marcas_retail')
        extra_tags.extend(['Marcas', 'Retail/Fashion'])
        print(f"[CyberRad][Marcas] INCLUDE title={title[:90]!r} score={total_score:.2f} retail={retail_context:.2f} cyber={cyber_score:.2f} penalty={exclusion_penalty:.2f}")
    elif has_brand_or_retail_context or cyber_hits or exclusion_hits:
        print(f"[CyberRad][Marcas] EXCLUDE title={title[:90]!r} score={total_score:.2f} retail={retail_context:.2f} cyber={cyber_score:.2f} penalty={exclusion_penalty:.2f} reasons={'; '.join(reasons[:3])}")

    return unique(categories), unique(extra_tags), reasons


def title_cluster_key(title: str) -> str:
    cleaned = CVE_RE.sub(' ', title or '')
    tokens = [t for t in normalize_tokens(cleaned) if len(t) > 2][:10]
    if not tokens:
        return hashlib.sha1((title or '').encode('utf-8', errors='ignore')).hexdigest()[:20]
    return '-'.join(tokens)


def variant_score(variant: str, title: str, summary: str, content: str, concept: dict[str, Any]) -> tuple[float, str | None]:
    variant_norm = normalize_spaces(variant)
    if not variant_norm:
        return 0.0, None
    blob = ' '.join([title, summary, content])
    canonical = concept.get('canonical')
    meta = CONCEPT_LEXICON.get(canonical or '', {})
    ambiguous_aliases = set(meta.get('ambiguous_aliases', set()))
    if variant_norm in ambiguous_aliases:
        direct_ok = phrase_in_text(blob, meta.get('label', ''))
        context_ok = any(phrase_in_text(blob, ctx) for ctx in meta.get('context', []))
        if not direct_ok and not context_ok:
            return 0.0, None
    if phrase_in_text(title, variant_norm):
        return 1.0, f"Coincidencia en título con '{variant_norm}'"
    if phrase_in_text(summary, variant_norm):
        return 0.84, f"Coincidencia en resumen con '{variant_norm}'"
    if phrase_in_text(content, variant_norm):
        return 0.62, f"Coincidencia en contenido con '{variant_norm}'"
    variant_tokens = normalize_tokens(variant_norm)
    if len(variant_tokens) >= 2:
        title_tokens = token_set(title)
        summary_tokens = token_set(summary)
        content_tokens = token_set(content)
        title_overlap = len(set(variant_tokens) & title_tokens) / len(set(variant_tokens))
        summary_overlap = len(set(variant_tokens) & summary_tokens) / len(set(variant_tokens))
        content_overlap = len(set(variant_tokens) & content_tokens) / len(set(variant_tokens))
        score = max(title_overlap * 0.86, summary_overlap * 0.70, content_overlap * 0.50)
        if score >= 0.38:
            return score, f"Coincidencia parcial con '{variant_norm}'"
    return 0.0, None


def score_concept(concept: dict[str, Any], title: str, summary: str, content: str) -> tuple[float, str]:
    best_score = 0.0
    best_reason = f"Sin coincidencia clara para '{concept['label']}'"
    for variant in concept['variants']:
        score, reason = variant_score(variant, title, summary, content, concept)
        if score > best_score and reason:
            best_score = score
            best_reason = reason
    return round(min(best_score, 1.0), 4), best_reason


def recency_boost(published_at: str | None) -> tuple[float, str | None]:
    dt = parse_datetime_to_dt(published_at)
    days_old = max((datetime.now(tz=timezone.utc) - dt).total_seconds() / 86400, 0)
    if days_old <= 1:
        return 0.08, 'Muy reciente'
    if days_old <= 3:
        return 0.06, 'Reciente (3d)'
    if days_old <= 7:
        return 0.04, 'Reciente (7d)'
    if days_old <= 15:
        return 0.02, 'Reciente (15d)'
    return 0.0, None


def score_against_prompt(prompt: str, title: str, summary: str, content: str, feed_name: str = '', feed_url: str = '', published_at: str | None = None, relevance_mode: str = 'balanced') -> tuple[float, str, list[str], str]:
    parsed = parse_prompt(prompt)
    if not parsed['raw']:
        return 0.0, 'Sin prompt activo; la noticia queda pendiente para revisión manual.', [], title_cluster_key(title)
    article_blob = normalize_spaces(' '.join([title or '', summary or '', content or '', feed_name or '', feed_url or '']))
    concept_hits: list[tuple[float, str, str]] = []
    for concept in parsed['concepts']:
        score, reason = score_concept(concept, title or '', summary or '', content or '')
        if score > 0:
            concept_hits.append((score, reason, concept['label']))
    negative_hits = [term for term in parsed['exclude_terms'] if term and phrase_in_text(article_blob, term)]
    source_bonus = get_domain_score(feed_url)
    recency_score, recency_label = recency_boost(published_at)
    severity_bonus = 0.0
    severity_labels: list[str] = []
    for term, bonus in SEVERITY_TERMS.items():
        if phrase_in_text(article_blob, term):
            severity_bonus = max(severity_bonus, bonus)
            severity_labels.append(term)
    extracted_tags = extract_tags_from_text(article_blob)
    if 'cve' in {c['canonical'] for c in parsed['concepts'] if c.get('canonical')} and any(tag.startswith('CVE-') for tag in extracted_tags):
        severity_bonus += 0.05
    for noise in NOISE_PATTERNS:
        if phrase_in_text(article_blob, noise):
            severity_bonus -= 0.08
            break
    if not concept_hits:
        if negative_hits:
            return 0.0, f"Excluida por términos negativos del prompt: {', '.join(negative_hits[:4])}.", extracted_tags[:8], title_cluster_key(title)
        return 0.0, 'No se detectaron coincidencias suficientemente claras con el prompt.', extracted_tags[:8], title_cluster_key(title)
    concept_hits.sort(key=lambda item: item[0], reverse=True)
    best_score, best_reason, best_label = concept_hits[0]
    support_bonus = min(sum(score for score, _, _ in concept_hits[1:]) * 0.15, 0.20)
    diversity_bonus = 0.06 if len(concept_hits) >= 2 else 0.0
    final_score = best_score + support_bonus + diversity_bonus + source_bonus + recency_score + severity_bonus
    if negative_hits:
        final_score -= 0.45
    if relevance_mode == 'flexible':
        final_score += 0.04
    elif relevance_mode == 'strict':
        final_score -= 0.05
    final_score = round(max(0.0, min(final_score, 1.0)), 4)
    reasons = [best_reason, f"Tema principal: {best_label}"]
    if len(concept_hits) >= 2:
        reasons.append('Soporte adicional de otros términos del prompt')
    if source_bonus > 0:
        reasons.append('Fuente prioritaria')
    if recency_label:
        reasons.append(recency_label)
    if severity_labels:
        reasons.append(f"Severidad detectada: {', '.join(unique(severity_labels)[:3])}")
    if negative_hits:
        reasons.append(f"Penalizada por: {', '.join(negative_hits[:3])}")
    matched_labels = [label for _, _, label in concept_hits[:4]]
    tags = unique(matched_labels + extracted_tags)[:10]
    rationale = '. '.join(reasons) + f". Score {final_score:.2f}."
    return final_score, rationale, tags, title_cluster_key(title)


def thresholds_for_mode(relevance_mode: str) -> tuple[float, float]:
    if relevance_mode == 'flexible':
        return 0.42, 0.20
    if relevance_mode == 'strict':
        return 0.68, 0.36
    return 0.55, 0.28


def classify_article(prompt: str, title: str, summary: str, content: str, published_at: str | None, date_window: str = 'all', relevance_mode: str = 'balanced', feed_name: str = '', feed_url: str = '') -> tuple[float, str, str, list[str], str]:
    score, rationale, tags, cluster_key = score_against_prompt(prompt, title, summary, content, feed_name=feed_name, feed_url=feed_url, published_at=published_at, relevance_mode=relevance_mode)
    include_threshold, pending_threshold = thresholds_for_mode(relevance_mode)
    if not prompt.strip():
        status = 'pending'
    elif score >= include_threshold:
        status = 'included'
    elif score >= pending_threshold:
        status = 'pending'
    else:
        status = 'excluded'
    if not article_matches_date_window(published_at, date_window):
        status = 'excluded'
        rationale = f"Excluida por fecha: fuera de la ventana temporal '{date_window}'. " + rationale
    return score, status, rationale, tags, cluster_key


def local_name(tag: str) -> str:
    return tag.split('}', 1)[-1].lower()


def child_text(node: ET.Element, *names: str) -> str:
    wanted = {name.lower() for name in names}
    for child in list(node):
        if local_name(child.tag) in wanted and (child.text or '').strip():
            return child.text.strip()
    return ''


def first_link(node: ET.Element) -> str | None:
    for child in list(node):
        if local_name(child.tag) != 'link':
            continue
        href = child.attrib.get('href') or (child.text or '').strip()
        rel = child.attrib.get('rel', 'alternate')
        if href and rel in {'alternate', '', 'self'}:
            return href
    return None


def entry_media_xml(node: ET.Element) -> tuple[str | None, str | None]:
    image_url = None
    video_url = None
    for child in node.iter():
        tag = local_name(child.tag)
        if tag in {'content', 'thumbnail', 'enclosure'}:
            url = child.attrib.get('url') or child.attrib.get('href')
            type_ = (child.attrib.get('type') or '').lower()
            if url and not image_url and ('image' in type_ or url.lower().endswith(('.jpg', '.jpeg', '.png', '.webp', '.gif'))):
                image_url = url
            if url and not video_url and ('video' in type_ or 'youtube.com' in url or 'youtu.be' in url or 'vimeo.com' in url):
                video_url = url
    return image_url, video_url


def entry_media_json(item: dict[str, Any]) -> tuple[str | None, str | None]:
    image_url = item.get('image') or item.get('banner_image')
    video_url = None
    attachments = item.get('attachments') or []
    if isinstance(attachments, list):
        for attachment in attachments:
            if not isinstance(attachment, dict):
                continue
            url = attachment.get('url')
            mime = (attachment.get('mime_type') or attachment.get('type') or '').lower()
            if url and not image_url and ('image' in mime or url.lower().endswith(('.jpg', '.jpeg', '.png', '.webp', '.gif'))):
                image_url = url
            if url and not video_url and ('video' in mime or 'youtube.com' in url or 'youtu.be' in url or 'vimeo.com' in url):
                video_url = url
    if not video_url:
        for key in ('external_url', 'url'):
            candidate = item.get(key)
            if isinstance(candidate, str) and any(x in candidate for x in ('youtube.com', 'youtu.be', 'vimeo.com')):
                video_url = candidate
                break
    return image_url, video_url


def enrich_from_article(url: str) -> tuple[str | None, str | None]:
    if not url:
        return None, None
    lowered = url.lower()
    if lowered.endswith(('.xml', '.rss', '.rdf', '.json', '.atom')):
        return None, None
    try:
        response = requests.get(url, headers=HEADERS, timeout=6)
        response.raise_for_status()
    except Exception:
        return None, None
    content_type = (response.headers.get('content-type') or '').lower()
    if any(kind in content_type for kind in ('xml', 'rss', 'json', 'atom')):
        return None, None
    soup = BeautifulSoup(response.text, 'html.parser')
    def meta_value(*keys: str) -> str | None:
        for key in keys:
            tag = soup.find('meta', attrs={'property': key}) or soup.find('meta', attrs={'name': key})
            if tag and tag.get('content'):
                return tag['content']
        return None
    image = meta_value('og:image', 'twitter:image', 'twitter:image:src')
    video = meta_value('og:video', 'twitter:player')
    return image, video


def safe_feedly_url(article_url: str | None) -> str | None:
    return None


def parse_xml_items(xml_text: str) -> list[dict[str, Any]]:
    root = ET.fromstring(xml_text)
    root_name = local_name(root.tag)
    items: list[dict[str, Any]] = []
    if root_name == 'rss':
        channel = next((child for child in list(root) if local_name(child.tag) == 'channel'), root)
        for item in channel.findall('./*'):
            if local_name(item.tag) != 'item':
                continue
            items.append({'title': child_text(item, 'title'), 'link': child_text(item, 'link') or first_link(item), 'summary': child_text(item, 'description', 'summary'), 'content': child_text(item, 'encoded', 'content'), 'published': child_text(item, 'pubdate', 'published', 'updated', 'date'), 'id': child_text(item, 'guid', 'id'), 'xml_node': item})
        return items
    if root_name == 'feed':
        for entry in root.findall('./*'):
            if local_name(entry.tag) != 'entry':
                continue
            items.append({'title': child_text(entry, 'title'), 'link': first_link(entry), 'summary': child_text(entry, 'summary'), 'content': child_text(entry, 'content'), 'published': child_text(entry, 'published', 'updated'), 'id': child_text(entry, 'id'), 'xml_node': entry})
        return items
    if root_name == 'rdf':
        for item in root.findall('./*'):
            if local_name(item.tag) != 'item':
                continue
            items.append({'title': child_text(item, 'title'), 'link': child_text(item, 'link') or first_link(item), 'summary': child_text(item, 'description', 'summary'), 'content': child_text(item, 'encoded', 'content'), 'published': child_text(item, 'date', 'pubdate', 'published', 'updated'), 'id': child_text(item, 'guid', 'id'), 'xml_node': item})
        return items
    return items


def parse_json_items(text: str) -> list[dict[str, Any]]:
    payload = json.loads(text)
    if not isinstance(payload, dict):
        return []
    items: list[dict[str, Any]] = []
    for item in payload.get('items', []):
        if not isinstance(item, dict):
            continue
        image_url, video_url = entry_media_json(item)
        items.append({'title': item.get('title') or '', 'link': item.get('url') or item.get('external_url') or '', 'summary': item.get('summary') or item.get('content_text') or '', 'content': item.get('content_html') or item.get('content_text') or item.get('summary') or '', 'published': item.get('date_published') or item.get('date_modified') or '', 'id': item.get('id') or item.get('url') or item.get('external_url') or '', 'image_url': image_url, 'video_url': video_url})
    return items


def parse_items(feed_text: str, content_type: str = '') -> list[dict[str, Any]]:
    stripped = (feed_text or '').lstrip()
    is_json = 'json' in (content_type or '').lower() or stripped.startswith('{')
    if is_json:
        return parse_json_items(feed_text)
    return parse_xml_items(feed_text)


def parse_feed(feed: dict[str, Any], prompt: str, max_articles: int = 20, date_window: str = 'all', relevance_mode: str = 'balanced') -> list[dict[str, Any]]:
    response = requests.get(feed['url'], headers=HEADERS, timeout=15)
    response.raise_for_status()
    parsed_entries = parse_items(response.text, response.headers.get('content-type', ''))[:max_articles]
    articles: list[dict[str, Any]] = []
    for entry in parsed_entries:
        title = clean_html(entry.get('title'))
        article_url = entry.get('link') or feed['url']
        summary = clean_html(entry.get('summary'))
        content_text = clean_html(entry.get('content'))
        published_at = parse_datetime(entry.get('published'))
        image_url = entry.get('image_url')
        video_url = entry.get('video_url')
        if entry.get('xml_node') is not None:
            xml_image, xml_video = entry_media_xml(entry['xml_node'])
            image_url = image_url or xml_image
            video_url = video_url or xml_video
        if not image_url and article_url:
            fetched_image, fetched_video = enrich_from_article(article_url)
            image_url = image_url or fetched_image
            video_url = video_url or fetched_video
        score, status, rationale, tags, cluster_key = classify_article(prompt, title, summary, content_text, published_at, date_window=date_window, relevance_mode=relevance_mode, feed_name=feed.get('name', ''), feed_url=feed.get('url', ''))
        unique_source = entry.get('id') or article_url or f"{feed['url']}::{title}"
        unique_key = hashlib.sha256(unique_source.encode('utf-8', errors='ignore')).hexdigest()
        articles.append({'unique_key': unique_key, 'feed_id': feed.get('id'), 'feed_name': feed.get('name'), 'feed_url': feed.get('url'), 'title': title or '(Sin título)', 'article_url': article_url, 'feedly_url': safe_feedly_url(article_url), 'summary': summary, 'content': content_text, 'published_at': published_at, 'image_url': image_url, 'video_url': video_url, 'status': status, 'status_origin': 'auto', 'relevance_score': score, 'rationale': rationale, 'match_tags': json.dumps(tags, ensure_ascii=False), 'cluster_key': cluster_key})
    return articles
